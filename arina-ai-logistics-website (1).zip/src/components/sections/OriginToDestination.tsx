import { Anchor, FileCheck2, Factory, Globe2, PackageCheck, Truck, Warehouse, type LucideIcon } from "lucide-react";

/* ---------------------------------------------------------------
   Section 5 — From Origin to Destination
   Static frontend component (not connected to the Content Editor).
--------------------------------------------------------------- */

type StageState = "done" | "current" | "pending";

const stages: { step: string; title: string; text: string; icon: LucideIcon; state: StageState }[] = [
  { step: "01", title: "Factory", text: "Goods are produced, packed", icon: Factory, state: "done" },
  { step: "02", title: "Pickup", text: "Collected from supplier's dock", icon: Truck, state: "done" },
  { step: "03", title: "Warehouse", text: "Consolidated, inspected and prepared", icon: Warehouse, state: "done" },
  { step: "04", title: "Port / Airport", text: "Booked, loaded and dispatched", icon: Anchor, state: "done" },
  { step: "05", title: "International Transit", text: "Moving across international routes", icon: Globe2, state: "current" },
  { step: "06", title: "Customs", text: "Declared, inspected and cleared", icon: FileCheck2, state: "pending" },
  { step: "07", title: "Final Delivery", text: "Delivered to the destination", icon: PackageCheck, state: "pending" },
];

export function OriginToDestination() {
  return (
    <section className="otd section-pad" aria-labelledby="otd-title">
      <div className="container">
        <div className="section-heading otd-head">
          <p className="eyebrow">
            <span className="eyebrow-line" />
            Global operations
          </p>
          <h2 id="otd-title">From Origin to Destination</h2>
          <p>Every shipment follows a controlled, visible path — with a named team accountable at each stage.</p>
        </div>

        <ol className="otd-steps">
          <span className="otd-line" aria-hidden="true" />
          <span className="otd-line-fill" aria-hidden="true" />
          {stages.map((s) => {
            const Icon = s.icon;
            return (
              <li key={s.step} className="otd-step">
                <span className={`otd-icon is-${s.state}`}>
                  <Icon size={26} strokeWidth={1.5} aria-hidden="true" />
                </span>
                <div className="otd-copy">
                  <span className="otd-num">{s.step}</span>
                  <h3>{s.title}</h3>
                  <p>{s.text}</p>
                </div>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
