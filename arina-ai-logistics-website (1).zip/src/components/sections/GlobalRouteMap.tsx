import { project, MAP_HEIGHT, MAP_WIDTH, WORLD_DOTS_PATH } from "./world-dots";
import {
  POINT_KIND_LABEL,
  pointXY,
  points,
  regionLabelPositions,
  routeShapes,
  type PointKind,
} from "./network-static";

/* ---------------------------------------------------------------
   Section 1 — Global Shipping Route Map
   Static frontend component (not connected to the Content Editor).
--------------------------------------------------------------- */

const SEA = "#3fd9cb";
const AIR = "rgba(226,240,245,0.62)";
const LAND = "rgba(140,175,205,0.30)";
const LABEL_STROKE = "#071e2e";

function labelDeltas(side: "t" | "b" | "l" | "r" | undefined, x: number, y: number) {
  switch (side) {
    case "b":
      return { x, y: y + 14, anchor: "middle" as const };
    case "l":
      return { x: x - 8, y: y + 3.5, anchor: "end" as const };
    case "r":
      return { x: x + 8, y: y + 3.5, anchor: "start" as const };
    default:
      return { x, y: y - 9, anchor: "middle" as const };
  }
}

function PointShape({ kind, x, y }: { kind: PointKind; x: number; y: number }) {
  switch (kind) {
    case "office":
      return (
        <>
          <circle cx={x} cy={y} r={3.2} fill={SEA} opacity={0.35} className="rmap-pulse" />
          <circle cx={x} cy={y} r={3.6} fill={SEA} stroke="#071e2e" strokeWidth={1.2} />
        </>
      );
    case "port":
      return <rect x={x - 2.6} y={y - 2.6} width={5.2} height={5.2} rx={1} fill="#eaf3f6" stroke="#071e2e" strokeWidth={0.9} />;
    case "airport":
      return (
        <rect
          x={x - 2.5}
          y={y - 2.5}
          width={5}
          height={5}
          fill="#0c2c40"
          stroke="#eaf3f6"
          strokeWidth={1.2}
          transform={`rotate(45 ${x} ${y})`}
        />
      );
    default:
      return <circle cx={x} cy={y} r={2.5} fill="#0c2c40" stroke="rgba(220,236,242,0.7)" strokeWidth={1.2} />;
  }
}

function LegendSymbol({ kind }: { kind: PointKind }) {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" aria-hidden="true" focusable="false">
      <PointShape kind={kind} x={6.5} y={6.5} />
    </svg>
  );
}

export function GlobalRouteMap() {
  return (
    <section className="rmap section-pad" aria-labelledby="rmap-title">
      <div className="container">
        <div className="rmap-head">
          <div className="section-heading rmap-heading">
            <p className="eyebrow eyebrow-light">
              <span className="eyebrow-line" />
              Global routes
            </p>
            <h2 id="rmap-title">One network. Every major trade lane.</h2>
            <p>
              Ocean and air corridors linking our offices, gateway ports and partner hubs across six regions — the routes
              we plan, book and monitor every day.
            </p>
          </div>
          <dl className="rmap-stats">
            <div>
              <dt>Trade regions</dt>
              <dd>06</dd>
            </div>
            <div>
              <dt>Network points</dt>
              <dd>{String(points.length).padStart(2, "0")}</dd>
            </div>
            <div>
              <dt>Lane types</dt>
              <dd>Ocean · Air</dd>
            </div>
          </dl>
        </div>

        <figure className="rmap-card">
          <div className="rmap-scroll">
            <svg
              viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
              className="rmap-svg"
              role="img"
              aria-label="World map showing offices, ports, airports and partner hubs across six regions, linked by ocean shipping lanes and air corridors"
            >
              {/* Land as dot matrix */}
              <path d={WORLD_DOTS_PATH} fill="none" stroke={LAND} strokeWidth={2.4} strokeLinecap="round" />

              {/* Shipping lanes (solid, gently flowing) */}
              <g fill="none" strokeLinecap="round">
                {routeShapes
                  .filter((r) => r.mode === "sea")
                  .map((r) => (
                    <path key={`sea-${r.from}-${r.to}`} d={r.d} stroke={SEA} strokeWidth={1.5} strokeOpacity={0.75} strokeDasharray="1 0" />
                  ))}
                {routeShapes
                  .filter((r) => r.mode === "air")
                  .map((r) => (
                    <path key={`air-${r.from}-${r.to}`} d={r.d} stroke={AIR} strokeWidth={1.1} strokeDasharray="3 6" />
                  ))}
                {/* moving markers */}
                <g className="rmap-flow">
                  {routeShapes.map((r, i) => (
                    <circle key={`m-${r.from}-${r.to}`} r={r.mode === "sea" ? 2.1 : 1.7} fill={r.mode === "sea" ? "#7be6dc" : "#dfeef3"}>
                      <animateMotion dur={`${9 + (i % 5) * 1.7}s`} begin={`-${(i * 1.6) % 8}s`} repeatCount="indefinite" path={r.d} />
                    </circle>
                  ))}
                </g>
              </g>

              {/* Network points */}
              <g>
                {points.map((p) => {
                  const [x, y] = pointXY[p.id];
                  return (
                    <g key={p.id}>
                      <PointShape kind={p.kind} x={x} y={y} />
                      <title>{`${p.name} — ${POINT_KIND_LABEL[p.kind]}`}</title>
                    </g>
                  );
                })}
              </g>

              {/* Region labels */}
              <g fontSize={10} fontWeight={700} letterSpacing={2.4} pointerEvents="none">
                {regionLabelPositions.map((r) => {
                  const [x, y] = project(r.lon, r.lat);
                  return (
                    <text
                      key={r.id}
                      x={x}
                      y={y}
                      textAnchor="middle"
                      fill="#e8f2f6"
                      stroke={LABEL_STROKE}
                      strokeWidth={3.2}
                      paintOrder="stroke"
                    >
                      {r.name}
                    </text>
                  );
                })}
              </g>
            </svg>
          </div>

          <figcaption className="rmap-legend">
            <ul>
              {(["office", "port", "airport", "partner"] as PointKind[]).map((k) => (
                <li key={k}>
                  <LegendSymbol kind={k} />
                  {POINT_KIND_LABEL[k]}
                </li>
              ))}
              <li>
                <svg width="26" height="8" viewBox="0 0 26 8" aria-hidden="true">
                  <line x1="1" y1="4" x2="25" y2="4" stroke={SEA} strokeWidth="1.8" strokeLinecap="round" />
                </svg>
                Shipping lane
              </li>
              <li>
                <svg width="26" height="8" viewBox="0 0 26 8" aria-hidden="true">
                  <line x1="1" y1="4" x2="25" y2="4" stroke="#dfeef3" strokeWidth="1.5" strokeDasharray="3 5" strokeLinecap="round" />
                </svg>
                Air route
              </li>
            </ul>
            <p className="rmap-note">Illustrative routes · Key network points shown</p>
          </figcaption>
        </figure>

        <p className="rmap-hint" aria-hidden="true">
          Swipe to explore the map →
        </p>
      </div>
    </section>
  );
}
