"use client";

import { useId, useState } from "react";
import { Globe2, Plane, Ship, TrainFront, Truck } from "lucide-react";
import { MAP_HEIGHT, MAP_WIDTH, project, WORLD_DOTS_PATH } from "./world-dots";
import {
  POINT_KIND_LABEL,
  pointXY,
  points,
  regionLabelName,
  regionOrder,
  regionRects,
  regions,
  routeShapes,
  type PointKind,
  type RegionId,
  type RegionKey,
} from "./network-static";

/* ---------------------------------------------------------------
   Section 3 — Regional Operations Map
   Static frontend data, region tabs drive the highlight + panel.
--------------------------------------------------------------- */

const SEA = "#3fd9cb";
const LAND = "rgba(140,175,205,0.22)";
const LAND_ACTIVE = "#4fd6c9";

const modeIcon = { Ocean: Ship, Air: Plane, Road: Truck, Rail: TrainFront } as const;

function labelDeltas(side: "t" | "b" | "l" | "r" | undefined, x: number, y: number) {
  switch (side) {
    case "b":
      return { x, y: y + 14, anchor: "middle" as const };
    case "l":
      return { x: x - 8, y: y + 3.5, anchor: "end" as const };
    case "r":
      return { x: x + 8, y: y + 3.5, anchor: "start" as const };
    default:
      return { x, y: y - 9, anchor: "middle" as const };
  }
}

function PointShape({ kind, x, y, muted }: { kind: PointKind; x: number; y: number; muted: boolean }) {
  const dim = muted ? 0.28 : 1;
  switch (kind) {
    case "office":
      return (
        <g opacity={dim}>
          <circle cx={x} cy={y} r={3.4} fill={SEA} opacity={0.3} className="rmap-pulse" />
          <circle cx={x} cy={y} r={3.6} fill={SEA} stroke="#071e2e" strokeWidth={1.2} />
        </g>
      );
    case "port":
      return (
        <g opacity={dim}>
          <rect x={x - 2.6} y={y - 2.6} width={5.2} height={5.2} rx={1} fill="#eaf3f6" stroke="#071e2e" strokeWidth={0.9} />
        </g>
      );
    case "airport":
      return (
        <g opacity={dim}>
          <rect x={x - 2.5} y={y - 2.5} width={5} height={5} fill="#0c2c40" stroke="#eaf3f6" strokeWidth={1.2} transform={`rotate(45 ${x} ${y})`} />
        </g>
      );
    default:
      return (
        <g opacity={dim}>
          <circle cx={x} cy={y} r={2.5} fill="#0c2c40" stroke="rgba(220,236,242,0.7)" strokeWidth={1.2} />
        </g>
      );
  }
}

function LegendSymbol({ kind }: { kind: PointKind }) {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" aria-hidden="true" focusable="false">
      <PointShape kind={kind} x={6.5} y={6.5} muted={false} />
    </svg>
  );
}

export function RegionalOperations() {
  const [selected, setSelected] = useState<RegionId>("all");
  const uid = useId().replace(/:/g, "");
  const clipId = `rops-clip-${uid}`;

  const region = selected === "all" ? null : (regions.find((r) => r.id === selected) as (typeof regions)[number]);
  const activeKey = selected === "all" ? null : (selected as RegionKey);

  return (
    <section className="rops section-pad" aria-labelledby="rops-title">
      <div className="container">
        <div className="section-heading rops-heading">
          <p className="eyebrow eyebrow-light">
            <span className="eyebrow-line" />
            Regional operations
          </p>
          <h2 id="rops-title">Explore the network region by region</h2>
          <p>
            Select a region to see major destinations, transportation modes, network points and the services available
            there.
          </p>
        </div>

        <div className="rops-card">
          <div className="rops-tabs" role="group" aria-label="Select a region">
            {regionOrder.map((id) => {
              const on = selected === id;
              return (
                <button
                  key={id}
                  type="button"
                  className={`rops-tab${on ? " is-active" : ""}`}
                  aria-pressed={on}
                  onClick={() => setSelected(id)}
                >
                  {regionLabelName[id]}
                </button>
              );
            })}
          </div>

          <div className="rmap-scroll">
            <svg
              viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
              className="rmap-svg rops-svg"
              role="img"
              aria-label={
                region
                  ? `World map with ${region.name} highlighted, showing regional offices, ports and airports`
                  : "World map showing all regional offices, ports, airports and partner hubs"
              }
            >
              <defs>
                <clipPath id={clipId}>
                  {(activeKey ? regionRects[activeKey] : []).map((r, i) => (
                    <rect key={i} {...r} />
                  ))}
                </clipPath>
              </defs>

              <path d={WORLD_DOTS_PATH} fill="none" stroke={LAND} strokeWidth={2.4} strokeLinecap="round" />
              {activeKey && (
                <path
                  d={WORLD_DOTS_PATH}
                  fill="none"
                  stroke={LAND_ACTIVE}
                  strokeWidth={2.7}
                  strokeLinecap="round"
                  clipPath={`url(#${clipId})`}
                />
              )}

              {/* Routes — dimmed outside the selected region */}
              <g fill="none" strokeLinecap="round">
                {routeShapes.map((r) => {
                  const related =
                    !activeKey ||
                    points.find((p) => p.id === r.from)?.region === activeKey ||
                    points.find((p) => p.id === r.to)?.region === activeKey;
                  return (
                    <path
                      key={`${r.mode}-${r.from}-${r.to}`}
                      d={r.d}
                      stroke={r.mode === "sea" ? SEA : "rgba(226,240,245,0.6)"}
                      strokeWidth={r.mode === "sea" ? 1.3 : 1}
                      strokeDasharray={r.mode === "sea" ? undefined : "3 6"}
                      strokeOpacity={related ? (r.mode === "sea" ? 0.7 : 0.55) : 0.12}
                      style={{ transition: "stroke-opacity .35s ease" }}
                    />
                  );
                })}
              </g>

              {/* Points + city labels for the selected region */}
              <g>
                {points.map((p) => {
                  const [x, y] = pointXY[p.id];
                  const muted = !!activeKey && p.region !== activeKey;
                  return (
                    <g key={p.id}>
                      <PointShape kind={p.kind} x={x} y={y} muted={muted} />
                      <title>{`${p.name} — ${POINT_KIND_LABEL[p.kind]}`}</title>
                      {activeKey && p.region === activeKey && p.feature && (
                        <text
                          {...labelDeltas(p.label, x, y)}
                          fontSize={8.5}
                          fontWeight={600}
                          fill="#eaf3f6"
                          stroke="#071e2e"
                          strokeWidth={2.8}
                          paintOrder="stroke"
                          pointerEvents="none"
                        >
                          {p.name}
                        </text>
                      )}
                    </g>
                  );
                })}
              </g>

              {/* Region names when no region is selected */}
              {!activeKey && (
                <g fontSize={10} fontWeight={700} letterSpacing={2.4} pointerEvents="none">
                  {regions.map((r) => {
                    const [x, y] = project(r.labelAt[0], r.labelAt[1]);
                    return (
                      <text key={r.id} x={x} y={y} textAnchor="middle" fill="#e8f2f6" stroke="#071e2e" strokeWidth={3.2} paintOrder="stroke">
                        {r.name.toUpperCase()}
                      </text>
                    );
                  })}
                </g>
              )}
            </svg>
          </div>

          <div className="rmap-legend rops-legend">
            <ul>
              {(["office", "port", "airport", "partner"] as PointKind[]).map((k) => (
                <li key={k}>
                  <LegendSymbol kind={k} />
                  {POINT_KIND_LABEL[k]}
                </li>
              ))}
              <li>
                <svg width="26" height="8" viewBox="0 0 26 8" aria-hidden="true">
                  <line x1="1" y1="4" x2="25" y2="4" stroke={SEA} strokeWidth="1.8" strokeLinecap="round" />
                </svg>
                Shipping lane
              </li>
              <li>
                <svg width="26" height="8" viewBox="0 0 26 8" aria-hidden="true">
                  <line x1="1" y1="4" x2="25" y2="4" stroke="#dfeef3" strokeWidth="1.5" strokeDasharray="3 5" strokeLinecap="round" />
                </svg>
                Air route
              </li>
            </ul>
            <p className="rmap-note">Illustrative routes · Key network points shown</p>
          </div>
        </div>

        {/* Information panel */}
        <div className="rops-panel" aria-live="polite">
          <div className="rops-panel-main">
            <p className="rops-kicker">Selected region</p>
            <h3 className="rops-region-name">{region ? region.name : "All Regions"}</h3>
            <p className="rops-blurb">
              {region
                ? region.blurb
                : "A connected network across Asia, Europe, the Middle East, North America, Africa and Australia — coordinated by one team from origin to destination."}
            </p>
            <p className="rops-kicker rops-kicker-gap">Major destinations</p>
            <ul className="rops-chips">
              {(region ? region.destinations : ["Dubai", "Singapore", "Rotterdam", "New York", "Durban", "Sydney"]).map((d) => (
                <li key={d}>{d}</li>
              ))}
            </ul>
          </div>

          <div className="rops-panel-col">
            <p className="rops-kicker">Transportation modes</p>
            <ul className="rops-modes">
              {(region ? region.modes : (["Ocean", "Air", "Road", "Rail"] as const)).map((m) => {
                const Icon = modeIcon[m];
                return (
                  <li key={m}>
                    <Icon size={19} strokeWidth={1.5} aria-hidden="true" />
                    {m}
                  </li>
                );
              })}
            </ul>
            <p className="rops-kicker rops-kicker-gap">Available services</p>
            <ul className="rops-list">
              {(region
                ? region.services
                : ["Multimodal freight forwarding", "Customs clearance", "Warehousing & distribution", "Project cargo"]
              ).map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </div>

          <div className="rops-panel-col">
            <p className="rops-kicker">Network points</p>
            {(
              [
                ["Offices", region ? region.offices : ["Dubai", "Mumbai", "Shanghai", "Rotterdam", "New York", "Sydney"]],
                ["Ports", region ? region.ports : ["Jebel Ali", "Colombo", "Busan", "Los Angeles", "Durban", "Melbourne"]],
                ["Airports", region ? region.airports : ["Hong Kong", "Tokyo", "Frankfurt", "Chicago", "Nairobi"]],
                ["Partners", region ? region.partners : ["Riyadh", "Cairo", "Toronto", "Brisbane"]],
              ] as [string, string[]][]
            ).map(([title, list]) => (
              <div key={title} className="rops-points-group">
                <h4>
                  {title}
                  <span>{String(list.length).padStart(2, "0")}</span>
                </h4>
                <p>{list.join(" · ")}</p>
              </div>
            ))}
            <p className="rops-footnote">
              <Globe2 size={13} aria-hidden="true" /> Coverage varies by lane — our team confirms availability for your
              route.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
