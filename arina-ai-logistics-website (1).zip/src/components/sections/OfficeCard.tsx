import { ArrowRight, MapPin } from "lucide-react";
import { project, WORLD_DOTS_PATH } from "./world-dots";
import { arcPath, pointXY } from "./network-static";

/* ---------------------------------------------------------------
   Section 4 — Regional Office / Location Card
   Static frontend component (not connected to the Content Editor).
--------------------------------------------------------------- */

const OFFICE = {
  name: "Dubai Office",
  country: "Dubai, United Arab Emirates",
  address: ["Harbour Gate Tower, Level 14", "Jebel Ali Free Zone, Dubai", "United Arab Emirates"],
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=Jebel+Ali+Free+Zone+Dubai",
  lon: 55.27,
  lat: 25.2,
};

const SEA = "#3fd9cb";
const LAND = "rgba(140,175,205,0.34)";

/** Cropped, map-style illustration centred on the office. */
function OfficeMapVisual() {
  const [cx, cy] = project(OFFICE.lon, OFFICE.lat);
  const w = 400;
  const h = 230;
  const x = cx - w * 0.5;
  const y = cy - h * 0.5;
  const office = pointXY.dubai;
  const nearby = [pointXY.riyadh, pointXY.jeddah, pointXY.mumbai].filter(Boolean) as [number, number][];

  return (
    <svg
      viewBox={`${x} ${y} ${w} ${h}`}
      className="office-map-svg"
      role="img"
      aria-label="Map illustration showing the Dubai office location in the Gulf region"
    >
      <rect x={x} y={y} width={w} height={h} fill="transparent" />
      <path d={WORLD_DOTS_PATH} fill="none" stroke={LAND} strokeWidth={2.7} strokeLinecap="round" />

      {/* regional links */}
      <path d={arcPath(nearby[2], office, 0.3)} fill="none" stroke={SEA} strokeOpacity={0.5} strokeWidth={1.2} strokeDasharray="3 5" />
      <path d={arcPath(office, nearby[0], 0.3)} fill="none" stroke={SEA} strokeOpacity={0.5} strokeWidth={1.2} strokeDasharray="3 5" />
      <path d={arcPath(office, nearby[1], 0.24)} fill="none" stroke={SEA} strokeOpacity={0.45} strokeWidth={1.2} strokeDasharray="3 5" />

      {/* office marker */}
      <circle cx={office[0]} cy={office[1]} r={16} fill={SEA} opacity={0.12} className="rmap-pulse" />
      <circle cx={office[0]} cy={office[1]} r={9} fill={SEA} opacity={0.22} />
      <path
        d="M0 -13 l2.6 8.2 8.3 0 -6.7 4.9 2.6 8.2 -6.8 -4.9 -6.8 4.9 2.6 -8.2 -6.7 -4.9 8.3 0 z"
        fill="#d8f4ef"
        opacity={0.95}
        transform={`translate(${office[0]} ${office[1]}) scale(0.85)`}
      />
    </svg>
  );
}

export function OfficeCard() {
  return (
    <section className="office section-pad" aria-labelledby="office-title">
      <div className="container">
        <div className="section-heading office-head">
          <p className="eyebrow">
            <span className="eyebrow-line" />
            Regional offices
          </p>
          <h2 id="office-title">On the ground where your cargo moves</h2>
          <p>Local teams, local knowledge — the people accountable for your shipments in every region we serve.</p>
        </div>

        <article className="office-card">
          <div className="office-body">
            <p className="office-kicker">
              <span className="eyebrow-line" />
              {OFFICE.name}
            </p>
            <h3>{OFFICE.country}</h3>
            <address className="office-address">
              {OFFICE.address.map((line) => (
                <span key={line}>{line}</span>
              ))}
            </address>
            <a className="button button-teal office-button" href={OFFICE.mapsUrl} target="_blank" rel="noopener noreferrer">
              Open in Maps
              <ArrowRight size={17} strokeWidth={1.8} aria-hidden="true" />
            </a>
            <p className="office-note">
              <MapPin size={13} aria-hidden="true" />
              Regional hub for the Middle East, Africa and South Asia
            </p>
          </div>

          <div className="office-map">
            <OfficeMapVisual />
            <p className="office-map-tag">25.27° N · 55.27° E</p>
          </div>
        </article>
      </div>
    </section>
  );
}
