import { MAP_HEIGHT, MAP_WIDTH, project } from "./world-dots";

/**
 * Static frontend data for the network showcase sections.
 * Intentionally NOT wired to the Content Editor — these sections are
 * code-owned visual components.
 */

export type PointKind = "office" | "port" | "airport" | "partner";
export type RegionId = "all" | "asia" | "europe" | "middle-east" | "north-america" | "africa" | "australia";
export type RegionKey = Exclude<RegionId, "all">;

export interface NetPoint {
  id: string;
  name: string;
  region: RegionKey;
  kind: PointKind;
  lon: number;
  lat: number;
  label?: "t" | "b" | "l" | "r";
  /** Show a city label on the map when its region is selected */
  feature?: boolean;
}

export interface NetRoute {
  from: string;
  to: string;
  mode: "sea" | "air";
}

export interface RegionInfo {
  id: RegionKey;
  name: string;
  blurb: string;
  destinations: string[];
  modes: ("Ocean" | "Air" | "Road" | "Rail")[];
  services: string[];
  offices: string[];
  ports: string[];
  airports: string[];
  partners: string[];
  /** lon/lat bounding boxes used to highlight the region on the map */
  boxes: [number, number, number, number][];
  labelAt: [number, number];
}

export const POINT_KIND_LABEL: Record<PointKind, string> = {
  office: "Office",
  port: "Port",
  airport: "Airport",
  partner: "Partner",
};

export const points: NetPoint[] = [
  // Offices
  { id: "dubai", name: "Dubai", region: "middle-east", kind: "office", lon: 55.27, lat: 25.2, label: "t", feature: true },
  { id: "mumbai", name: "Mumbai", region: "asia", kind: "office", lon: 72.88, lat: 19.07, label: "b", feature: true },
  { id: "shanghai", name: "Shanghai", region: "asia", kind: "office", lon: 121.47, lat: 31.23, label: "t", feature: true },
  { id: "singapore", name: "Singapore", region: "asia", kind: "office", lon: 103.82, lat: 1.35, label: "b", feature: true },
  { id: "rotterdam", name: "Rotterdam", region: "europe", kind: "office", lon: 4.48, lat: 51.92, label: "b", feature: true },
  { id: "hamburg", name: "Hamburg", region: "europe", kind: "office", lon: 9.99, lat: 53.55, label: "r", feature: true },
  { id: "london", name: "London", region: "europe", kind: "office", lon: -0.13, lat: 51.51, label: "l", feature: true },
  { id: "newyork", name: "New York", region: "north-america", kind: "office", lon: -74, lat: 40.71, label: "r", feature: true },
  { id: "johannesburg", name: "Johannesburg", region: "africa", kind: "office", lon: 28.05, lat: -26.2, label: "l", feature: true },
  { id: "sydney", name: "Sydney", region: "australia", kind: "office", lon: 151.2, lat: -33.87, label: "r", feature: true },
  // Ports
  { id: "durban", name: "Durban", region: "africa", kind: "port", lon: 31.02, lat: -29.86, label: "r", feature: true },
  { id: "mombasa", name: "Mombasa", region: "africa", kind: "port", lon: 39.67, lat: -4.05, label: "r" },
  { id: "lagos", name: "Lagos", region: "africa", kind: "port", lon: 3.38, lat: 6.45, label: "b" },
  { id: "jeddah", name: "Jeddah", region: "middle-east", kind: "port", lon: 39.17, lat: 21.49, label: "l", feature: true },
  { id: "colombo", name: "Colombo", region: "asia", kind: "port", lon: 79.86, lat: 6.93, label: "b", feature: true },
  { id: "busan", name: "Busan", region: "asia", kind: "port", lon: 129.04, lat: 35.1, label: "r", feature: true },
  { id: "losangeles", name: "Los Angeles", region: "north-america", kind: "port", lon: -118.24, lat: 33.74, label: "l", feature: true },
  { id: "houston", name: "Houston", region: "north-america", kind: "port", lon: -95.37, lat: 29.76, label: "b" },
  { id: "melbourne", name: "Melbourne", region: "australia", kind: "port", lon: 144.96, lat: -37.81, label: "r", feature: true },
  // Airports
  { id: "frankfurt", name: "Frankfurt", region: "europe", kind: "airport", lon: 8.57, lat: 50.03, label: "r" },
  { id: "hongkong", name: "Hong Kong", region: "asia", kind: "airport", lon: 114.17, lat: 22.31, label: "b", feature: true },
  { id: "tokyo", name: "Tokyo", region: "asia", kind: "airport", lon: 139.69, lat: 35.68, label: "r", feature: true },
  { id: "chicago", name: "Chicago", region: "north-america", kind: "airport", lon: -87.63, lat: 41.88, label: "t" },
  { id: "nairobi", name: "Nairobi", region: "africa", kind: "airport", lon: 36.82, lat: -1.29, label: "l" },
  // Partners
  { id: "riyadh", name: "Riyadh", region: "middle-east", kind: "partner", lon: 46.68, lat: 24.71, label: "l" },
  { id: "cairo", name: "Cairo", region: "africa", kind: "partner", lon: 31.24, lat: 30.04, label: "t" },
  { id: "casablanca", name: "Casablanca", region: "africa", kind: "partner", lon: -7.59, lat: 33.57, label: "l" },
  { id: "toronto", name: "Toronto", region: "north-america", kind: "partner", lon: -79.38, lat: 43.65, label: "t" },
  { id: "mexico", name: "Mexico City", region: "north-america", kind: "partner", lon: -99.13, lat: 19.43, label: "b" },
  { id: "brisbane", name: "Brisbane", region: "australia", kind: "partner", lon: 153.03, lat: -27.47, label: "r" },
  { id: "perth", name: "Perth", region: "australia", kind: "partner", lon: 115.86, lat: -31.95, label: "l" },
];

export const routes: NetRoute[] = [
  // Shipping lanes (ocean)
  { from: "shanghai", to: "singapore", mode: "sea" },
  { from: "singapore", to: "mumbai", mode: "sea" },
  { from: "mumbai", to: "dubai", mode: "sea" },
  { from: "dubai", to: "rotterdam", mode: "sea" },
  { from: "rotterdam", to: "newyork", mode: "sea" },
  { from: "singapore", to: "sydney", mode: "sea" },
  { from: "dubai", to: "durban", mode: "sea" },
  { from: "losangeles", to: "shanghai", mode: "sea" },
  // Air corridors
  { from: "dubai", to: "london", mode: "air" },
  { from: "dubai", to: "shanghai", mode: "air" },
  { from: "london", to: "newyork", mode: "air" },
  { from: "johannesburg", to: "dubai", mode: "air" },
  { from: "newyork", to: "losangeles", mode: "air" },
  { from: "hongkong", to: "sydney", mode: "air" },
];

export const regionOrder: RegionId[] = [
  "all",
  "asia",
  "europe",
  "middle-east",
  "north-america",
  "africa",
  "australia",
];

export const regionLabelName: Record<RegionId, string> = {
  all: "All Regions",
  asia: "Asia",
  europe: "Europe",
  "middle-east": "Middle East",
  "north-america": "North America",
  africa: "Africa",
  australia: "Australia",
};

export const regions: RegionInfo[] = [
  {
    id: "asia",
    name: "Asia",
    blurb:
      "Our Asian gateways connect the world's largest manufacturing base to every major trade lane, with consolidation, customs and distribution on the ground.",
    destinations: ["Shanghai", "Singapore", "Mumbai", "Hong Kong", "Busan", "Tokyo", "Colombo"],
    modes: ["Ocean", "Air", "Road", "Rail"],
    services: ["FCL & LCL consolidation", "Origin pickup and export customs", "Eurasian rail programmes", "Warehousing & distribution"],
    offices: ["Shanghai", "Singapore", "Mumbai"],
    ports: ["Colombo", "Busan"],
    airports: ["Hong Kong", "Tokyo"],
    partners: ["Ho Chi Minh City", "Jakarta"],
    boxes: [[63, -12, 180, 78]],
    labelAt: [95, 51],
  },
  {
    id: "europe",
    name: "Europe",
    blurb:
      "Deep-water ports, major air hubs and dense road and rail links give us reliable reach across the continent and into its industrial heartland.",
    destinations: ["Rotterdam", "Hamburg", "London", "Frankfurt", "Milan", "Duisburg"],
    modes: ["Ocean", "Air", "Road", "Rail"],
    services: ["Port-to-door distribution", "Cross-border road haulage", "Customs clearance", "Bonded warehousing"],
    offices: ["Rotterdam", "Hamburg", "London"],
    ports: ["Rotterdam", "Hamburg"],
    airports: ["Frankfurt"],
    partners: ["Milan", "Duisburg"],
    boxes: [[-25, 36, 63, 75]],
    labelAt: [13, 60],
  },
  {
    id: "middle-east",
    name: "Middle East",
    blurb:
      "Headquartered in Dubai, we operate the region's key gateways and connect Asia, Europe and Africa through fast, well-served Gulf corridors.",
    destinations: ["Dubai (Jebel Ali)", "Riyadh", "Jeddah", "Doha", "Abu Dhabi"],
    modes: ["Ocean", "Air", "Road"],
    services: ["Free-zone warehousing", "Transshipment and re-export", "Customs & permits", "Regional trucking"],
    offices: ["Dubai"],
    ports: ["Jebel Ali", "Jeddah"],
    airports: ["Dubai World Central"],
    partners: ["Riyadh", "Doha"],
    boxes: [[34, 12, 63, 36]],
    labelAt: [48, 20],
  },
  {
    id: "north-america",
    name: "North America",
    blurb:
      "Coast-to-coast coverage with gateway ports, air hubs and rail ramps serving the world's largest consumer market.",
    destinations: ["New York / New Jersey", "Los Angeles", "Houston", "Chicago", "Toronto"],
    modes: ["Ocean", "Air", "Road", "Rail"],
    services: ["Import and export forwarding", "Intermodal rail & drayage", "E-commerce fulfilment", "Customs brokerage"],
    offices: ["New York"],
    ports: ["Los Angeles", "Houston"],
    airports: ["Chicago"],
    partners: ["Toronto", "Mexico City"],
    boxes: [[-170, 5, -50, 83]],
    labelAt: [-100, 49],
  },
  {
    id: "africa",
    name: "Africa",
    blurb:
      "Trusted partners and our own team on the ground for fast-growing markets on the east, west and south coasts.",
    destinations: ["Johannesburg", "Durban", "Lagos", "Nairobi", "Mombasa", "Cairo"],
    modes: ["Ocean", "Air", "Road"],
    services: ["Project and mining logistics", "Cross-border road corridors", "Clearance and inland delivery", "Warehousing"],
    offices: ["Johannesburg"],
    ports: ["Durban", "Mombasa", "Lagos"],
    airports: ["Nairobi"],
    partners: ["Cairo", "Casablanca"],
    boxes: [
      [-20, -36, 34, 37],
      [34, -36, 52, 12],
    ],
    labelAt: [18, 5],
  },
  {
    id: "australia",
    name: "Australia",
    blurb:
      "Reliable ocean and air links to Australia's major ports, with local clearance, quarantine-compliant handling and inland distribution.",
    destinations: ["Sydney", "Melbourne", "Brisbane", "Perth"],
    modes: ["Ocean", "Air", "Road"],
    services: ["Import and export forwarding", "Quarantine-compliant handling", "Customs clearance", "Regional distribution"],
    offices: ["Sydney"],
    ports: ["Melbourne"],
    airports: ["Sydney"],
    partners: ["Brisbane", "Perth"],
    boxes: [[110, -50, 180, -9]],
    labelAt: [133, -25],
  },
];

export const regionLabelPositions: { id: RegionKey; name: string; lon: number; lat: number }[] = regions.map((r) => ({
  id: r.id,
  name: r.name.toUpperCase(),
  lon: r.labelAt[0],
  lat: r.labelAt[1],
}));

/** Projected coordinates for every network point. */
export const pointXY: Record<string, [number, number]> = Object.fromEntries(
  points.map((p) => [p.id, project(p.lon, p.lat)]),
);

/** Projected rectangles used to highlight one region's landmass. */
export const regionRects: Record<RegionKey, { x: number; y: number; width: number; height: number }[]> =
  Object.fromEntries(
    regions.map((r) => [
      r.id,
      r.boxes.map(([lonMin, latMin, lonMax, latMax]) => {
        const [x1, y1] = project(lonMin, latMax);
        const [x2, y2] = project(lonMax, latMin);
        return { x: x1, y: y1, width: x2 - x1, height: y2 - y1 };
      }),
    ]),
  ) as Record<RegionKey, { x: number; y: number; width: number; height: number }[]>;

/** Quadratic great-circle style arc between two projected points. */
export function arcPath(a: [number, number], b: [number, number], lift: number): string {
  const [x1, y1] = a;
  const [x2, y2] = b;
  const dist = Math.hypot(x2 - x1, y2 - y1);
  const cx = (x1 + x2) / 2;
  const cy = (y1 + y2) / 2 - dist * lift;
  return `M${Math.round(x1 * 10) / 10} ${Math.round(y1 * 10) / 10} Q${Math.round(cx * 10) / 10} ${Math.round(cy * 10) / 10} ${Math.round(x2 * 10) / 10} ${Math.round(y2 * 10) / 10}`;
}

export const routeShapes = routes.map((r) => ({
  ...r,
  d: arcPath(pointXY[r.from], pointXY[r.to], r.mode === "air" ? 0.3 : 0.17),
}));

export { MAP_WIDTH, MAP_HEIGHT };
