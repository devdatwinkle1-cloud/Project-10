import { useId } from "react";
import { MAP_HEIGHT, MAP_WIDTH, project, WORLD_DOTS_PATH } from "./world-dots";
import {
  POINT_KIND_LABEL,
  pointXY,
  points,
  regionLabelPositions,
  routeShapes,
  type PointKind,
} from "./network-static";

/* ------------------------------------------------------------------
   Home page Global Network map visual.
   Static frontend component — intentionally not connected to the CMS.
   Replaces only the old map underneath the existing section heading.
------------------------------------------------------------------- */

const CYAN = "#41e3d5";
const CYAN_SOFT = "#89f0e7";
const AIR = "#dcecf2";
const LAND = "rgba(113, 164, 198, 0.43)";
const NAVY = "#061726";

function PointShape({ kind, x, y }: { kind: PointKind; x: number; y: number }) {
  switch (kind) {
    case "office":
      return (
        <>
          <circle className="gnm-point-pulse" cx={x} cy={y} r={4.6} fill={CYAN} opacity={0.2} />
          <circle cx={x} cy={y} r={5.2} fill="none" stroke={CYAN} strokeOpacity={0.35} strokeWidth={1.3} />
          <circle cx={x} cy={y} r={2.8} fill={CYAN} />
        </>
      );
    case "port":
      return <rect x={x - 2.7} y={y - 2.7} width={5.4} height={5.4} rx={0.8} fill="#eef7f8" stroke={NAVY} strokeWidth={0.9} />;
    case "airport":
      return (
        <rect
          x={x - 2.5}
          y={y - 2.5}
          width={5}
          height={5}
          fill={NAVY}
          stroke="#dcecf2"
          strokeWidth={1.2}
          transform={`rotate(45 ${x} ${y})`}
        />
      );
    default:
      return <circle cx={x} cy={y} r={2.6} fill={NAVY} stroke="#bcd2dc" strokeWidth={1.2} />;
  }
}

function LegendSymbol({ kind }: { kind: PointKind }) {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" aria-hidden="true" focusable="false">
      <PointShape kind={kind} x={6.5} y={6.5} />
    </svg>
  );
}

export function GlobalNetworkMapVisual() {
  const uid = useId().replace(/:/g, "");
  const glowId = `gnm-glow-${uid}`;
  const routeGlowId = `gnm-route-glow-${uid}`;

  return (
    <>
      <figure className="rmap-card gnm-card">
        <div className="gnm-grid" aria-hidden="true" />
        <div className="rmap-scroll gnm-scroll">
          <svg
            viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
            className="rmap-svg gnm-svg"
            role="img"
            aria-label="Dotted world map showing Arina offices, ports, airports and partners connected by international shipping and air routes"
          >
            <defs>
              <filter id={glowId} x="-300%" y="-300%" width="700%" height="700%">
                <feGaussianBlur stdDeviation="3.4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id={routeGlowId} x="-20%" y="-80%" width="140%" height="260%">
                <feGaussianBlur stdDeviation="1.35" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Large, precise dotted continents */}
            <path d={WORLD_DOTS_PATH} fill="none" stroke={LAND} strokeWidth={2.5} strokeLinecap="round" />

            {/* International ocean and air connections */}
            <g fill="none" strokeLinecap="round">
              {routeShapes
                .filter((route) => route.mode === "sea")
                .map((route, index) => (
                  <path
                    key={`sea-${route.from}-${route.to}`}
                    d={route.d}
                    stroke={index < 5 ? CYAN : CYAN_SOFT}
                    strokeWidth={index < 5 ? 1.65 : 1.3}
                    strokeOpacity={index < 5 ? 0.9 : 0.58}
                    filter={`url(#${routeGlowId})`}
                  />
                ))}
              {routeShapes
                .filter((route) => route.mode === "air")
                .map((route) => (
                  <path
                    key={`air-${route.from}-${route.to}`}
                    d={route.d}
                    stroke={AIR}
                    strokeWidth={1.05}
                    strokeOpacity={0.62}
                    strokeDasharray="2 6"
                  />
                ))}

              {/* Subtle moving lights show direction without distracting */}
              <g className="gnm-route-motion">
                {routeShapes.map((route, index) => (
                  <circle
                    key={`motion-${route.from}-${route.to}`}
                    r={route.mode === "sea" ? 2.3 : 1.65}
                    fill={route.mode === "sea" ? CYAN_SOFT : "#eef7f8"}
                    filter={`url(#${glowId})`}
                  >
                    <animateMotion
                      dur={`${9.5 + (index % 5) * 1.75}s`}
                      begin={`-${(index * 1.65) % 9}s`}
                      repeatCount="indefinite"
                      path={route.d}
                    />
                  </circle>
                ))}
              </g>
            </g>

            {/* Offices, ports, airports and partners */}
            <g>
              {points.map((point) => {
                const [x, y] = pointXY[point.id];
                return (
                  <g key={point.id} filter={point.kind === "office" ? `url(#${glowId})` : undefined}>
                    <PointShape kind={point.kind} x={x} y={y} />
                    <title>{`${point.name} — ${POINT_KIND_LABEL[point.kind]}`}</title>
                  </g>
                );
              })}
            </g>

            {/* Region labels requested in the reference */}
            <g fontSize={9.5} fontWeight={700} letterSpacing={2.3} pointerEvents="none">
              {regionLabelPositions.map((region) => {
                const [x, y] = project(region.lon, region.lat);
                return (
                  <text
                    key={region.id}
                    x={x}
                    y={y}
                    textAnchor="middle"
                    fill="#e6f3f6"
                    fillOpacity={0.9}
                    stroke={NAVY}
                    strokeWidth={3.4}
                    paintOrder="stroke"
                  >
                    {region.name}
                  </text>
                );
              })}
            </g>
          </svg>
        </div>

        <figcaption className="rmap-legend gnm-legend">
          <ul>
            {(["office", "port", "airport", "partner"] as PointKind[]).map((kind) => (
              <li key={kind}>
                <LegendSymbol kind={kind} />
                {POINT_KIND_LABEL[kind]}
              </li>
            ))}
            <li>
              <svg width="27" height="8" viewBox="0 0 27 8" aria-hidden="true">
                <line x1="1" y1="4" x2="26" y2="4" stroke={CYAN} strokeWidth="1.8" strokeLinecap="round" />
              </svg>
              Shipping route
            </li>
            <li>
              <svg width="27" height="8" viewBox="0 0 27 8" aria-hidden="true">
                <line x1="1" y1="4" x2="26" y2="4" stroke={AIR} strokeWidth="1.4" strokeDasharray="2 5" strokeLinecap="round" />
              </svg>
              Air route
            </li>
          </ul>
          <p className="rmap-note">Illustrative routes · Key network points shown</p>
        </figcaption>
      </figure>

      <p className="rmap-hint gnm-hint" aria-hidden="true">
        Swipe to explore the global network →
      </p>
    </>
  );
}
