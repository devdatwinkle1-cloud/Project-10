/* ---------------------------------------------------------------
   Section 2 — Company Journey / Milestones
   Static frontend component (not connected to the Content Editor).
--------------------------------------------------------------- */

const milestones = [
  {
    year: "2013",
    title: "Founded in Mumbai",
    text: "Arina begins as a freight-forwarding desk serving exporters on the India–Gulf corridor.",
  },
  {
    year: "2016",
    title: "Gulf Headquarters",
    text: "Dubai becomes our regional hub, opening lanes between Asia, the Middle East, Europe and Africa.",
  },
  {
    year: "2018",
    title: "Air Freight & Customs",
    text: "We add air freight capacity and an in-house customs brokerage team.",
  },
  {
    year: "2020",
    title: "Warehousing & Distribution",
    text: "Bonded and free-zone warehousing launches to support end-to-end supply chain programmes.",
  },
  {
    year: "2023",
    title: "Shipment Visibility",
    text: "Digital documentation and tracking give customers clearer visibility from pickup to delivery.",
  },
  {
    year: "2025",
    title: "10+ Countries",
    text: "Our network reaches ten countries, with partners across six regions.",
  },
];

export function CompanyMilestones() {
  return (
    <section className="mstone section-pad" aria-labelledby="mstone-title">
      <div className="container">
        <div className="section-heading mstone-head">
          <p className="eyebrow">
            <span className="eyebrow-line" />
            Milestones
            <span className="eyebrow-line" />
          </p>
          <h2 id="mstone-title">Our journey so far</h2>
          <p>From a single forwarding desk in Mumbai to a connected network across six regions.</p>
        </div>

        <ol className="mstone-list">
          {milestones.map((m, i) => (
            <li key={m.year} className={`mstone-item ${i % 2 === 0 ? "is-left" : "is-right"}`}>
              <div className="mstone-card">
                <p className="mstone-year">{m.year}</p>
                <h3>{m.title}</h3>
                <p className="mstone-text">{m.text}</p>
              </div>
              <span className="mstone-node" aria-hidden="true" />
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
