"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowUpRight, ChevronRight, Menu, X, MapPin, Phone, Mail } from "lucide-react";
import { useContent, FormattedText } from "@/context/content-context";
import { getIconComponent } from "@/lib/icon-map";
import { BannerAsset, ImageAsset, RegionItem } from "@/lib/cms-types";
import { bannerStyle } from "@/lib/media";

/** Renders a section image only when a source is set; alt text comes from the CMS. */
export function CmsImage({ image, fallbackAlt, loading = "lazy" }: { image?: ImageAsset; fallbackAlt: string; loading?: "lazy" | "eager" }) {
  const src = image?.src?.trim();
  if (!src) return null;
  return <img src={src} alt={image?.alt?.trim() || fallbackAlt} loading={loading} />;
}

export function ButtonLink({
  href,
  children,
  variant = "primary",
  className = "",
}: {
  href: string;
  children: React.ReactNode;
  variant?: "primary" | "outline" | "light" | "text";
  className?: string;
}) {
  return (
    <Link href={href} className={`button button-${variant} ${className}`}>
      {children}
      <ArrowUpRight size={17} strokeWidth={1.8} />
    </Link>
  );
}

export function Brand({ light = false }: { light?: boolean }) {
  const { global } = useContent();
  const branding = global.branding;
  const showText = branding?.showBrandText !== false;

  // Preferred logo for the current *tone* (light = over-hero/transparent header, footer).
  const toneLogo = light && branding?.logoLight?.src ? branding.logoLight : branding?.logo;
  const hasToneLogo = !!toneLogo?.src;
  const hasMobile = !!branding?.logoMobile?.src;
  const hasAny = hasToneLogo || (!light && hasMobile);

  return (
    <Link href="/" className={`brand ${light ? "brand-light" : ""}`} aria-label={`${global.companyName} home`}>
      {hasAny ? (
        <>
          {hasToneLogo && (
            <>
              {/* Desktop-sized logo (hidden below 760px when a dedicated mobile logo exists) */}
              <span className={`brand-logo ${hasMobile ? "brand-logo-desktop" : ""}`}>
                <img src={toneLogo.src} alt={toneLogo.alt || global.companyName} />
              </span>
            </>
          )}
          {hasMobile && (
            <>
              {/* Mobile-sized logo (only shown below 760px, takes priority in every context) */}
              <span className="brand-logo brand-logo-mobile">
                <img src={branding.logoMobile.src} alt={branding.logoMobile.alt || toneLogo?.alt || global.companyName} />
              </span>
            </>
          )}
        </>
      ) : (
        <span className="brand-symbol">
          <span />
          <span />
          <span />
        </span>
      )}
      {showText && (
      <span className="brand-copy">
        <strong>
          {global.companyName}
          <span className="brand-dot">.</span>
        </strong>
        <small>{global.companySubtitle}</small>
      </span>
      )}
    </Link>
  );
}

const defaultNav = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Solutions", href: "/solutions" },
  { label: "Global Network", href: "/global-network" },
  { label: "Tracking", href: "/tracking" },
  { label: "Contact", href: "/contact" },
];

export function Header() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { global } = useContent();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 36);
    handler();
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => setOpen(false), [path]);

  const heroPage = path === "/";
  const navItems = global.navigation && global.navigation.length > 0 ? global.navigation : defaultNav;
  // If navigating in admin mode, hide sticky header or allow header
  const isCmsEditor = path.startsWith("/admin") || path.startsWith("/editor");
  if (isCmsEditor) return null;

  return (
    <header className={`header ${scrolled || !heroPage || open ? "header-solid" : "header-transparent"}`}>
      <div className="container header-inner">
        <Brand light={!scrolled && heroPage && !open} />
        <nav className="desktop-nav" aria-label="Main navigation">
          {navItems.map((n, i) => (
            <Link key={`${n.href}-${i}`} className={path === n.href ? "nav-active" : ""} href={n.href}>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="header-actions">
          <Link href="/tracking" className="header-track">
            {global.headerTrackButton} <ArrowUpRight size={15} />
          </Link>
          <ButtonLink href="/quote" className="header-quote">
            {global.headerQuoteButton}
          </ButtonLink>
        </div>
        <div className="mobile-actions">
          <Link href="/tracking" className="mobile-track">
            {global.headerTrackButton}
          </Link>
          <button
            className="menu-toggle"
            onClick={() => setOpen(!open)}
            aria-label={open ? "Close navigation" : "Open navigation"}
            aria-expanded={open}
          >
            {open ? <X size={25} /> : <Menu size={25} />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="mobile-nav" aria-label="Mobile navigation">
          {navItems.map((n, i) => (
            <Link key={`${n.href}-${i}`} href={n.href} className={path === n.href ? "nav-active" : ""}>
              {n.label}
              <ArrowUpRight size={17} />
            </Link>
          ))}
          <Link href="/quote" className="mobile-quote">
            {global.headerQuoteButton} <ArrowUpRight size={17} />
          </Link>
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  const path = usePathname();
  const { global, services, solutions } = useContent();
  const headings = global.footerHeadings;
  const isCmsEditor = path.startsWith("/admin") || path.startsWith("/editor");
  if (isCmsEditor) return null;

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div className="footer-intro">
            <Brand light />
            <p>
              <FormattedText text={global.footerMission} />
            </p>
            <div className="socials">
              <a href={global.socialLinks.linkedin || "https://linkedin.com"} aria-label="LinkedIn" target="_blank" rel="noreferrer">
                in
              </a>
              <a href={global.socialLinks.instagram || "https://instagram.com"} aria-label="Instagram" target="_blank" rel="noreferrer">
                ig
              </a>
              <a href={global.socialLinks.facebook || "https://facebook.com"} aria-label="Facebook" target="_blank" rel="noreferrer">
                f
              </a>
            </div>
          </div>
          <div className="footer-links">
            <h4>{headings?.company || "Company"}</h4>
            <Link href="/about">About Us</Link>
            <Link href="/global-network">Global Network</Link>
            <Link href="/contact">Careers</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/admin" className="text-amber-400 font-semibold opacity-80 hover:opacity-100 transition-opacity">
              CMS Editor ↗
            </Link>
          </div>
          <div className="footer-links">
            <h4>{headings?.services || "Services"}</h4>
            {services.items.map((s) => (
              <Link key={s.slug} href={`/services#${s.slug}`}>
                {s.title}
              </Link>
            ))}
          </div>
          <div className="footer-links">
            <h4>{headings?.solutions || "Solutions"}</h4>
            {solutions.items
              .filter((s) => ["freight-forwarding", "supply-chain", "project-cargo", "ecommerce-logistics"].includes(s.slug))
              .map((s) => (
                <Link key={s.slug} href={`/solutions#${s.slug}`}>
                  {s.title.replace("International ", "")}
                </Link>
              ))}
          </div>
          <div className="footer-links">
            <h4>{headings?.support || "Support"}</h4>
            <Link href="/tracking">{global.headerTrackButton}</Link>
            <Link href="/quote">{global.headerQuoteButton}</Link>
            <Link href="/contact#faq">FAQ</Link>
            <Link href="/contact">Contact</Link>
          </div>
          <div className="footer-links footer-contact">
            <h4>{headings?.contact || "Contact"}</h4>
            <span>
              <MapPin size={16} />
              <FormattedText text={global.address} />
            </span>
            <a href={`tel:${global.phone.replace(/[^0-9+]/g, "")}`}>
              <Phone size={16} /> {global.phone}
            </a>
            <a href={`mailto:${global.email}`}>
              <Mail size={16} /> {global.email}
            </a>
          </div>
        </div>
        <div className="footer-bottom">
          <span>{global.copyright}</span>
          <div>
            <Link href="/privacy">Privacy Policy</Link>
            <Link href="/terms">Terms & Conditions</Link>
            <Link href="/cookies">Cookie Policy</Link>
          </div>
          <span>{global.footerBottomTagline}</span>
        </div>
      </div>
    </footer>
  );
}

export function Eyebrow({ children, light = false }: { children: React.ReactNode; light?: boolean }) {
  return (
    <div className={`eyebrow ${light ? "eyebrow-light" : ""}`}>
      <span className="eyebrow-line" />
      {children}
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  light = false,
  centered = false,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  light?: boolean;
  centered?: boolean;
}) {
  return (
    <div className={`section-heading ${centered ? "centered" : ""}`}>
      <Eyebrow light={light}>{eyebrow}</Eyebrow>
      <h2>
        <FormattedText text={title} />
      </h2>
      {description && (
        <p>
          <FormattedText text={description} />
        </p>
      )}
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  image,
  indexLabel1 = "ARINA / GLOBAL LOGISTICS",
  indexLabel2 = "CONNECTED BEYOND BORDERS",
}: {
  eyebrow: string;
  title: string;
  description: string;
  image: BannerAsset;
  indexLabel1?: string;
  indexLabel2?: string;
}) {
  return (
    <section
      className="page-hero"
      style={bannerStyle(image, "linear-gradient(90deg, rgba(5,24,38,.92) 0%, rgba(5,24,38,.67) 55%, rgba(5,24,38,.42) 100%)")}
    >
      <div className="container page-hero-content">
        <Eyebrow light>{eyebrow}</Eyebrow>
        <h1>
          <FormattedText text={title} />
        </h1>
        <p>
          <FormattedText text={description} />
        </p>
      </div>
      <div className="page-hero-index container">
        <span>{indexLabel1}</span>
        <span>{indexLabel2}</span>
      </div>
    </section>
  );
}

export function ServiceGrid() {
  const { services } = useContent();
  return (
    <div className="service-grid">
      {services.items.map((s, i) => {
        const IconComponent = getIconComponent(s.icon);
        return (
          <Link href={`/services#${s.slug}`} className="service-card" key={s.slug}>
            <div className="service-card-top">
              <span className="service-icon">
                <IconComponent size={29} strokeWidth={1.45} />
              </span>
              <span className="card-number">0{i + 1}</span>
            </div>
            <h3>
              <FormattedText text={s.title} />
            </h3>
            <p>
              <FormattedText text={s.shortDescription} />
            </p>
            <span className="card-link">
              Learn More <ArrowUpRight size={17} />
            </span>
          </Link>
        );
      })}
    </div>
  );
}

export function SolutionGrid({ limit }: { limit?: number }) {
  const { solutions } = useContent();
  const items = limit ? solutions.items.slice(0, limit) : solutions.items;
  return (
    <div className="solution-grid">
      {items.map((s, i) => (
        <Link href={`/solutions#${s.slug}`} className={`solution-card ${i === 0 ? "solution-featured" : ""}`} key={s.slug}>
          <div className="solution-image">
            <CmsImage image={s.image} fallbackAlt={`${s.title} logistics`} />
          </div>
          <div className="solution-content">
            <span className="solution-index">SOLUTION / 0{i + 1}</span>
            <div>
              <h3>
                <FormattedText text={s.title} />
              </h3>
              <p>
                <FormattedText text={s.description} />
              </p>
              <span>
                Learn More <ArrowUpRight size={17} />
              </span>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

export function IndustryGrid() {
  const { industries } = useContent();
  return (
    <div className="industry-grid">
      {industries.map((s, i) => {
        const IconComponent = getIconComponent(s.icon);
        return (
          <Link href="/contact" className="industry-card" key={s.title}>
            <CmsImage image={s.image} fallbackAlt={`${s.title} logistics operations`} />
            <div className="industry-cover" />
            <span className="industry-num">0{i + 1} / 0{industries.length}</span>
            <div className="industry-title">
              <IconComponent size={23} strokeWidth={1.5} />
              <h3>{s.title}</h3>
              <ArrowUpRight size={19} />
            </div>
          </Link>
        );
      })}
    </div>
  );
}

export function CtaBanner({ compact = false }: { compact?: boolean }) {
  const { home } = useContent();
  if (compact) {
    const c = home.compactCta;
    return (
      <section className="compact-cta">
        <div className="container compact-cta-inner">
          <div>
            <Eyebrow>{c.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={c.title} />
            </h2>
          </div>
          <ButtonLink href={c.buttonHref}>{c.buttonLabel}</ButtonLink>
        </div>
      </section>
    );
  }

  const l = home.largeCta;
  return (
    <section
      className="large-cta"
      style={bannerStyle(l.bgImage, "linear-gradient(90deg, rgba(5,24,38,.98) 0%, rgba(5,24,38,.88) 47%, rgba(5,24,38,.32) 100%)")}
    >
      <div className="container">
        <Eyebrow light>{l.eyebrow}</Eyebrow>
        <h2>
          <FormattedText text={l.title} />
        </h2>
        <p>
          <FormattedText text={l.description} />
        </p>
        <div className="button-row">
          <ButtonLink href={l.primaryButtonHref}>{l.primaryButton}</ButtonLink>
          <ButtonLink href={l.secondaryButtonHref} variant="outline">
            {l.secondaryButton}
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}

export function WhyChoose() {
  const { home } = useContent();
  const w = home.whyChooseSection;
  return (
    <section className="why-section section-pad">
      <div className="container">
        <div className="why-intro">
          <SectionHeading eyebrow={w.eyebrow} title={w.title} description={w.description} light />
          <div className="why-decoration">
            <span>{w.watermarkTop}</span>
            <strong>{w.watermarkBottom}</strong>
          </div>
        </div>
        <div className="features-grid">
          {w.features.map((f, i) => {
            const IconComponent = getIconComponent(f.icon);
            return (
              <div className="feature" key={f.title}>
                <span className="feature-number">0{i + 1} /</span>
                <IconComponent size={30} strokeWidth={1.4} />
                <h3>{f.title}</h3>
                <p>
                  <FormattedText text={f.description} />
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function Journey() {
  const { home } = useContent();
  const j = home.journeySection;
  return (
    <section className="journey section-pad">
      <div className="container">
        <SectionHeading eyebrow={j.eyebrow} title={j.title} description={j.description} />
        <div className="journey-steps">
          {j.steps.map((s) => {
            const IconComponent = getIconComponent(s.icon);
            return (
              <div className="journey-step" key={s.step}>
                <div className="journey-icon">
                  <IconComponent size={26} strokeWidth={1.5} />
                </div>
                <span className="journey-count">{s.step}</span>
                <h3>{s.label}</h3>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function NetworkMap({ interactive = false }: { interactive?: boolean }) {
  const { globalNetwork } = useContent();
  const [selected, setSelected] = useState(0);
  const r: RegionItem = globalNetwork.regions[selected] || globalNetwork.regions[0] || {
    name: "Asia",
    destinations: "Mumbai · Singapore · Shanghai · Tokyo",
    modes: "Ocean, Air, Road, Rail",
    services: "Freight forwarding, customs, distribution",
    pointX: 73,
    pointY: 48,
  };

  return (
    <div className={`network-layout ${interactive ? "network-interactive" : ""}`}>
      <div className="map-panel">
        <div className="map-grid" />
        <svg viewBox="0 0 1000 520" className="world-svg" role="img" aria-label="Stylized world map showing Arina global logistics connections">
          <g fill="#466174" opacity=".64">
            <path d="M84 112l40-23 41 7 29-15 61 9 27 25 44 2 12 28-26 24-32 7-18 30-35 1-17 28-35-9-22-33-28-9-12-29-35-7zM218 242l43 10 31 24 9 39 24 23-13 65-24 44-29 8-22-28-3-45-22-36-20-27 5-45zM433 107l38-24 48 10 34-18 48 6 17 22 58-16 55 15 61 1 53 30 25 40-17 24-48-4-27 28-46-4-27 26-48-11-40 20-25-27-43 4-19-32-34-4-18-30-30 2-16-31zM455 215l37-10 47 13 24 31 44 8 17 34-21 45-27 53-41 43-35-16-11-40-26-18-17-55-15-34zM789 325l31-22 53 7 27 32 17 34-31 27-58-6-37-32zM350 90l15-14 25 5-7 23-20 9zM906 387l8 9-6 11-11-7z" />
          </g>
          <g fill="none" stroke="#cfa074" strokeWidth="1.4" opacity=".58" strokeDasharray="5 7">
            <path d="M220 204 Q350 90 490 170 Q590 158 730 240" />
            <path d="M490 170 Q540 240 595 255 Q670 275 730 240" />
            <path d="M490 170 Q450 240 500 350" />
            <path d="M595 255 Q700 345 850 390" />
            <path d="M220 204 Q410 400 850 390" />
          </g>
        </svg>
        {globalNetwork.regions.map((region, i) => (
          <button
            title={region.name}
            aria-label={`Select ${region.name}`}
            onClick={() => setSelected(i)}
            key={region.name}
            style={{ left: `${region.pointX}%`, top: `${region.pointY}%` }}
            className={`map-point ${selected === i ? "selected" : ""}`}
          >
            <span />
          </button>
        ))}
        <div className="map-coordinate">{globalNetwork.mapSection.coordinateText}</div>
      </div>
      {interactive && (
        <div className="region-info">
          <span className="region-label">{globalNetwork.mapSection.selectRegionPrompt}</span>
          <div className="region-tabs">
            {globalNetwork.regions.map((region, i) => (
              <button key={region.name} onClick={() => setSelected(i)} className={i === selected ? "active" : ""}>
                {region.name}
                <ChevronRight size={16} />
              </button>
            ))}
          </div>
          <div className="region-details">
            <span>
              0{selected + 1} / 0{globalNetwork.regions.length} — NETWORK REGION
            </span>
            <h3>{r.name}</h3>
            <dl>
              <div>
                <dt>Major destinations</dt>
                <dd>{r.destinations}</dd>
              </div>
              <div>
                <dt>Transport modes</dt>
                <dd>{r.modes}</dd>
              </div>
              <div>
                <dt>Available services</dt>
                <dd>{r.services}</dd>
              </div>
            </dl>
            <p>Our network combines local knowledge and coordinated global reach. Contact our team for specific lane availability.</p>
          </div>
        </div>
      )}
    </div>
  );
}
