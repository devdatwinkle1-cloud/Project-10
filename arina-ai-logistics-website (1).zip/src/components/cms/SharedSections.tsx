"use client";

import React from "react";
import { Info, Monitor, Smartphone, Moon } from "lucide-react";
import type { SiteContent } from "@/lib/cms-types";
import { defaultSiteContent } from "@/lib/cms-defaults";
import { FieldWrapper } from "./FieldWrapper";
import { MediaField } from "./MediaField";
import { RichTextEditor } from "./RichTextEditor";

type EditorProps = {
  content: SiteContent;
  update: (path: string, value: unknown) => void;
};

/**
 * Header: logo, brand text, navigation labels and action buttons.
 * Rendered inside Home → "Header" and Global Settings → "Header" (same content keys).
 */
export function HeaderSectionFields({ content, update }: EditorProps) {
  const g = content.global;
  const branding = g.branding;
  return (
    <div className="space-y-5">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <Monitor size={13} className="text-amber-400" /> Company Logo
          </span>
          <span className="cms-key-badge-sub font-mono">global.branding.logo</span>
        </div>
        <MediaField
          label="Main Logo (Header & Mobile Header)"
          contentKey="global.branding.logo"
          variant="logo"
          hint="The central logo used in the Header (after scrolling and on inner pages), the Mobile header, and the Footer unless a dark-background logo is set. Displayed 33px tall, width auto (max 150px). PNG or SVG with transparency recommended. Leave empty to keep the built-in ARINA mark."
          value={branding.logo}
          defaultValue={defaultSiteContent.global.branding.logo}
          onChange={(val) => update("global.branding.logo", val)}
        />
        <div className="flex items-center gap-2 text-[10px] text-slate-500 -mt-2">
          <Info size={11} /> Shown everywhere the logo appears: header (all states), mobile header, and — if no dark-logo override is set — the footer.
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <Smartphone size={13} className="text-amber-400" /> Mobile Logo (optional, ≤760px)
          </span>
          <span className="cms-key-badge-sub font-mono">global.branding.logoMobile</span>
        </div>
        <MediaField
          label="Mobile Logo"
          contentKey="global.branding.logoMobile"
          variant="logo"
          hint="Optional. Shown in the header on screens up to 760px wide instead of the desktop logo (28px tall, max 120px wide). Use a compact/square version of your logo. Falls back to the desktop logo when empty."
          value={branding.logoMobile}
          defaultValue={defaultSiteContent.global.branding.logoMobile}
          onChange={(val) => update("global.branding.logoMobile", val)}
        />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <Moon size={13} className="text-amber-400" /> Dark-background Logo (optional)
          </span>
          <span className="cms-key-badge-sub font-mono">global.branding.logoLight</span>
        </div>
        <MediaField
          label="Dark-background Logo"
          contentKey="global.branding.logoLight"
          variant="logo"
          hint="Optional. Transparent header over the home hero and the footer use this while the background is dark. Falls back to the desktop logo when empty."
          value={branding.logoLight}
          defaultValue={defaultSiteContent.global.branding.logoLight}
          onChange={(val) => update("global.branding.logoLight", val)}
        />
      </div>

      <div className="cms-sub-card">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <label className="cms-toggle">
            <input
              type="checkbox"
              checked={branding.showBrandText !== false}
              onChange={(e) => update("global.branding.showBrandText", e.target.checked)}
            />
            Show company name &amp; subtitle beside the logo
          </label>
          <span className="cms-key-badge-sub font-mono">global.branding.showBrandText</span>
        </div>
        <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1.5">
          <Info size={12} /> Turn this off when your uploaded logo already contains the company name.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Company Name (brand text)" contentKey="global.companyName">
            <input type="text" value={g.companyName} onChange={(e) => update("global.companyName", e.target.value)} className="cms-input font-bold" />
          </FieldWrapper>
          <FieldWrapper label="Brand Subtitle" contentKey="global.companySubtitle">
            <input type="text" value={g.companySubtitle} onChange={(e) => update("global.companySubtitle", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </div>

      <div className="cms-sub-card">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">Navigation menu</span>
          <span className="cms-key-badge-sub font-mono">global.navigation</span>
        </div>
        <div className="space-y-2">
          {g.navigation.map((item, idx) => (
            <div key={idx} className="grid grid-cols-[2rem_1fr_1fr] gap-2 items-center">
              <span className="font-mono text-amber-400 font-bold text-xs">0{idx + 1}</span>
              <input
                type="text"
                value={item.label}
                onChange={(e) => update(`global.navigation.${idx}.label`, e.target.value)}
                className="cms-input"
                aria-label={`Menu item ${idx + 1} label`}
                title={`global.navigation[${idx}].label`}
              />
              <input
                type="text"
                value={item.href}
                onChange={(e) => update(`global.navigation.${idx}.href`, e.target.value)}
                className="cms-input font-mono text-xs"
                aria-label={`Menu item ${idx + 1} link`}
                title={`global.navigation[${idx}].href`}
              />
            </div>
          ))}
        </div>
        <p className="text-[10px] text-slate-500 mt-2">Labels appear in the desktop menu and the mobile menu. Links are internal paths such as /services.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FieldWrapper label="Track Shipment Button Label" contentKey="global.headerTrackButton">
          <input type="text" value={g.headerTrackButton} onChange={(e) => update("global.headerTrackButton", e.target.value)} className="cms-input" />
        </FieldWrapper>
        <FieldWrapper label="Get a Quote Button Label" contentKey="global.headerQuoteButton">
          <input type="text" value={g.headerQuoteButton} onChange={(e) => update("global.headerQuoteButton", e.target.value)} className="cms-input" />
        </FieldWrapper>
      </div>
    </div>
  );
}

/**
 * Footer: logo, mission text, column headings, copyright and bottom tagline.
 * Rendered inside Home → "Footer" and Global Settings → "Footer" (same content keys).
 */
export function FooterSectionFields({ content, update }: EditorProps) {
  const g = content.global;
  const headings = g.footerHeadings;
  return (
    <div className="space-y-5">
      <MediaField
        label="Footer Logo (dark background)"
        contentKey="global.branding.logoLight"
        variant="logo"
        hint="Footer brand block. This is the same dark-background logo used by the transparent header. 33px tall, width auto."
        value={g.branding.logoLight}
        defaultValue={defaultSiteContent.global.branding.logoLight}
        onChange={(val) => update("global.branding.logoLight", val)}
      />

      <FieldWrapper label="Footer Mission Paragraph" contentKey="global.footerMission">
        <RichTextEditor value={g.footerMission} onChange={(val) => update("global.footerMission", val)} rows={2} />
      </FieldWrapper>

      <div className="cms-sub-card">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">Column headings</span>
          <span className="cms-key-badge-sub font-mono">global.footerHeadings</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          {(["company", "services", "solutions", "support", "contact"] as const).map((key) => (
            <input
              key={key}
              type="text"
              value={headings[key]}
              onChange={(e) => update(`global.footerHeadings.${key}`, e.target.value)}
              className="cms-input"
              aria-label={`${key} column heading`}
              title={`global.footerHeadings.${key}`}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FieldWrapper label="Copyright Statement" contentKey="global.copyright">
          <input type="text" value={g.copyright} onChange={(e) => update("global.copyright", e.target.value)} className="cms-input" />
        </FieldWrapper>
        <FieldWrapper label="Footer Bottom Tagline" contentKey="global.footerBottomTagline">
          <input type="text" value={g.footerBottomTagline} onChange={(e) => update("global.footerBottomTagline", e.target.value)} className="cms-input" />
        </FieldWrapper>
      </div>

      <p className="text-[11px] text-slate-500 flex items-center gap-1.5">
        <Info size={12} /> Contact details and social links shown in the footer are managed under Global Settings → Contact Information / Social Media Links.
      </p>
    </div>
  );
}
