"use client";

import React, { useEffect, useRef, useState } from "react";
import { SiteContent } from "@/lib/cms-types";
import {
  Monitor,
  Tablet,
  Smartphone,
  RotateCw,
  ExternalLink,
  Eye,
  CheckCircle2,
  Sparkles,
} from "lucide-react";

interface LivePreviewPaneProps {
  content: SiteContent;
  activePageTab: string;
}

const PAGE_ROUTES = [
  { label: "Home Page", path: "/" },
  { label: "About Us", path: "/about" },
  { label: "Services", path: "/services" },
  { label: "Solutions", path: "/solutions" },
  { label: "Global Network", path: "/global-network" },
  { label: "Tracking", path: "/tracking" },
  { label: "Request a Quote", path: "/quote" },
  { label: "Contact Us", path: "/contact" },
  { label: "Privacy Policy", path: "/privacy" },
  { label: "Terms & Conditions", path: "/terms" },
  { label: "Cookie Policy", path: "/cookies" },
];

export function LivePreviewPane({ content, activePageTab }: LivePreviewPaneProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [device, setDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [selectedPath, setSelectedPath] = useState("/");
  const [syncedCount, setSyncedCount] = useState(0);

  // Auto-switch preview page if user clicks a tab in the editor
  useEffect(() => {
    switch (activePageTab) {
      case "home":
        setSelectedPath("/");
        break;
      case "about":
        setSelectedPath("/about");
        break;
      case "services":
        setSelectedPath("/services");
        break;
      case "solutions":
        setSelectedPath("/solutions");
        break;
      case "globalNetwork":
        setSelectedPath("/global-network");
        break;
      case "tracking":
        setSelectedPath("/tracking");
        break;
      case "quote":
        setSelectedPath("/quote");
        break;
      case "contact":
        setSelectedPath("/contact");
        break;
      case "legal":
        setSelectedPath("/privacy");
        break;
      default:
        break;
    }
  }, [activePageTab]);

  // Send real-time updates to iframe whenever content changes
  useEffect(() => {
    const iframe = iframeRef.current;
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage(
        {
          type: "ARINA_CMS_PREVIEW_UPDATE",
          content,
        },
        "*"
      );
      setSyncedCount((c) => c + 1);
    }
  }, [content, selectedPath]);

  // Handle iframe handshake when it finishes loading
  const handleIframeLoad = () => {
    const iframe = iframeRef.current;
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage(
        {
          type: "ARINA_CMS_PREVIEW_UPDATE",
          content,
        },
        "*"
      );
    }
  };

  const reloadIframe = () => {
    if (iframeRef.current) {
      iframeRef.current.src = selectedPath;
    }
  };

  const getDeviceWidth = () => {
    if (device === "mobile") return "375px";
    if (device === "tablet") return "768px";
    return "100%";
  };

  return (
    <div className="cms-preview-container">
      {/* Top Preview Bar */}
      <div className="cms-preview-header">
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs font-bold text-amber-500 bg-amber-500/10 px-2.5 py-1 rounded">
            <Sparkles size={13} />
            LIVE PREVIEW
          </span>
          <select
            value={selectedPath}
            onChange={(e) => setSelectedPath(e.target.value)}
            className="cms-preview-select"
          >
            {PAGE_ROUTES.map((p) => (
              <option key={p.path} value={p.path}>
                {p.label} ({p.path})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-700">
          <button
            type="button"
            onClick={() => setDevice("desktop")}
            className={`cms-device-btn ${device === "desktop" ? "active" : ""}`}
            title="Desktop View (100%)"
          >
            <Monitor size={15} />
          </button>
          <button
            type="button"
            onClick={() => setDevice("tablet")}
            className={`cms-device-btn ${device === "tablet" ? "active" : ""}`}
            title="Tablet View (768px)"
          >
            <Tablet size={15} />
          </button>
          <button
            type="button"
            onClick={() => setDevice("mobile")}
            className={`cms-device-btn ${device === "mobile" ? "active" : ""}`}
            title="Mobile View (375px)"
          >
            <Smartphone size={15} />
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={reloadIframe}
            className="cms-preview-tool-btn"
            title="Reload preview"
          >
            <RotateCw size={14} />
          </button>
          <a
            href={selectedPath}
            target="_blank"
            rel="noreferrer"
            className="cms-preview-tool-btn"
            title="Open in new window"
          >
            <ExternalLink size={14} />
          </a>
        </div>
      </div>

      {/* Frame wrapper */}
      <div className="cms-preview-frame-wrap">
        <div
          className="cms-preview-viewport"
          style={{
            width: getDeviceWidth(),
            boxShadow: device !== "desktop" ? "0 25px 60px rgba(0,0,0,0.5)" : "none",
          }}
        >
          <iframe
            ref={iframeRef}
            src={selectedPath}
            title="Live Website Preview"
            className="cms-preview-iframe"
            onLoad={handleIframeLoad}
          />
        </div>
      </div>

      <div className="cms-preview-footer">
        <span className="flex items-center gap-1.5 text-[11px] text-slate-400">
          <CheckCircle2 size={13} className="text-emerald-400" /> Real-time instant sync active
        </span>
        <span className="text-[11px] text-slate-500 font-mono">
          Viewport: {device.toUpperCase()} ({getDeviceWidth()})
        </span>
      </div>
    </div>
  );
}
