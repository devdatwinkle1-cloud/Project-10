"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  ExternalLink,
  Image as ImageIcon,
  Link2,
  Loader2,
  Monitor,
  RefreshCw,
  RotateCcw,
  Smartphone,
  Trash2,
  Upload,
  FolderOpen,
  Images,
} from "lucide-react";
import { FieldWrapper } from "./FieldWrapper";
import type { BannerAsset, ImageAsset } from "@/lib/cms-types";
import { ACCEPTED_IMAGE_TYPES, MAX_UPLOAD_BYTES, formatBytes, isUploadedMedia } from "@/lib/media";

/* ------------------------------------------------------------------ */
/*  Shared "recent uploads" cache (one request for all fields)          */
/* ------------------------------------------------------------------ */
export interface MediaItem {
  id: number;
  url: string;
  filename: string;
  mimeType: string;
  size: number;
  width: number | null;
  height: number | null;
  alt: string;
  createdAt: string;
}

let libraryCache: Promise<MediaItem[]> | null = null;
const libraryListeners = new Set<() => void>();

export function invalidateMediaLibrary() {
  libraryCache = null;
  libraryListeners.forEach((fn) => fn());
}

function loadMediaLibrary(): Promise<MediaItem[]> {
  if (!libraryCache) {
    libraryCache = fetch("/api/media", { cache: "no-store" })
      .then((r) => r.json())
      .then((json) => (json?.success ? (json.media as MediaItem[]) : []))
      .catch(() => []);
  }
  return libraryCache;
}

const STOCK_IMAGES = [
  { label: "Container Ship Dusk", url: "https://images.pexels.com/photos/3848789/pexels-photo-3848789.jpeg?auto=compress&cs=tinysrgb&w=2000" },
  { label: "Port Cranes & Ship", url: "https://images.pexels.com/photos/24702864/pexels-photo-24702864.jpeg?auto=compress&cs=tinysrgb&w=1300" },
  { label: "Aerial Container Port", url: "https://images.pexels.com/photos/7519262/pexels-photo-7519262.jpeg?auto=compress&cs=tinysrgb&w=1300" },
  { label: "Jakarta Cargo Port", url: "https://images.pexels.com/photos/3856433/pexels-photo-3856433.jpeg?auto=compress&cs=tinysrgb&w=1300" },
  { label: "Logistics Warehouse", url: "https://images.pexels.com/photos/24244230/pexels-photo-24244230.jpeg?auto=compress&cs=tinysrgb&w=1300" },
  { label: "Road Freight Trailers", url: "https://images.pexels.com/photos/1267325/pexels-photo-1267325.jpeg?auto=compress&cs=tinysrgb&w=1300" },
  { label: "Hamburg Terminal", url: "https://images.pexels.com/photos/29278107/pexels-photo-29278107.jpeg?auto=compress&cs=tinysrgb&w=1300" },
  { label: "Industrial Stacks", url: "https://images.pexels.com/photos/7519246/pexels-photo-7519246.jpeg?auto=compress&cs=tinysrgb&w=1300" },
];

type MediaValue = ImageAsset | BannerAsset;
type Slot = "src" | "mobileSrc";

interface MediaFieldProps {
  label: string;
  contentKey: string;
  value: MediaValue | undefined;
  onChange: (next: MediaValue) => void;
  /** image = single image · banner = desktop + optional mobile image · logo = contain-fit preview */
  variant?: "image" | "banner" | "logo";
  /** Where the image is used and the recommended size. */
  hint?: string;
  /** Original value, enables "Reset to default". */
  defaultValue?: MediaValue;
  description?: string;
}

async function uploadFile(file: File, alt: string): Promise<{ ok: true; media: MediaItem } | { ok: false; error: string }> {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    return { ok: false, error: "Unsupported file type. Use JPG, PNG, WEBP, GIF, AVIF or SVG." };
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return { ok: false, error: `File is too large (${formatBytes(file.size)}). Maximum is ${formatBytes(MAX_UPLOAD_BYTES)}.` };
  }
  const form = new FormData();
  form.append("file", file);
  form.append("alt", alt);
  try {
    const res = await fetch("/api/media", { method: "POST", body: form });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.success) return { ok: false, error: json?.error || "Upload failed. Please try again." };
    invalidateMediaLibrary();
    return { ok: true, media: json.media as MediaItem };
  } catch {
    return { ok: false, error: "Network error while uploading. Please try again." };
  }
}

export function MediaField({
  label,
  contentKey,
  value,
  onChange,
  variant = "image",
  hint,
  defaultValue,
  description,
}: MediaFieldProps) {
  const isBanner = variant === "banner";
  const current: BannerAsset = {
    src: value?.src ?? "",
    mobileSrc: (value as BannerAsset | undefined)?.mobileSrc ?? "",
    alt: value?.alt ?? "",
  };

  const [slot, setSlot] = useState<Slot>("src");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const [dims, setDims] = useState<string>("");
  const [loadFailed, setLoadFailed] = useState(false);
  const [library, setLibrary] = useState<MediaItem[] | null>(null);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const activeSrc = slot === "mobileSrc" ? current.mobileSrc : current.src;

  useEffect(() => {
    setDims("");
    setLoadFailed(false);
  }, [activeSrc]);

  const emit = useCallback(
    (patch: Partial<BannerAsset>) => {
      const next = { ...current, ...patch };
      onChange(isBanner ? next : { src: next.src, alt: next.alt });
    },
    [current, isBanner, onChange],
  );

  const setSrc = (url: string) => {
    setError("");
    emit(slot === "mobileSrc" ? { mobileSrc: url } : { src: url });
  };

  async function handleFile(file: File | undefined | null) {
    if (!file) return;
    setError("");
    setUploading(true);
    const result = await uploadFile(file, current.alt);
    setUploading(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    const patch: Partial<BannerAsset> = slot === "mobileSrc" ? { mobileSrc: result.media.url } : { src: result.media.url };
    if (!current.alt && result.media.filename) {
      patch.alt = result.media.filename.replace(/\.[a-z0-9]+$/i, "").replace(/[-_]+/g, " ");
    }
    emit(patch);
    if (fileInput.current) fileInput.current.value = "";
  }

  /**
   * Removes the image from this section (editor state only).
   * Uploaded files are deleted from storage when the change is published,
   * provided nothing else on the website still uses them.
   */
  function handleRemove() {
    if (!activeSrc) return;
    setSrc("");
  }

  async function openLibrary() {
    const next = !libraryOpen;
    setLibraryOpen(next);
    if (next) setLibrary(await loadMediaLibrary());
  }

  // Refresh the open library list when any field uploads/deletes
  useEffect(() => {
    const listener = () => {
      if (libraryOpen) loadMediaLibrary().then(setLibrary);
    };
    libraryListeners.add(listener);
    return () => {
      libraryListeners.delete(listener);
    };
  }, [libraryOpen]);

  const canReset =
    !!defaultValue &&
    (defaultValue.src !== current.src ||
      ((defaultValue as BannerAsset).mobileSrc ?? "") !== current.mobileSrc ||
      defaultValue.alt !== current.alt);

  const slotKey = `${contentKey}.${slot}`;

  return (
    <FieldWrapper label={label} contentKey={contentKey} description={description}>
      <div className="cms-media">
        {isBanner && (
          <div className="cms-media-tabs" role="tablist" aria-label="Banner image variants">
            <button
              type="button"
              role="tab"
              aria-selected={slot === "src"}
              className={`cms-media-tab ${slot === "src" ? "active" : ""}`}
              onClick={() => setSlot("src")}
            >
              <Monitor size={13} /> Desktop image
              <span className={`cms-media-tab-dot ${current.src ? "" : "empty"}`} />
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={slot === "mobileSrc"}
              className={`cms-media-tab ${slot === "mobileSrc" ? "active" : ""}`}
              onClick={() => setSlot("mobileSrc")}
            >
              <Smartphone size={13} /> Mobile image <span className="text-slate-500 font-medium">(optional)</span>
              <span className={`cms-media-tab-dot ${current.mobileSrc ? "" : "empty"}`} />
            </button>
          </div>
        )}

        <div className="cms-media-body">
          {/* Preview / drop zone */}
          <div
            className={`cms-media-drop ${activeSrc ? "has-image" : ""} ${variant === "logo" ? "contain" : ""} ${dragging ? "dragging" : ""}`}
            onClick={() => !uploading && fileInput.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              handleFile(e.dataTransfer.files?.[0]);
            }}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                fileInput.current?.click();
              }
            }}
            aria-label={activeSrc ? "Replace image" : "Upload image"}
            title={activeSrc ? "Click or drop a file to replace" : "Click or drop a file to upload"}
          >
            {activeSrc && !loadFailed ? (
              <>
                <img
                  src={activeSrc}
                  alt={current.alt || "Preview"}
                  onLoad={(e) => setDims(`${e.currentTarget.naturalWidth}×${e.currentTarget.naturalHeight}`)}
                  onError={() => setLoadFailed(true)}
                />
                {dims && <span className="cms-media-dim">{dims}</span>}
              </>
            ) : (
              <div className="cms-media-drop-empty">
                {loadFailed ? <AlertCircle size={20} className="text-rose-400" /> : <ImageIcon size={22} />}
                <strong>{loadFailed ? "Image could not be loaded" : slot === "mobileSrc" ? "No mobile image — desktop image is used" : "No image set"}</strong>
                <span>Drop a file here or click to upload</span>
              </div>
            )}
            {uploading && (
              <div className="cms-media-overlay">
                <Loader2 size={18} className="animate-spin" /> Uploading…
              </div>
            )}
          </div>

          {/* Controls */}
          <div>
            <div className="cms-media-actions">
              <button
                type="button"
                className={`cms-media-btn ${activeSrc ? "" : "primary"}`}
                onClick={() => fileInput.current?.click()}
                disabled={uploading}
              >
                {activeSrc ? <RefreshCw size={13} /> : <Upload size={13} />}
                {activeSrc ? "Replace" : "Upload image"}
              </button>
              <button type="button" className="cms-media-btn" onClick={openLibrary} disabled={uploading} aria-expanded={libraryOpen}>
                <FolderOpen size={13} /> Use uploaded
              </button>
              {activeSrc && (
                <a href={activeSrc} target="_blank" rel="noreferrer" className="cms-media-btn" title="Open full size in a new tab">
                  <ExternalLink size={13} /> Preview
                </a>
              )}
              {activeSrc && (
                <button type="button" className="cms-media-btn danger" onClick={handleRemove} disabled={uploading}>
                  <Trash2 size={13} /> Remove
                </button>
              )}
              {canReset && (
                <button
                  type="button"
                  className="cms-media-btn"
                  title="Restore the original image and alt text"
                  onClick={() => {
                    setError("");
                    onChange(isBanner ? { src: defaultValue!.src, mobileSrc: (defaultValue as BannerAsset).mobileSrc ?? "", alt: defaultValue!.alt } : { src: defaultValue!.src, alt: defaultValue!.alt });
                  }}
                >
                  <RotateCcw size={13} /> Reset to default
                </button>
              )}
            </div>
            <input
              ref={fileInput}
              type="file"
              accept={ACCEPTED_IMAGE_TYPES.join(",")}
              className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0])}
            />

            <p className="cms-media-meta mt-2">
              {hint && (
                <>
                  <b>Used for:</b> {hint}
                  <br />
                </>
              )}
              JPG · PNG · WEBP · GIF · AVIF · SVG · up to {formatBytes(MAX_UPLOAD_BYTES)}
              {isBanner && slot === "mobileSrc" && (
                <>
                  <br />
                  Shown on screens up to 760px wide. Leave empty to reuse the desktop image.
                </>
              )}
              {activeSrc && (
                <>
                  <br />
                  <b>Source:</b> {isUploadedMedia(activeSrc) ? "Uploaded file" : "External URL"}
                </>
              )}
            </p>

            {error && (
              <p className="cms-media-error" role="alert">
                <AlertCircle size={13} /> {error}
              </p>
            )}

            {libraryOpen && (
              <div className="cms-media-source" style={{ marginTop: 10 }}>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Images size={12} /> Uploaded images
                </span>
                {library === null ? (
                  <p className="cms-media-empty-note">Loading…</p>
                ) : library.length === 0 ? (
                  <p className="cms-media-empty-note">No uploads yet. Use “Upload image” to add your first file.</p>
                ) : (
                  <div className="cms-media-thumbs">
                    {library.map((m) => (
                      <button
                        type="button"
                        key={m.id}
                        className={`cms-media-thumb ${m.url === activeSrc ? "active" : ""} ${m.mimeType === "image/svg+xml" ? "svg" : ""}`}
                        title={`${m.filename}${m.width && m.height ? ` · ${m.width}×${m.height}` : ""} · ${formatBytes(m.size)}`}
                        onClick={() => {
                          setSrc(m.url);
                          if (!current.alt && m.alt) emit({ alt: m.alt, ...(slot === "mobileSrc" ? { mobileSrc: m.url } : { src: m.url }) });
                        }}
                      >
                        <img src={m.url} alt={m.alt || m.filename} loading="lazy" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            <details className="cms-media-source">
              <summary>
                <Link2 size={12} /> Use image URL
              </summary>
              <div className="cms-media-row">
                <input
                  type="text"
                  value={activeSrc}
                  onChange={(e) => setSrc(e.target.value)}
                  placeholder="https://… or /api/media/12"
                  className="cms-input flex-1"
                  title={slotKey}
                  aria-label={`${label} URL (${slotKey})`}
                />
              </div>
            </details>

            <details className="cms-media-source">
              <summary>
                <ImageIcon size={12} /> Stock photos
              </summary>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {STOCK_IMAGES.map((preset) => (
                  <button
                    type="button"
                    key={preset.url}
                    onClick={() => setSrc(preset.url)}
                    className={`cms-preset-chip ${activeSrc === preset.url ? "active" : ""}`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </details>
          </div>
        </div>

        <div className="cms-media-alt">
          <label htmlFor={`${contentKey}-alt`}>Alt text (accessibility &amp; SEO)</label>
          <input
            id={`${contentKey}-alt`}
            type="text"
            value={current.alt}
            onChange={(e) => emit({ alt: e.target.value })}
            placeholder="Describe the image, e.g. Container ship at the port of Dubai"
            className="cms-input"
            title={`${contentKey}.alt`}
          />
        </div>

        <div className="cms-media-note">
          <ImageIcon size={11} /> Replacing an image changes only the picture — size, position, overlay and animation stay exactly as designed. Replaced or removed uploads are cleared from storage when you publish.
        </div>
      </div>
    </FieldWrapper>
  );
}
