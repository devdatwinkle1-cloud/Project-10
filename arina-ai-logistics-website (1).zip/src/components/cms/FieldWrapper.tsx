"use client";

import React, { useState } from "react";
import { Copy, Check } from "lucide-react";

interface FieldWrapperProps {
  label: string;
  contentKey: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
}

export function FieldWrapper({
  label,
  contentKey,
  description,
  children,
  className = "",
}: FieldWrapperProps) {
  const [copied, setCopied] = useState(false);

  function copyKey() {
    navigator.clipboard?.writeText(contentKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className={`cms-field-group ${className}`}>
      <div className="cms-field-header">
        <label className="cms-field-label">
          {label}
        </label>
        <button
          type="button"
          onClick={copyKey}
          className="cms-key-badge"
          title="Click to copy content ID / key"
        >
          <span>{contentKey}</span>
          {copied ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
        </button>
      </div>
      {description && <p className="cms-field-desc">{description}</p>}
      <div className="cms-field-input-wrap">{children}</div>
    </div>
  );
}
