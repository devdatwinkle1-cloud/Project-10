"use client";

import React, { useRef, useEffect } from "react";
import { Bold, Italic, Underline, Link as LinkIcon, List, Heading2, Heading3, RotateCcw } from "lucide-react";

interface RichTextEditorProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  rows?: number;
  id?: string;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = "Write content...",
  rows = 4,
  id,
}: RichTextEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  function wrapSelection(prefix: string, suffix: string = prefix, defaultText = "text") {
    const el = textareaRef.current;
    if (!el) return;
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const text = el.value;
    const selected = text.substring(start, end) || defaultText;
    const replacement = `${prefix}${selected}${suffix}`;
    const nextVal = text.substring(0, start) + replacement + text.substring(end);
    onChange(nextVal);

    setTimeout(() => {
      el.focus();
      el.setSelectionRange(start + prefix.length, start + prefix.length + selected.length);
    }, 0);
  }

  function insertList() {
    const el = textareaRef.current;
    if (!el) return;
    const start = el.selectionStart;
    const text = el.value;
    const prefix = text.length === 0 || text.endsWith("\n") ? "• " : "\n• ";
    const nextVal = text.substring(0, start) + prefix + text.substring(start);
    onChange(nextVal);
  }

  return (
    <div className="cms-richtext-wrap">
      <div className="cms-richtext-toolbar">
        <button
          type="button"
          onClick={() => wrapSelection("**", "**", "bold text")}
          title="Bold (**text**)"
          className="cms-tool-btn"
        >
          <Bold size={14} />
        </button>
        <button
          type="button"
          onClick={() => wrapSelection("*", "*", "italic text")}
          title="Italic (*text*)"
          className="cms-tool-btn"
        >
          <Italic size={14} />
        </button>
        <button
          type="button"
          onClick={() => wrapSelection("<u>", "</u>", "underlined text")}
          title="Underline (<u>text</u>)"
          className="cms-tool-btn"
        >
          <Underline size={14} />
        </button>
        <div className="cms-tool-divider" />
        <button
          type="button"
          onClick={() => wrapSelection("[", "](https://example.com)", "link label")}
          title="Add Link"
          className="cms-tool-btn"
        >
          <LinkIcon size={14} />
        </button>
        <button
          type="button"
          onClick={insertList}
          title="Bullet Point"
          className="cms-tool-btn"
        >
          <List size={14} />
        </button>
        <div className="cms-tool-divider" />
        <button
          type="button"
          onClick={() => wrapSelection("## ", "", "Heading 2")}
          title="Heading 2"
          className="cms-tool-btn text-xs font-bold"
        >
          H2
        </button>
        <button
          type="button"
          onClick={() => wrapSelection("### ", "", "Heading 3")}
          title="Heading 3"
          className="cms-tool-btn text-xs font-bold"
        >
          H3
        </button>
        <span className="cms-richtext-hint">Supports formatting, **bold**, *italic*, and line breaks</span>
      </div>
      <textarea
        ref={textareaRef}
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="cms-richtext-area"
      />
    </div>
  );
}
