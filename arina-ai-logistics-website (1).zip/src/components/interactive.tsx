"use client";

import React, { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Circle,
  PackageSearch,
  Search,
  AlertCircle,
  Loader2,
  ArrowUpRight,
  X,
  Info,
} from "lucide-react";
import { useContent, FormattedText } from "@/context/content-context";

export function TrackingWidget() {
  const { home } = useContent();
  const w = home.trackingWidget;
  const [number, setNumber] = useState("");
  const router = useRouter();

  return (
    <div className="tracking-widget">
      <div className="widget-title">
        <div className="widget-icon">
          <PackageSearch size={25} strokeWidth={1.6} />
        </div>
        <div>
          <h2>
            <FormattedText text={w.title} />
          </h2>
          <p>
            <FormattedText text={w.description} />
          </p>
        </div>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          router.push(`/tracking${number.trim() ? `?number=${encodeURIComponent(number.trim())}` : ""}`);
        }}
        className="widget-form"
      >
        <label className="sr-only" htmlFor="quick-tracking">
          {w.placeholder}
        </label>
        <input
          id="quick-tracking"
          placeholder={w.placeholder}
          value={number}
          onChange={(e) => setNumber(e.target.value)}
        />
        <button type="submit">
          {w.buttonLabel} <ArrowRight size={18} />
        </button>
      </form>
      <span className="widget-note">{w.footerNote}</span>
    </div>
  );
}

export function TrackingInterface() {
  const { tracking } = useContent();
  const search = useSearchParams();
  const [number, setNumber] = useState(search.get("number") || "");
  const [shipmentType, setShipmentType] = useState(tracking.form.options[0] || "Ocean Freight");
  const [state, setState] = useState<"idle" | "loading" | "result" | "empty">("idle");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const sampleNumber = tracking.demoHint.sampleNumber || "DEMO-2026-00125";

  useEffect(() => {
    const initial = search.get("number");
    if (initial) {
      const t = setTimeout(() => {
        setState(initial.trim().toUpperCase() === sampleNumber.toUpperCase() ? "result" : "empty");
      }, 400);
      return () => clearTimeout(t);
    }
  }, [search, sampleNumber]);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!number.trim()) return;
    setState("loading");
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      setState(number.trim().toUpperCase() === sampleNumber.toUpperCase() ? "result" : "empty");
    }, 700);
  }

  const s = tracking.sampleResult;

  return (
    <div className="tracking-interface">
      <div className="tracking-form-head">
        <span className="micro-label">{tracking.form.microLabel}</span>
        <h2>
          <FormattedText text={tracking.form.title} />
        </h2>
        <p>
          <FormattedText text={tracking.form.subtitle} />
        </p>
      </div>

      <form className="tracking-form" onSubmit={submit}>
        <div className="field">
          <label htmlFor="tracking-number">{tracking.form.inputLabel}</label>
          <input
            id="tracking-number"
            required
            placeholder={tracking.form.inputPlaceholder}
            value={number}
            onChange={(e) => setNumber(e.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="shipment-type">{tracking.form.selectLabel}</label>
          <select id="shipment-type" value={shipmentType} onChange={(e) => setShipmentType(e.target.value)}>
            {tracking.form.options.map((opt) => (
              <option key={opt}>{opt}</option>
            ))}
          </select>
        </div>
        <button className="button button-primary" type="submit" disabled={state === "loading"}>
          {state === "loading" ? (
            <>
              <Loader2 className="spin" size={17} /> {tracking.form.searchingLabel}
            </>
          ) : (
            <>
              {tracking.form.buttonLabel} <ArrowUpRight size={17} />
            </>
          )}
        </button>
      </form>

      <div className="demo-hint">
        <span className="demo-badge">{tracking.demoHint.badge}</span>
        <p>
          {tracking.demoHint.text}{" "}
          <button
            type="button"
            onClick={() => {
              setNumber(sampleNumber);
              setShipmentType(tracking.form.options[0] || "Ocean Freight");
              setState("result");
            }}
          >
            {sampleNumber}
          </button>
        </p>
        <DemoInfo />
      </div>

      {state === "empty" && (
        <div className="tracking-empty" role="status">
          <Search size={30} />
          <h3>{tracking.emptyState.title}</h3>
          <p>
            {tracking.emptyState.textPrefix} <strong>{number}</strong>. {tracking.emptyState.textSuffix}
          </p>
        </div>
      )}

      {state === "result" && (
        <div className="tracking-result" role="status">
          <div className="result-demo">{s.bannerText}</div>
          <div className="result-top">
            <div>
              <span className="micro-label">{s.numberLabel}</span>
              <h3>{sampleNumber}</h3>
            </div>
            <span className="status-pill">
              <span /> {s.statusText}
            </span>
          </div>
          <div className="result-details">
            <div>
              <span>{s.originLabel}</span>
              <strong>{s.originValue}</strong>
            </div>
            <div>
              <span>{s.destinationLabel}</span>
              <strong>{s.destinationValue}</strong>
            </div>
            <div>
              <span>{s.deliveryLabel}</span>
              <strong>{s.deliveryValue}</strong>
            </div>
            <div>
              <span>{s.shipmentTypeLabel}</span>
              <strong>{s.shipmentTypeValue}</strong>
            </div>
          </div>
          <div className="result-timeline">
            <div className="timeline-heading">
              <h4>{s.journeyHeading}</h4>
              <span>{s.journeyCount}</span>
            </div>
            <div className="timeline-list">
              {s.timelineSteps.map((step, i) => (
                <div
                  className={`timeline-item ${i < 3 ? "done" : i === 3 ? "current" : "upcoming"}`}
                  key={step}
                >
                  <span className="timeline-marker">
                    {i < 3 ? <Check size={15} /> : i === 3 ? <span /> : <Circle size={14} />}
                  </span>
                  <div>
                    <strong>{step}</strong>
                    <small>{i === 3 ? "Current stage" : i < 3 ? "Completed" : "Upcoming"}</small>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

type FormKind = "quote" | "contact";

export function InquiryForm({ kind }: { kind: FormKind }) {
  const { quote, contact } = useContent();
  const formData = kind === "quote" ? quote.form : contact.form;
  const labels = formData.labels as any;
  const placeholders = formData.placeholders as any;

  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [error, setError] = useState("");
  const [resetKey, setResetKey] = useState(0);
  const [showToast, setShowToast] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.reportValidity()) return;
    const data = Object.fromEntries(new FormData(form).entries());
    setStatus("loading");
    setError("");

    try {
      const res = await fetch(`/api/${kind}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Something went wrong. Please try again.");
      setStatus("success");
      setShowToast(true);
      setResetKey((k) => k + 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to submit. Please try again.");
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="form-success" role="status">
        {showToast && (
          <Toast message={formData.success.toastMessage} onClose={() => setShowToast(false)} />
        )}
        <span className="success-icon">
          <CheckCircle2 size={35} />
        </span>
        <span className="micro-label">{formData.success.microLabel}</span>
        <h2>
          <FormattedText text={formData.success.title} />
        </h2>
        <p>
          <FormattedText text={formData.success.description} />
        </p>
        <button className="button button-primary" onClick={() => setStatus("idle")}>
          {formData.success.buttonLabel} <ArrowRight size={17} />
        </button>
      </div>
    );
  }

  return (
    <form key={resetKey} className="inquiry-form" onSubmit={submit}>
      <div className="form-grid">
        <Field label={labels.fullName} name="fullName" placeholder={placeholders.fullName} required />
        <Field
          label={labels.companyName}
          name="companyName"
          placeholder={placeholders.companyName}
          required={kind === "quote"}
        />
        <Field
          label={labels.email}
          name="email"
          type="email"
          placeholder={placeholders.email}
          required
        />
        <Field
          label={labels.phone}
          name="phone"
          type="tel"
          placeholder={placeholders.phone}
          required={kind === "quote"}
        />

        {kind === "quote" ? (
          <>
            <Field label={labels.origin} name="origin" placeholder={placeholders.origin} required />
            <Field label={labels.destination} name="destination" placeholder={placeholders.destination} required />
            <Field label={labels.cargoType} name="cargoType" placeholder={placeholders.cargoType} required />
            <Field
              label={labels.cargoWeight}
              name="cargoWeight"
              type="number"
              min="0.01"
              step="any"
              placeholder={placeholders.cargoWeight}
              required
            />
            <div className="field">
              <label htmlFor="shippingMethod">
                {labels.shippingMethod} <span>*</span>
              </label>
              <select id="shippingMethod" name="shippingMethod" required defaultValue="">
                <option value="" disabled>
                  {placeholders.shippingMethodPrompt || "Select a method"}
                </option>
                {quote.form.shippingMethods.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </div>
            <Field label={labels.preferredDate} name="preferredDate" type="date" />
          </>
        ) : (
          <div className="field full-field">
            <label htmlFor="subject">
              {labels.subject} <span>*</span>
            </label>
            <select id="subject" name="subject" required defaultValue="">
              <option value="" disabled>
                {placeholders.subjectPrompt || "Select a subject"}
              </option>
              {contact.form.subjects.map((sub) => (
                <option key={sub}>{sub}</option>
              ))}
            </select>
          </div>
        )}

        <div className="field full-field">
          <label htmlFor="message">
            {labels.message} {kind === "contact" && <span>*</span>}
          </label>
          <textarea
            id="message"
            name="message"
            rows={5}
            required={kind === "contact"}
            placeholder={placeholders.message}
          />
        </div>
      </div>

      {status === "error" && (
        <div className="form-error" role="alert">
          <AlertCircle size={17} />
          {error}
        </div>
      )}

      <div className="form-submit">
        <button className="button button-primary" type="submit" disabled={status === "loading"}>
          {status === "loading" ? (
            <>
              <Loader2 className="spin" size={17} /> {formData.submittingLabel}
            </>
          ) : (
            <>
              {formData.buttonLabel} <ArrowUpRight size={17} />
            </>
          )}
        </button>
        <p>{formData.privacyNote}</p>
      </div>
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required = false,
  min,
  step,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  min?: string;
  step?: string;
}) {
  return (
    <div className="field">
      <label htmlFor={name}>
        {label} {required && <span>*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        min={min}
        step={step}
      />
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const handle = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handle);
    return () => document.removeEventListener("keydown", handle);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div role="dialog" aria-modal="true" aria-label={title} className="modal-panel">
        <button type="button" className="modal-close" onClick={onClose} aria-label="Close dialog">
          <X size={22} />
        </button>
        <span className="micro-label">ARINA / INFORMATION</span>
        <h2>
          <FormattedText text={title} />
        </h2>
        {children}
      </div>
    </div>
  );
}

export function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 5000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <div className="toast" role="status">
      <CheckCircle2 size={20} />
      <span>{message}</span>
      <button type="button" onClick={onClose} aria-label="Dismiss notification">
        <X size={17} />
      </button>
    </div>
  );
}

export function DemoInfo() {
  const { tracking } = useContent();
  const [open, setOpen] = useState(false);
  const m = tracking.modal;

  return (
    <>
      <button
        type="button"
        className="demo-info-button"
        onClick={() => setOpen(true)}
        aria-label={tracking.demoHint.infoButtonLabel}
      >
        <Info size={17} />
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title={m.title}>
        <p>
          <FormattedText text={m.paragraph1} />
        </p>
        <p>
          <FormattedText text={m.paragraph2} />
        </p>
      </Modal>
    </>
  );
}

export function Counters() {
  const { home } = useContent();
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setActive(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="stats-grid" ref={ref}>
      {home.stats.map((stat, i) => (
        <Counter key={i} n={stat.number} s={stat.suffix} l={stat.label} active={active} />
      ))}
    </div>
  );
}

function Counter({ n, s, l, active }: { n: number; s: string; l: string; active: boolean }) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!active) return;
    let frame = 0;
    const duration = 900;
    const start = performance.now();

    function tick(now: number) {
      const progress = Math.min((now - start) / duration, 1);
      setValue(Math.round(n * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) frame = requestAnimationFrame(tick);
    }

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [active, n]);

  return (
    <div className="stat">
      <strong>
        {value}
        {s}
      </strong>
      <span>{l}</span>
    </div>
  );
}
