"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import {
  ButtonLink,
  CtaBanner,
  Eyebrow,
  IndustryGrid,
  Journey,
  SectionHeading,
  ServiceGrid,
  SolutionGrid,
  WhyChoose,
} from "@/components/site";
import { Counters, TrackingWidget } from "@/components/interactive";
import { useContent, FormattedText } from "@/context/content-context";
import { bannerStyle } from "@/lib/media";
import { CmsImage } from "@/components/site";
import { GlobalNetworkMapVisual } from "@/components/sections/GlobalNetworkMapVisual";

export default function HomePage() {
  const { home } = useContent();
  const hero = home.hero;
  const s = home.servicesSection;
  const a = home.aboutPreview;
  const n = home.networkPreview;
  const sol = home.solutionsSection;
  const ind = home.industriesSection;

  return (
    <main>
      <section
        className="home-hero"
        style={bannerStyle(
          hero.bgImage,
          "linear-gradient(90deg,rgba(5,24,38,.84) 0%,rgba(5,24,38,.47) 55%,rgba(5,24,38,.17) 100%),linear-gradient(0deg,rgba(5,24,38,.48),transparent 45%)",
        )}
      >
        <div className="container hero-content">
          <Eyebrow light>{hero.eyebrow}</Eyebrow>
          <h1>
            <FormattedText text={hero.titleLine1} />
            <br />
            <em>
              <FormattedText text={hero.titleLine2} />
            </em>
          </h1>
          <p>
            <FormattedText text={hero.description} />
          </p>
          <div className="button-row">
            <ButtonLink href={hero.primaryButtonHref}>{hero.primaryButton}</ButtonLink>
            <ButtonLink href={hero.secondaryButtonHref} variant="outline">
              {hero.secondaryButton}
            </ButtonLink>
          </div>
        </div>
        <div className="hero-bottom container">
          <span>{hero.bottomLabel}</span>
          <span className="hero-scroll">
            {hero.scrollLabel} <span>↓</span>
          </span>
        </div>
      </section>

      <div className="container widget-wrap">
        <TrackingWidget />
      </div>

      <section className="stats-section">
        <div className="container">
          <Counters />
        </div>
      </section>

      <section className="section-pad services-section">
        <div className="container">
          <div className="section-top">
            <SectionHeading eyebrow={s.eyebrow} title={s.title} description={s.description} />
            <Link className="inline-link" href="/services">
              {s.viewAllLabel} <ArrowUpRight size={18} />
            </Link>
          </div>
          <ServiceGrid />
        </div>
      </section>

      <section className="about-preview section-pad">
        <div className="container about-layout">
          <div className="about-photo">
            <CmsImage image={a.image} fallbackAlt="Cargo ship being handled at an international container port" />
            <span className="photo-caption">
              {a.photoCaption} <span>↗</span>
            </span>
          </div>
          <div className="about-copy">
            <Eyebrow>{a.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={a.title} />
            </h2>
            <p>
              <FormattedText text={a.paragraph1} />
            </p>
            <p>
              <FormattedText text={a.paragraph2} />
            </p>
            <div className="about-mini-stats">
              <div>
                <strong>
                  <FormattedText text={a.stat1Number} />
                </strong>
                <small>{a.stat1Label}</small>
              </div>
              <div>
                <strong>
                  <FormattedText text={a.stat2Number} />
                </strong>
                <small>{a.stat2Label}</small>
              </div>
            </div>
            <ButtonLink href={a.buttonHref}>{a.buttonLabel}</ButtonLink>
          </div>
        </div>
      </section>

      <section className="network-preview section-pad">
        <div className="container">
          <div className="network-preview-head">
            <SectionHeading eyebrow={n.eyebrow} title={n.title} description={n.description} light />
            <ButtonLink href={n.buttonHref} variant="outline">
              {n.buttonLabel}
            </ButtonLink>
          </div>
          <GlobalNetworkMapVisual />
        </div>
      </section>

      <section className="section-pad solutions-section">
        <div className="container">
          <div className="section-top">
            <SectionHeading eyebrow={sol.eyebrow} title={sol.title} description={sol.description} />
            <Link className="inline-link" href="/solutions">
              {sol.viewAllLabel} <ArrowUpRight size={18} />
            </Link>
          </div>
          <SolutionGrid />
        </div>
      </section>

      <section className="industries-section section-pad">
        <div className="container">
          <SectionHeading eyebrow={ind.eyebrow} title={ind.title} description={ind.description} />
          <IndustryGrid />
        </div>
      </section>

      <Journey />
      <WhyChoose />
      <CtaBanner />
      <CtaBanner compact />
    </main>
  );
}
