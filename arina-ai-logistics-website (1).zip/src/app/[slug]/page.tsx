"use client";

import React, { use } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import {
  ArrowUpRight,
  Check,
  ChevronRight,
  Clock3,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
} from "lucide-react";
import {
  ButtonLink,
  CtaBanner,
  Eyebrow,
  NetworkMap,
  PageHero,
  SectionHeading,
  ServiceGrid,
  SolutionGrid,
} from "@/components/site";
import { InquiryForm, TrackingInterface } from "@/components/interactive";
import { GlobalRouteMap } from "@/components/sections/GlobalRouteMap";
import { RegionalOperations } from "@/components/sections/RegionalOperations";
import { OfficeCard } from "@/components/sections/OfficeCard";
import { CompanyMilestones } from "@/components/sections/CompanyMilestones";
import { OriginToDestination } from "@/components/sections/OriginToDestination";
import { useContent, FormattedText } from "@/context/content-context";
import { bannerStyle } from "@/lib/media";
import { CmsImage } from "@/components/site";
import { getIconComponent } from "@/lib/icon-map";

const VALID_SLUGS = [
  "about",
  "services",
  "solutions",
  "global-network",
  "tracking",
  "quote",
  "contact",
  "privacy",
  "terms",
  "cookies",
];

export default function InnerPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  if (!VALID_SLUGS.includes(slug)) notFound();

  switch (slug) {
    case "about":
      return <AboutPage />;
    case "services":
      return <ServicesPage />;
    case "solutions":
      return <SolutionsPage />;
    case "global-network":
      return <GlobalNetworkPage />;
    case "tracking":
      return <TrackingPage />;
    case "quote":
      return <QuotePage />;
    case "contact":
      return <ContactPage />;
    default:
      return <LegalPage slug={slug} />;
  }
}

function AboutPage() {
  const { about } = useContent();
  const { hero, editorial, missionVision, valuesSection, capabilitiesBanner, milestonesSection } = about;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
        indexLabel1={hero.indexLabel1}
        indexLabel2={hero.indexLabel2}
      />
      <section className="section-pad">
        <div className="container editorial-grid">
          <div>
            <Eyebrow>{editorial.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={editorial.title} />
            </h2>
          </div>
          <div className="editorial-text">
            <p>
              <FormattedText text={editorial.paragraph1} />
            </p>
            <p>
              <FormattedText text={editorial.paragraph2} />
            </p>
            <ButtonLink href={editorial.buttonHref}>{editorial.buttonLabel}</ButtonLink>
          </div>
        </div>
      </section>

      <CompanyMilestones />

      <section className="about-values-intro section-pad">
        <div className="container mission-grid">
          <div>
            <span className="micro-label">{missionVision.missionLabel}</span>
            <h3>
              <FormattedText text={missionVision.missionTitle} />
            </h3>
            <p>
              <FormattedText text={missionVision.missionDescription} />
            </p>
          </div>
          <div>
            <span className="micro-label">{missionVision.visionLabel}</span>
            <h3>
              <FormattedText text={missionVision.visionTitle} />
            </h3>
            <p>
              <FormattedText text={missionVision.visionDescription} />
            </p>
          </div>
        </div>
      </section>

      <section className="section-pad">
        <div className="container">
          <SectionHeading
            eyebrow={valuesSection.eyebrow}
            title={valuesSection.title}
            description={valuesSection.description}
          />
          <div className="value-grid">
            {valuesSection.items.map((v, i) => {
              const IconComponent = getIconComponent(v.icon);
              return (
                <div className="value-card" key={v.title}>
                  <span>0{i + 1}</span>
                  <IconComponent size={32} strokeWidth={1.5} />
                  <h3>
                    <FormattedText text={v.title} />
                  </h3>
                  <p>
                    <FormattedText text={v.text} />
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section
        className="about-photo-band"
        style={bannerStyle(capabilitiesBanner.bgImage, "linear-gradient(90deg,rgba(5,24,38,.8),rgba(5,24,38,.22))")}
      >
        <div className="container">
          <Eyebrow light>{capabilitiesBanner.eyebrow}</Eyebrow>
          <h2>
            <FormattedText text={capabilitiesBanner.title} />
          </h2>
          <p>
            <FormattedText text={capabilitiesBanner.description} />
          </p>
        </div>
      </section>

      <section className="section-pad milestones">
        <div className="container">
          <SectionHeading
            eyebrow={milestonesSection.eyebrow}
            title={milestonesSection.title}
            description={milestonesSection.description}
          />
          <div className="milestone-grid">
            {milestonesSection.milestones.map((m) => (
              <div key={m.step}>
                <span>{m.step}</span>
                <h3>
                  <FormattedText text={m.title} />
                </h3>
                <p>
                  <FormattedText text={m.text} />
                </p>
              </div>
            ))}
          </div>
          <div className="about-stat-line">
            {milestonesSection.stats.map((s) => (
              <div key={s.label}>
                <strong>
                  <FormattedText text={s.number} />
                </strong>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
          <p className="stat-disclaimer">{milestonesSection.disclaimer}</p>
        </div>
      </section>
      <CtaBanner compact />
    </main>
  );
}

function ServicesPage() {
  const { services } = useContent();
  const { hero, overview, items } = services;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
      />
      <section className="section-pad">
        <div className="container">
          <SectionHeading
            eyebrow={overview.eyebrow}
            title={overview.title}
            description={overview.description}
          />
          <ServiceGrid />
        </div>
      </section>

      <OriginToDestination />

      <section className="service-details">
        {items.map((s, i) => {
          const IconComponent = getIconComponent(s.icon);
          return (
            <article id={s.slug} className="service-detail section-pad" key={s.slug}>
              <div className="container service-detail-grid">
                <div className="service-detail-image">
                  <CmsImage image={s.image} fallbackAlt={`${s.title} cargo operations`} />
                </div>
                <div className="service-detail-copy">
                  <Eyebrow>SERVICE / 0{i + 1}</Eyebrow>
                  <IconComponent size={36} strokeWidth={1.3} />
                  <h2>
                    <FormattedText text={s.title} />
                  </h2>
                  <p>
                    <FormattedText text={s.longDescription} />
                  </p>
                  <h3>What you can expect</h3>
                  <ul>
                    {s.benefits.map((b) => (
                      <li key={b}>
                        <Check size={17} />
                        <FormattedText text={b} />
                      </li>
                    ))}
                  </ul>
                  <p className="detail-audience">
                    <strong>Industries served:</strong> {s.industriesServed}
                  </p>
                  <ButtonLink href={s.buttonHref}>{s.buttonLabel}</ButtonLink>
                </div>
              </div>
            </article>
          );
        })}
      </section>
      <CtaBanner compact />
    </main>
  );
}

function SolutionsPage() {
  const { solutions } = useContent();
  const { hero, overview, detailsHeader, items } = solutions;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
      />
      <section className="section-pad">
        <div className="container">
          <SectionHeading
            eyebrow={overview.eyebrow}
            title={overview.title}
            description={overview.description}
          />
          <SolutionGrid />
        </div>
      </section>

      <section className="solution-details section-pad">
        <div className="container">
          <SectionHeading eyebrow={detailsHeader.eyebrow} title={detailsHeader.title} />
          <div className="solution-detail-list">
            {items.map((s, i) => {
              const IconComponent = getIconComponent(s.icon);
              return (
                <article id={s.slug} key={s.slug} className="solution-detail-row">
                  <div className="solution-row-icon">
                    <IconComponent size={28} strokeWidth={1.5} />
                  </div>
                  <div>
                    <span className="micro-label">SOLUTION 0{i + 1}</span>
                    <h3>
                      <FormattedText text={s.title} />
                    </h3>
                    <p>
                      <FormattedText text={s.description} />
                    </p>
                  </div>
                  <div className="solution-row-facts">
                    <p>
                      <strong>For</strong>
                      <FormattedText text={s.audience} />
                    </p>
                    <p>
                      <strong>Benefit</strong>
                      <FormattedText text={s.benefit} />
                    </p>
                    <p>
                      <strong>How we help</strong>
                      <FormattedText text={s.help} />
                    </p>
                    <Link href="/quote">
                      {s.discussLinkText} <ArrowUpRight size={17} />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>
      <CtaBanner />
    </main>
  );
}

function GlobalNetworkPage() {
  const { globalNetwork } = useContent();
  const { hero, capabilitiesSection } = globalNetwork;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
      />
      <GlobalRouteMap />
      <RegionalOperations />
      <OfficeCard />

      <section className="section-pad">
        <div className="container network-capabilities">
          <div>
            <Eyebrow>{capabilitiesSection.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={capabilitiesSection.title} />
            </h2>
            <p>
              <FormattedText text={capabilitiesSection.description} />
            </p>
            <ButtonLink href={capabilitiesSection.buttonHref}>
              {capabilitiesSection.buttonLabel}
            </ButtonLink>
          </div>
          <div className="capability-list">
            {capabilitiesSection.items.map((item) => (
              <div key={item.step}>
                <span>{item.step}</span>
                <h3>
                  <FormattedText text={item.title} />
                </h3>
                <p>
                  <FormattedText text={item.description} />
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <CtaBanner compact />
    </main>
  );
}

function TrackingPage() {
  const { tracking } = useContent();
  const { hero, helpBox } = tracking;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
      />
      <section className="tracking-page section-pad">
        <div className="container narrow-container">
          <Suspense fallback={<div className="tracking-interface">Loading tracking interface...</div>}>
            <TrackingInterface />
          </Suspense>
          <div className="tracking-help">
            <div>
              <Clock3 size={22} />
              <h3>
                <FormattedText text={helpBox.title} />
              </h3>
              <p>
                <FormattedText text={helpBox.description} />
              </p>
            </div>
            <ButtonLink href={helpBox.buttonHref} variant="text">
              {helpBox.buttonLabel}
            </ButtonLink>
          </div>
        </div>
      </section>
    </main>
  );
}

function QuotePage() {
  const { quote } = useContent();
  const { hero, sidePanel, form } = quote;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
      />
      <section className="form-page section-pad">
        <div className="container form-page-grid">
          <div className="form-side">
            <Eyebrow>{sidePanel.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={sidePanel.title} />
            </h2>
            <p>
              <FormattedText text={sidePanel.description} />
            </p>
            <div className="form-side-points">
              {sidePanel.points.map((pt) => (
                <div key={pt.step}>
                  <span>{pt.step}</span> {pt.text}
                </div>
              ))}
            </div>
            <div className="form-side-note">
              <ShieldCheck size={23} />
              <p>{sidePanel.note}</p>
            </div>
          </div>
          <div className="form-panel">
            <div className="panel-heading">
              <span className="micro-label">{form.microLabel}</span>
              <h2>
                <FormattedText text={form.title} />
              </h2>
              <p>{form.subtitle}</p>
            </div>
            <InquiryForm kind="quote" />
          </div>
        </div>
      </section>
    </main>
  );
}

function ContactPage() {
  const { contact, global } = useContent();
  const { hero, sidePanel, form, locationSection, faqSection } = contact;

  return (
    <main>
      <PageHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        description={hero.description}
        image={hero.bgImage}
      />
      <section className="contact-section section-pad">
        <div className="container form-page-grid">
          <div className="form-side">
            <Eyebrow>{sidePanel.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={sidePanel.title} />
            </h2>
            <p>
              <FormattedText text={sidePanel.description} />
            </p>
            <div className="contact-methods">
              <div>
                <MapPin size={23} />
                <div>
                  <span>OFFICE ADDRESS</span>
                  <strong>
                    <FormattedText text={global.address} />
                  </strong>
                </div>
              </div>
              <div>
                <Phone size={23} />
                <div>
                  <span>PHONE</span>
                  <a href={`tel:${global.phone.replace(/[^0-9+]/g, "")}`}>{global.phone}</a>
                </div>
              </div>
              <div>
                <Mail size={23} />
                <div>
                  <span>EMAIL</span>
                  <a href={`mailto:${global.email}`}>{global.email}</a>
                </div>
              </div>
              <div>
                <Clock3 size={23} />
                <div>
                  <span>WORKING HOURS</span>
                  <strong>{global.workingHours}</strong>
                  <p>{global.workingHoursNote}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="form-panel">
            <div className="panel-heading">
              <span className="micro-label">{form.microLabel}</span>
              <h2>
                <FormattedText text={form.title} />
              </h2>
              <p>{form.subtitle}</p>
            </div>
            <InquiryForm kind="contact" />
          </div>
        </div>
      </section>

      <section className="contact-location">
        <div className="container location-grid">
          <div>
            <Eyebrow>{locationSection.eyebrow}</Eyebrow>
            <h2>
              <FormattedText text={locationSection.title} />
            </h2>
            <p>
              <FormattedText text={locationSection.description} />
            </p>
            <ButtonLink href={locationSection.buttonHref} variant="text">
              {locationSection.buttonLabel}
            </ButtonLink>
          </div>
          <div className="location-map">
            <NetworkMap />
          </div>
        </div>
      </section>

      <section id="faq" className="section-pad faq-section">
        <div className="container">
          <SectionHeading eyebrow={faqSection.eyebrow} title={faqSection.title} />
          <div className="faq-list">
            {faqSection.items.map((item, idx) => (
              <details key={idx}>
                <summary>
                  <FormattedText text={item.question} />
                  <ChevronRight size={19} />
                </summary>
                <p>
                  <FormattedText text={item.answer} />
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function LegalPage({ slug }: { slug: string }) {
  const { legal } = useContent();
  const section =
    slug === "privacy" ? legal.privacy : slug === "terms" ? legal.terms : legal.cookies;

  return (
    <main>
      <PageHero
        eyebrow={legal.hero.eyebrow}
        title={section.title}
        description={legal.hero.description}
        image={legal.hero.bgImage}
      />
      <section className="section-pad">
        <div className="container legal-copy">
          <p>{legal.note}</p>
          <h2>
            <FormattedText text={section.title} />
          </h2>
          <p>
            <FormattedText text={section.paragraph1} />
          </p>
          <p>
            <FormattedText text={section.paragraph2} />
          </p>
          <ButtonLink href="/contact">Contact Us</ButtonLink>
        </div>
      </section>
    </main>
  );
}
