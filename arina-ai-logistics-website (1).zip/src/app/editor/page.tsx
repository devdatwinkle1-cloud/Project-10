import CmsAdminDashboard from "../admin/page";

export default function EditorPage() {
  return <CmsAdminDashboard />;
}
