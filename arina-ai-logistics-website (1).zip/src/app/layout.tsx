import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Header, Footer } from "@/components/site";
import { ContentProvider } from "@/context/content-context";
import { getSiteContent } from "@/lib/cms-server";
import "./globals.css";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const content = await getSiteContent();
  return {
    title: content.global.meta.defaultTitle || "ARINA Global Logistics | Moving Your Cargo. Connecting the World.",
    description: content.global.meta.defaultDescription || "Reliable global shipping and logistics solutions. Explore ocean, air, road and rail freight, customs, warehousing and connected supply chain services with ARINA.",
    keywords: ["global logistics", "cargo shipping", "freight forwarding", "ocean freight", "air freight", "supply chain"],
    ...(content.global.branding?.favicon?.src ? { icons: { icon: content.global.branding.favicon.src } } : {}),
  };
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const content = await getSiteContent();

  return (
    <html lang="en">
      <body>
        <a href="#main-content" className="skip-link">
          Skip to content
        </a>
        <ContentProvider initialContent={content}>
          <Header />
          <div id="main-content">{children}</div>
          <Footer />
        </ContentProvider>
      </body>
    </html>
  );
}
