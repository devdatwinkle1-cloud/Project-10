"use client";

import React, { useState, useEffect, useTransition } from "react";
import Link from "next/link";
import { SiteContent } from "@/lib/cms-types";
import { defaultSiteContent } from "@/lib/cms-defaults";
import { RichTextEditor } from "@/components/cms/RichTextEditor";
import { FieldWrapper } from "@/components/cms/FieldWrapper";
import { MediaField } from "@/components/cms/MediaField";
import { normalizeSiteContent } from "@/lib/cms-merge";
import { HeaderSectionFields, FooterSectionFields } from "@/components/cms/SharedSections";
import { LivePreviewPane } from "@/components/cms/LivePreviewPane";
import { Modal, Toast } from "@/components/interactive";
import {
  Save,
  RotateCcw,
  RefreshCw,
  Eye,
  Download,
  Upload,
  Search,
  Sparkles,
  Layers,
  Globe,
  Home,
  Info,
  Package,
  Cpu,
  MapPin,
  FileText,
  HelpCircle,
  Settings,
  ShieldCheck,
  Check,
  Plus,
  Trash2,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  SlidersHorizontal,
  SplitSquareVertical,
  PanelLeftClose,
  PanelLeftOpen,
  Maximize2,
  FileCheck2,
  Phone,
  Mail,
  Building,
  Columns,
  Layout,
} from "lucide-react";

export default function CmsAdminDashboard() {
  const [content, setContent] = useState<SiteContent>(defaultSiteContent);
  const [savedContent, setSavedContent] = useState<SiteContent>(defaultSiteContent);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("home");
  const [activeSubSection, setActiveSubSection] = useState<string>("hero");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  useEffect(() => {
    if (typeof window !== "undefined" && window.innerWidth < 760) setSidebarCollapsed(true);
  }, []);
  const [viewMode, setViewMode] = useState<"split" | "editor" | "preview">("split");
  const [searchQuery, setSearchQuery] = useState("");
  const [resetModalOpen, setResetModalOpen] = useState(false);

  // Fetch initial content from API
  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/content");
        const json = await res.json();
        if (json.success && json.content) {
          setContent(json.content);
          setSavedContent(json.content);
        }
      } catch (err) {
        console.error("Failed to load content:", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const isDirty = JSON.stringify(content) !== JSON.stringify(savedContent);

  // Save changes to database
  async function handleSave() {
    setSaving(true);
    try {
      const res = await fetch("/api/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      const json = await res.json();
      if (json.success) {
        setSavedContent(content);
        setToastMessage("All changes have been published to the live website!");
      } else {
        alert(json.error || "Failed to save content");
      }
    } catch (err) {
      alert("Error saving content. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  // Revert changes back to last saved
  function handleRevert() {
    if (confirm("Discard all unsaved edits and restore last published version?")) {
      setContent(savedContent);
      setToastMessage("Unsaved changes discarded.");
    }
  }

  // Reset to factory defaults
  async function handleResetToDefaults() {
    setSaving(true);
    try {
      const res = await fetch("/api/content/reset", { method: "POST" });
      const json = await res.json();
      if (json.success) {
        setContent(defaultSiteContent);
        setSavedContent(defaultSiteContent);
        setResetModalOpen(false);
        setToastMessage("Website content has been reset to original defaults!");
      } else {
        alert(json.error || "Failed to reset");
      }
    } catch (err) {
      alert("Error resetting content.");
    } finally {
      setSaving(false);
    }
  }

  // Export JSON
  function handleExport() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(content, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `arina-content-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setToastMessage("Content JSON backup downloaded.");
  }

  // Import JSON
  function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        setContent(normalizeSiteContent(parsed));
        setToastMessage("Imported content successfully. Click 'Publish Changes' to save.");
      } catch (err) {
        alert("Invalid JSON file format.");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  // Deep update helper
  const updateContent = (path: string, value: any) => {
    setContent((prev) => {
      const copy = JSON.parse(JSON.stringify(prev));
      const keys = path.split(".");
      let current = copy;
      for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (!current[key]) current[key] = {};
        current = current[key];
      }
      current[keys[keys.length - 1]] = value;
      return copy;
    });
  };

  const navTabs = [
    { id: "global", label: "Global Settings", icon: Settings, badge: "Logo · Contact" },
    { id: "home", label: "Home Page", icon: Home, badge: "Header → Footer" },
    { id: "about", label: "About Us", icon: Info, badge: "6 Sections" },
    { id: "services", label: "Services", icon: Package, badge: "6 Services" },
    { id: "solutions", label: "Solutions", icon: Layers, badge: "7 Solutions" },
    { id: "globalNetwork", label: "Global Network", icon: Globe, badge: "6 Regions" },
    { id: "tracking", label: "Shipment Tracking", icon: Cpu, badge: "Demo UI" },
    { id: "quote", label: "Quote Request", icon: FileCheck2, badge: "Form" },
    { id: "contact", label: "Contact Us", icon: Phone, badge: "Contact & FAQ" },
    { id: "legal", label: "Legal & Policies", icon: ShieldCheck, badge: "Hero · 3 Pages" },
  ];

  if (loading) {
    return (
      <div className="cms-loading-screen">
        <div className="cms-spinner" />
        <p className="mt-4 text-sm font-semibold text-slate-300">Loading ARINA Content Management System...</p>
      </div>
    );
  }

  return (
    <div className="cms-app">
      {/* Toast */}
      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}

      {/* Confirmation Modal */}
      <Modal
        open={resetModalOpen}
        onClose={() => setResetModalOpen(false)}
        title="Reset to Factory Defaults"
      >
        <p className="text-slate-600 text-sm mb-4">
          Are you sure you want to reset all content back to original factory defaults? This will overwrite all custom text, headings, statistics, and images.
        </p>
        <div className="flex justify-end gap-3 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={() => setResetModalOpen(false)}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 rounded hover:bg-slate-200"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleResetToDefaults}
            className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 rounded hover:bg-rose-700"
          >
            Yes, Reset All Content
          </button>
        </div>
      </Modal>

      {/* Top Navbar */}
      <header className="cms-topbar">
        <div className="flex items-center gap-4">
          <div className="cms-topbar-brand">
            <span className="cms-brand-badge">ARINA CMS</span>
            <span className="cms-topbar-title">Content Editor & Management System</span>
          </div>
          <span className="cms-divider-v" />
          <div className="flex items-center gap-2">
            <span
              className={`cms-status-indicator ${isDirty ? "status-dirty" : "status-clean"}`}
            >
              <span className="cms-status-dot" />
              {isDirty ? "Unsaved Changes" : "Published & Live"}
            </span>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-700/80">
          <button
            type="button"
            onClick={() => setViewMode("split")}
            className={`cms-viewmode-btn ${viewMode === "split" ? "active" : ""}`}
            title="Split View (Editor + Live Preview)"
          >
            <SplitSquareVertical size={14} />
            <span className="hidden sm:inline">Split View</span>
          </button>
          <button
            type="button"
            onClick={() => setViewMode("editor")}
            className={`cms-viewmode-btn ${viewMode === "editor" ? "active" : ""}`}
            title="Editor Only"
          >
            <PanelLeftClose size={14} />
            <span className="hidden sm:inline">Editor Only</span>
          </button>
          <button
            type="button"
            onClick={() => setViewMode("preview")}
            className={`cms-viewmode-btn ${viewMode === "preview" ? "active" : ""}`}
            title="Preview Only"
          >
            <Eye size={14} />
            <span className="hidden sm:inline">Live Preview</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {isDirty && (
            <button
              type="button"
              onClick={handleRevert}
              className="cms-action-btn cms-btn-revert"
              title="Discard unsaved edits"
            >
              <RotateCcw size={14} />
              <span className="hidden md:inline">Revert</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setResetModalOpen(true)}
            className="cms-action-btn cms-btn-secondary"
            title="Reset to Factory Defaults"
          >
            <RefreshCw size={14} />
            <span className="hidden lg:inline">Reset Defaults</span>
          </button>

          <button
            type="button"
            onClick={handleExport}
            className="cms-action-btn cms-btn-secondary"
            title="Export JSON Backup"
          >
            <Download size={14} />
            <span className="hidden lg:inline">Export JSON</span>
          </button>

          <label className="cms-action-btn cms-btn-secondary cursor-pointer" title="Import JSON Backup">
            <Upload size={14} />
            <span className="hidden lg:inline">Import</span>
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>

          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            className="cms-action-btn cms-btn-secondary"
            title="Open Live Website in New Tab"
          >
            <ExternalLink size={14} />
            <span className="hidden md:inline">View Live Site</span>
          </a>

          <button
            type="button"
            onClick={handleSave}
            disabled={saving || !isDirty}
            className={`cms-action-btn cms-btn-primary ${!isDirty ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            {saving ? (
              <>
                <div className="cms-btn-spinner" /> Publishing...
              </>
            ) : (
              <>
                <Save size={15} /> Publish Changes
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main CMS Layout */}
      <div className="cms-main-layout">
        {/* Left Sidebar Navigation */}
        <aside className={`cms-sidebar ${sidebarCollapsed ? "is-collapsed" : ""}`} aria-label="Content editor navigation">
          <div className="cms-search-box">
            <button
              type="button"
              className="cms-sidebar-toggle"
              onClick={() => setSidebarCollapsed((v) => !v)}
              aria-expanded={!sidebarCollapsed}
              aria-label={sidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
              title={sidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
            >
              {sidebarCollapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
            </button>
            <Search size={14} className="text-slate-400 cms-collapsible" />
            <input
              type="text"
              placeholder="Search content or key..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="cms-search-input cms-collapsible"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>

          <div className="cms-nav-group">
            <span className="cms-nav-heading">WEBSITE PAGES & SECTIONS</span>
            <nav className="cms-nav-list">
              {navTabs.map((tab) => {
                const IconComponent = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(tab.id);
                      setSearchQuery("");
                    }}
                    className={`cms-nav-item ${isActive ? "active" : ""}`}
                    title={sidebarCollapsed ? tab.label : undefined}
                    aria-label={tab.label}
                  >
                    <IconComponent size={16} className={isActive ? "text-amber-400" : "text-slate-400"} />
                    <span className="cms-nav-label">{tab.label}</span>
                    <span className="cms-nav-badge">{tab.badge}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="cms-sidebar-footer">
            <div className="cms-info-card">
              <span className="cms-info-title">CENTRALIZED CONTENT CMS</span>
              <p className="cms-info-text">
                Every section holds its text AND its media (logo, banners, images). Upload or replace an image and only the picture changes — layout, sizes and animations stay as designed.
              </p>
            </div>
          </div>
        </aside>

        {/* Center/Left Editor Panel */}
        {viewMode !== "preview" && (
          <main className={`cms-editor-panel ${viewMode === "editor" ? "full-width" : ""}`}>
            <div className="cms-editor-content">
              {/* Header for current tab */}
              <div className="cms-editor-header">
                <div>
                  <span className="cms-breadcrumb">
                    CMS / {navTabs.find((t) => t.id === activeTab)?.label}
                  </span>
                  <h1 className="cms-editor-title">
                    {navTabs.find((t) => t.id === activeTab)?.label}
                  </h1>
                </div>
                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-slate-800 rounded font-mono text-[11px] text-amber-300">
                    ID: {activeTab}
                  </span>
                </div>
              </div>

              {/* Render Section Form based on activeTab */}
              {activeTab === "global" && (
                <GlobalSettingsEditor content={content} update={updateContent} />
              )}
              {activeTab === "home" && (
                <HomePageEditor content={content} update={updateContent} />
              )}
              {activeTab === "about" && (
                <AboutPageEditor content={content} update={updateContent} />
              )}
              {activeTab === "services" && (
                <ServicesPageEditor content={content} update={updateContent} />
              )}
              {activeTab === "solutions" && (
                <SolutionsPageEditor content={content} update={updateContent} />
              )}
              {activeTab === "globalNetwork" && (
                <GlobalNetworkEditor content={content} update={updateContent} />
              )}
              {activeTab === "tracking" && (
                <TrackingEditor content={content} update={updateContent} />
              )}
              {activeTab === "quote" && (
                <QuoteEditor content={content} update={updateContent} />
              )}
              {activeTab === "contact" && (
                <ContactEditor content={content} update={updateContent} />
              )}
              {activeTab === "legal" && (
                <LegalEditor content={content} update={updateContent} />
              )}
            </div>
          </main>
        )}

        {/* Right Live Preview Panel */}
        {viewMode !== "editor" && (
          <div className={`cms-preview-wrapper ${viewMode === "preview" ? "full-width" : ""}`}>
            <LivePreviewPane content={content} activePageTab={activeTab} />
          </div>
        )}
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// SECTION EDITORS
// -------------------------------------------------------------

function AccordionSection({
  title,
  sectionKey,
  defaultOpen = false,
  children,
}: {
  title: string;
  sectionKey: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="cms-accordion-box">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="cms-accordion-header"
      >
        <div className="flex items-center gap-2">
          {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
          <span className="font-bold text-sm text-slate-100">{title}</span>
        </div>
        <span className="cms-key-badge-sub font-mono">{sectionKey}</span>
      </button>
      {open && <div className="cms-accordion-body">{children}</div>}
    </div>
  );
}

/* 1. Global Settings Editor */
function GlobalSettingsEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const g = content.global;
  return (
    <div className="space-y-6">
      <AccordionSection title="Header — Logo, Brand Text, Navigation & Buttons" sectionKey="global.branding" defaultOpen={true}>
        <HeaderSectionFields content={content} update={update} />
      </AccordionSection>

      <AccordionSection title="Company Identity, Favicon & Tagline" sectionKey="global" defaultOpen={true}>
        <MediaField
          label="Favicon / Browser Tab Icon"
          contentKey="global.branding.favicon"
          variant="logo"
          hint="Browser tab icon. Square PNG, SVG or ICO-style PNG, 64×64 or larger."
          value={g.branding.favicon}
          defaultValue={defaultSiteContent.global.branding.favicon}
          onChange={(val) => update("global.branding.favicon", val)}
        />
        <div className="mt-4">
          <FieldWrapper label="Global Tagline / Mission" contentKey="global.tagline">
            <RichTextEditor value={g.tagline} onChange={(val) => update("global.tagline", val)} rows={2} />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="Contact Information" sectionKey="global.contact" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Primary Phone" contentKey="global.phone">
            <input type="text" value={g.phone} onChange={(e) => update("global.phone", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Primary Email" contentKey="global.email">
            <input type="text" value={g.email} onChange={(e) => update("global.email", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Office Address / Service Network" contentKey="global.address" className="md:col-span-2">
            <RichTextEditor value={g.address} onChange={(val) => update("global.address", val)} rows={2} />
          </FieldWrapper>
          <FieldWrapper label="Working Hours" contentKey="global.workingHours">
            <input type="text" value={g.workingHours} onChange={(e) => update("global.workingHours", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Working Hours Urgent Note" contentKey="global.workingHoursNote">
            <input type="text" value={g.workingHoursNote} onChange={(e) => update("global.workingHoursNote", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="Footer — Logo, Text, Headings & Copyright" sectionKey="global.footer">
        <FooterSectionFields content={content} update={update} />
      </AccordionSection>

      <AccordionSection title="Social Media Links" sectionKey="global.socialLinks">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FieldWrapper label="LinkedIn URL" contentKey="global.socialLinks.linkedin">
            <input type="text" value={g.socialLinks.linkedin} onChange={(e) => update("global.socialLinks.linkedin", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Instagram URL" contentKey="global.socialLinks.instagram">
            <input type="text" value={g.socialLinks.instagram} onChange={(e) => update("global.socialLinks.instagram", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Facebook URL" contentKey="global.socialLinks.facebook">
            <input type="text" value={g.socialLinks.facebook} onChange={(e) => update("global.socialLinks.facebook", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="Global SEO Defaults" sectionKey="global.meta">
          <FieldWrapper label="Default Meta Title" contentKey="global.meta.defaultTitle">
            <input type="text" value={g.meta.defaultTitle} onChange={(e) => update("global.meta.defaultTitle", e.target.value)} className="cms-input" />
          </FieldWrapper>
        <div className="mt-4">
          <FieldWrapper label="Default Meta Description" contentKey="global.meta.defaultDescription">
            <RichTextEditor value={g.meta.defaultDescription} onChange={(val) => update("global.meta.defaultDescription", val)} rows={2} />
          </FieldWrapper>
        </div>
      </AccordionSection>
    </div>
  );
}

/* 2. Home Page Editor */
function HomePageEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const h = content.home;

  return (
    <div className="space-y-6">
      {/* Header */}
      <AccordionSection title="0. Header — Logo & Navigation" sectionKey="global.branding" defaultOpen={false}>
        <HeaderSectionFields content={content} update={update} />
      </AccordionSection>

      {/* Hero Section */}
      <AccordionSection title="1. Hero Section" sectionKey="home.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow Badge" contentKey="home.hero.eyebrow">
            <input
              type="text"
              value={h.hero.eyebrow}
              onChange={(e) => update("home.hero.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Headline Line 1" contentKey="home.hero.titleLine1">
            <input
              type="text"
              value={h.hero.titleLine1}
              onChange={(e) => update("home.hero.titleLine1", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Headline Line 2 (Highlighted/Italic)" contentKey="home.hero.titleLine2">
            <input
              type="text"
              value={h.hero.titleLine2}
              onChange={(e) => update("home.hero.titleLine2", e.target.value)}
              className="cms-input font-bold text-amber-400"
            />
          </FieldWrapper>
          <FieldWrapper label="Bottom Label" contentKey="home.hero.bottomLabel">
            <input
              type="text"
              value={h.hero.bottomLabel}
              onChange={(e) => update("home.hero.bottomLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>

        <FieldWrapper label="Hero Description" contentKey="home.hero.description" className="mt-4">
          <RichTextEditor
            value={h.hero.description}
            onChange={(val) => update("home.hero.description", val)}
            rows={2}
          />
        </FieldWrapper>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Primary Button Label" contentKey="home.hero.primaryButton">
            <input
              type="text"
              value={h.hero.primaryButton}
              onChange={(e) => update("home.hero.primaryButton", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Primary Button Link" contentKey="home.hero.primaryButtonHref">
            <input
              type="text"
              value={h.hero.primaryButtonHref}
              onChange={(e) => update("home.hero.primaryButtonHref", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Secondary Button Label" contentKey="home.hero.secondaryButton">
            <input
              type="text"
              value={h.hero.secondaryButton}
              onChange={(e) => update("home.hero.secondaryButton", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Secondary Button Link" contentKey="home.hero.secondaryButtonHref">
            <input
              type="text"
              value={h.hero.secondaryButtonHref}
              onChange={(e) => update("home.hero.secondaryButtonHref", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>

        <div className="mt-4">
          <MediaField
            label="Hero Banner Image"
            contentKey="home.hero.bgImage"
            variant="banner"
            hint="Full-width home hero banner (cover, centred). Recommended 1920×1080 desktop · 1080×1350 mobile"
            value={h.hero.bgImage}
            defaultValue={defaultSiteContent.home.hero.bgImage}
            onChange={(val) => update("home.hero.bgImage", val)}
            />
        </div>
      </AccordionSection>

      {/* Hero Tracking Widget */}
      <AccordionSection title="2. Hero Tracking Widget" sectionKey="home.trackingWidget" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Widget Title" contentKey="home.trackingWidget.title">
            <input
              type="text"
              value={h.trackingWidget.title}
              onChange={(e) => update("home.trackingWidget.title", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Input Placeholder" contentKey="home.trackingWidget.placeholder">
            <input
              type="text"
              value={h.trackingWidget.placeholder}
              onChange={(e) => update("home.trackingWidget.placeholder", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Button Label" contentKey="home.trackingWidget.buttonLabel">
            <input
              type="text"
              value={h.trackingWidget.buttonLabel}
              onChange={(e) => update("home.trackingWidget.buttonLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Footer Note" contentKey="home.trackingWidget.footerNote">
            <input
              type="text"
              value={h.trackingWidget.footerNote}
              onChange={(e) => update("home.trackingWidget.footerNote", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Widget Subtitle" contentKey="home.trackingWidget.description" className="mt-4">
          <input
            type="text"
            value={h.trackingWidget.description}
            onChange={(e) => update("home.trackingWidget.description", e.target.value)}
            className="cms-input"
          />
        </FieldWrapper>
      </AccordionSection>

      {/* Trust Statistics */}
      <AccordionSection title="3. Trust Statistics (4 Counters)" sectionKey="home.stats">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {h.stats.map((st, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">
                Stat #{idx + 1} (home.stats[{idx}])
              </span>
              <div className="grid grid-cols-2 gap-2">
                <FieldWrapper label="Number" contentKey={`home.stats[${idx}].number`}>
                  <input
                    type="number"
                    value={st.number}
                    onChange={(e) => update(`home.stats.${idx}.number`, Number(e.target.value))}
                    className="cms-input font-bold"
                  />
                </FieldWrapper>
                <FieldWrapper label="Suffix" contentKey={`home.stats[${idx}].suffix`}>
                  <input
                    type="text"
                    value={st.suffix}
                    onChange={(e) => update(`home.stats.${idx}.suffix`, e.target.value)}
                    className="cms-input font-bold text-amber-400"
                  />
                </FieldWrapper>
              </div>
              <FieldWrapper label="Label" contentKey={`home.stats[${idx}].label`} className="mt-2">
                <input
                  type="text"
                  value={st.label}
                  onChange={(e) => update(`home.stats.${idx}.label`, e.target.value)}
                  className="cms-input"
                />
              </FieldWrapper>
            </div>
          ))}
        </div>
      </AccordionSection>

      {/* Services Section Header */}
      <AccordionSection title="4. Services Section Header" sectionKey="home.servicesSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="home.servicesSection.eyebrow">
            <input
              type="text"
              value={h.servicesSection.eyebrow}
              onChange={(e) => update("home.servicesSection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Section Title" contentKey="home.servicesSection.title">
            <input
              type="text"
              value={h.servicesSection.title}
              onChange={(e) => update("home.servicesSection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="View All Services Link Text" contentKey="home.servicesSection.viewAllLabel">
            <input
              type="text"
              value={h.servicesSection.viewAllLabel}
              onChange={(e) => update("home.servicesSection.viewAllLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.servicesSection.description" className="mt-4">
          <RichTextEditor
            value={h.servicesSection.description}
            onChange={(val) => update("home.servicesSection.description", val)}
            rows={2}
          />
        </FieldWrapper>
      </AccordionSection>

      {/* About Preview Section */}
      <AccordionSection title="5. About Preview Section" sectionKey="home.aboutPreview">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="home.aboutPreview.eyebrow">
            <input
              type="text"
              value={h.aboutPreview.eyebrow}
              onChange={(e) => update("home.aboutPreview.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="home.aboutPreview.title">
            <input
              type="text"
              value={h.aboutPreview.title}
              onChange={(e) => update("home.aboutPreview.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Paragraph 1" contentKey="home.aboutPreview.paragraph1" className="mt-4">
          <RichTextEditor
            value={h.aboutPreview.paragraph1}
            onChange={(val) => update("home.aboutPreview.paragraph1", val)}
            rows={3}
          />
        </FieldWrapper>
        <FieldWrapper label="Paragraph 2" contentKey="home.aboutPreview.paragraph2" className="mt-4">
          <RichTextEditor
            value={h.aboutPreview.paragraph2}
            onChange={(val) => update("home.aboutPreview.paragraph2", val)}
            rows={3}
          />
        </FieldWrapper>
        <div className="grid grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Stat 1 Number" contentKey="home.aboutPreview.stat1Number">
            <input
              type="text"
              value={h.aboutPreview.stat1Number}
              onChange={(e) => update("home.aboutPreview.stat1Number", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Stat 1 Label" contentKey="home.aboutPreview.stat1Label">
            <input
              type="text"
              value={h.aboutPreview.stat1Label}
              onChange={(e) => update("home.aboutPreview.stat1Label", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Stat 2 Number" contentKey="home.aboutPreview.stat2Number">
            <input
              type="text"
              value={h.aboutPreview.stat2Number}
              onChange={(e) => update("home.aboutPreview.stat2Number", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Stat 2 Label" contentKey="home.aboutPreview.stat2Label">
            <input
              type="text"
              value={h.aboutPreview.stat2Label}
              onChange={(e) => update("home.aboutPreview.stat2Label", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Button Label" contentKey="home.aboutPreview.buttonLabel">
            <input
              type="text"
              value={h.aboutPreview.buttonLabel}
              onChange={(e) => update("home.aboutPreview.buttonLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Photo Caption" contentKey="home.aboutPreview.photoCaption">
            <input
              type="text"
              value={h.aboutPreview.photoCaption}
              onChange={(e) => update("home.aboutPreview.photoCaption", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <div className="mt-4">
          <MediaField
            label="About Section Image"
            contentKey="home.aboutPreview.image"
            variant="image"
            hint="About preview photo, 550px tall column (cover). Recommended 1200×1400 portrait"
            value={h.aboutPreview.image}
            defaultValue={defaultSiteContent.home.aboutPreview.image}
            onChange={(val) => update("home.aboutPreview.image", val)}
            />
        </div>
      </AccordionSection>

      {/* Global Network Preview */}
      <AccordionSection title="6. Global Network Preview" sectionKey="home.networkPreview">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="home.networkPreview.eyebrow">
            <input
              type="text"
              value={h.networkPreview.eyebrow}
              onChange={(e) => update("home.networkPreview.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="home.networkPreview.title">
            <input
              type="text"
              value={h.networkPreview.title}
              onChange={(e) => update("home.networkPreview.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Button Label" contentKey="home.networkPreview.buttonLabel">
            <input
              type="text"
              value={h.networkPreview.buttonLabel}
              onChange={(e) => update("home.networkPreview.buttonLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Button Link" contentKey="home.networkPreview.buttonHref">
            <input
              type="text"
              value={h.networkPreview.buttonHref}
              onChange={(e) => update("home.networkPreview.buttonHref", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.networkPreview.description" className="mt-4">
          <RichTextEditor
            value={h.networkPreview.description}
            onChange={(val) => update("home.networkPreview.description", val)}
            rows={2}
          />
        </FieldWrapper>
      </AccordionSection>

      {/* Solutions Section Header */}
      <AccordionSection title="6b. Solutions Section Header" sectionKey="home.solutionsSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="home.solutionsSection.eyebrow">
            <input
              type="text"
              value={h.solutionsSection.eyebrow}
              onChange={(e) => update("home.solutionsSection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Section Title" contentKey="home.solutionsSection.title">
            <input
              type="text"
              value={h.solutionsSection.title}
              onChange={(e) => update("home.solutionsSection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="View All Link Text" contentKey="home.solutionsSection.viewAllLabel" className="md:col-span-2">
            <input
              type="text"
              value={h.solutionsSection.viewAllLabel}
              onChange={(e) => update("home.solutionsSection.viewAllLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.solutionsSection.description" className="mt-4">
          <RichTextEditor
            value={h.solutionsSection.description}
            onChange={(val) => update("home.solutionsSection.description", val)}
            rows={2}
          />
        </FieldWrapper>
      </AccordionSection>

      {/* Industries Grid */}
      <AccordionSection title="6c. Industries We Serve (8 Sectors)" sectionKey="industries">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <FieldWrapper label="Eyebrow" contentKey="home.industriesSection.eyebrow">
            <input
              type="text"
              value={h.industriesSection.eyebrow}
              onChange={(e) => update("home.industriesSection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Section Heading" contentKey="home.industriesSection.title">
            <input
              type="text"
              value={h.industriesSection.title}
              onChange={(e) => update("home.industriesSection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.industriesSection.description" className="mb-4">
          <RichTextEditor
            value={h.industriesSection.description}
            onChange={(val) => update("home.industriesSection.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {content.industries.map((ind, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">
                Industry #{idx + 1} ({`industries[${idx}]`})
              </span>
              <div className="grid grid-cols-2 gap-2">
                <FieldWrapper label="Industry Name" contentKey={`industries[${idx}].title`}>
                  <input
                    type="text"
                    value={ind.title}
                    onChange={(e) => update(`industries.${idx}.title`, e.target.value)}
                    className="cms-input font-bold"
                  />
                </FieldWrapper>
                <FieldWrapper label="Icon" contentKey={`industries[${idx}].icon`}>
                  <input
                    type="text"
                    value={ind.icon}
                    onChange={(e) => update(`industries.${idx}.icon`, e.target.value)}
                    className="cms-input font-mono text-xs"
                  />
                </FieldWrapper>
              </div>
              <div className="mt-2">
                <MediaField
                  label="Industry Card Image"
                  contentKey={`industries[${idx}].image`}
                  variant="image"
                  hint="Industry card tile, 212px tall (cover with dark overlay). Recommended 900×700"
                  value={ind.image}
                  defaultValue={defaultSiteContent.industries[idx]?.image}
                  onChange={(val) => update(`industries.${idx}.image`, val)}
                  />
              </div>
            </div>
          ))}
        </div>
      </AccordionSection>

      {/* Operations Journey */}
      <AccordionSection title="7. Operations Journey (7 Steps)" sectionKey="home.journeySection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <FieldWrapper label="Eyebrow" contentKey="home.journeySection.eyebrow">
            <input
              type="text"
              value={h.journeySection.eyebrow}
              onChange={(e) => update("home.journeySection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Section Title" contentKey="home.journeySection.title">
            <input
              type="text"
              value={h.journeySection.title}
              onChange={(e) => update("home.journeySection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.journeySection.description" className="mb-4">
          <RichTextEditor
            value={h.journeySection.description}
            onChange={(val) => update("home.journeySection.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="space-y-3">
          {h.journeySection.steps.map((st, idx) => (
            <div key={st.step} className="cms-sub-card flex items-center gap-4">
              <span className="font-bold text-amber-400 font-mono text-sm w-12">{st.step}</span>
              <FieldWrapper label="Step Label" contentKey={`home.journeySection.steps[${idx}].label`} className="flex-1">
                <input
                  type="text"
                  value={st.label}
                  onChange={(e) => update(`home.journeySection.steps.${idx}.label`, e.target.value)}
                  className="cms-input"
                />
              </FieldWrapper>
              <FieldWrapper label="Icon" contentKey={`home.journeySection.steps[${idx}].icon`} className="w-36">
                <input
                  type="text"
                  value={st.icon}
                  onChange={(e) => update(`home.journeySection.steps.${idx}.icon`, e.target.value)}
                  className="cms-input font-mono text-xs"
                />
              </FieldWrapper>
            </div>
          ))}
        </div>
      </AccordionSection>

      {/* Why Businesses Choose Us */}
      <AccordionSection title="8. Why Businesses Choose Us (6 Features)" sectionKey="home.whyChooseSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <FieldWrapper label="Eyebrow" contentKey="home.whyChooseSection.eyebrow">
            <input
              type="text"
              value={h.whyChooseSection.eyebrow}
              onChange={(e) => update("home.whyChooseSection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Title" contentKey="home.whyChooseSection.title">
            <input
              type="text"
              value={h.whyChooseSection.title}
              onChange={(e) => update("home.whyChooseSection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Watermark Top" contentKey="home.whyChooseSection.watermarkTop">
            <input
              type="text"
              value={h.whyChooseSection.watermarkTop}
              onChange={(e) => update("home.whyChooseSection.watermarkTop", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Watermark Bottom" contentKey="home.whyChooseSection.watermarkBottom">
            <input
              type="text"
              value={h.whyChooseSection.watermarkBottom}
              onChange={(e) => update("home.whyChooseSection.watermarkBottom", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.whyChooseSection.description" className="mb-4">
          <RichTextEditor
            value={h.whyChooseSection.description}
            onChange={(val) => update("home.whyChooseSection.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {h.whyChooseSection.features.map((f, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">
                Feature #{idx + 1} ({`home.whyChooseSection.features[${idx}]`})
              </span>
              <FieldWrapper label="Feature Title" contentKey={`home.whyChooseSection.features[${idx}].title`}>
                <input
                  type="text"
                  value={f.title}
                  onChange={(e) => update(`home.whyChooseSection.features.${idx}.title`, e.target.value)}
                  className="cms-input font-bold"
                />
              </FieldWrapper>
              <FieldWrapper label="Description" contentKey={`home.whyChooseSection.features[${idx}].description`} className="mt-2">
                <RichTextEditor
                  value={f.description}
                  onChange={(val) => update(`home.whyChooseSection.features.${idx}.description`, val)}
                  rows={2}
                />
              </FieldWrapper>
              <FieldWrapper label="Icon" contentKey={`home.whyChooseSection.features[${idx}].icon`} className="mt-2">
                <input
                  type="text"
                  value={f.icon}
                  onChange={(e) => update(`home.whyChooseSection.features.${idx}.icon`, e.target.value)}
                  className="cms-input font-mono text-xs"
                />
              </FieldWrapper>
            </div>
          ))}
        </div>
      </AccordionSection>

      {/* CTA Sections */}
      <AccordionSection title="9. Large & Compact CTA Sections" sectionKey="home.largeCta">
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Large Hero CTA</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="home.largeCta.eyebrow">
            <input
              type="text"
              value={h.largeCta.eyebrow}
              onChange={(e) => update("home.largeCta.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="home.largeCta.title">
            <input
              type="text"
              value={h.largeCta.title}
              onChange={(e) => update("home.largeCta.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Primary Button" contentKey="home.largeCta.primaryButton">
            <input
              type="text"
              value={h.largeCta.primaryButton}
              onChange={(e) => update("home.largeCta.primaryButton", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Secondary Button" contentKey="home.largeCta.secondaryButton">
            <input
              type="text"
              value={h.largeCta.secondaryButton}
              onChange={(e) => update("home.largeCta.secondaryButton", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="home.largeCta.description" className="mt-4">
          <RichTextEditor
            value={h.largeCta.description}
            onChange={(val) => update("home.largeCta.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="CTA Background Banner"
            contentKey="home.largeCta.bgImage"
            variant="banner"
            hint="Large CTA background banner (cover). Recommended 1920×900 desktop · 1080×1200 mobile"
            value={h.largeCta.bgImage}
            defaultValue={defaultSiteContent.home.largeCta.bgImage}
            onChange={(val) => update("home.largeCta.bgImage", val)}
            />
        </div>

        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mt-8 mb-2">Compact Bottom CTA</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="home.compactCta.eyebrow">
            <input
              type="text"
              value={h.compactCta.eyebrow}
              onChange={(e) => update("home.compactCta.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="home.compactCta.title">
            <input
              type="text"
              value={h.compactCta.title}
              onChange={(e) => update("home.compactCta.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Button Label" contentKey="home.compactCta.buttonLabel">
            <input
              type="text"
              value={h.compactCta.buttonLabel}
              onChange={(e) => update("home.compactCta.buttonLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
      </AccordionSection>

      {/* Footer */}
      <AccordionSection title="10. Footer — Logo, Text & Links" sectionKey="global.footer">
        <FooterSectionFields content={content} update={update} />
      </AccordionSection>
    </div>
  );
}

/* 3. About Us Page Editor */
function AboutPageEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const a = content.about;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. About Us Hero" sectionKey="about.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="about.hero.eyebrow">
            <input
              type="text"
              value={a.hero.eyebrow}
              onChange={(e) => update("about.hero.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Hero Title" contentKey="about.hero.title">
            <input
              type="text"
              value={a.hero.title}
              onChange={(e) => update("about.hero.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Hero Description" contentKey="about.hero.description" className="mt-4">
          <RichTextEditor
            value={a.hero.description}
            onChange={(val) => update("about.hero.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="About Hero Banner"
            contentKey="about.hero.bgImage"
            variant="banner"
            hint="About page hero banner, 480px tall (cover). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={a.hero.bgImage}
            defaultValue={defaultSiteContent.about.hero.bgImage}
            onChange={(val) => update("about.hero.bgImage", val)}
            />
        </div>
      </AccordionSection>

      <AccordionSection title="2. Editorial & Story" sectionKey="about.editorial">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="about.editorial.eyebrow">
            <input
              type="text"
              value={a.editorial.eyebrow}
              onChange={(e) => update("about.editorial.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Title" contentKey="about.editorial.title">
            <input
              type="text"
              value={a.editorial.title}
              onChange={(e) => update("about.editorial.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Paragraph 1" contentKey="about.editorial.paragraph1" className="mt-4">
          <RichTextEditor
            value={a.editorial.paragraph1}
            onChange={(val) => update("about.editorial.paragraph1", val)}
            rows={3}
          />
        </FieldWrapper>
        <FieldWrapper label="Paragraph 2" contentKey="about.editorial.paragraph2" className="mt-4">
          <RichTextEditor
            value={a.editorial.paragraph2}
            onChange={(val) => update("about.editorial.paragraph2", val)}
            rows={3}
          />
        </FieldWrapper>
        <div className="grid grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Button Label" contentKey="about.editorial.buttonLabel">
            <input
              type="text"
              value={a.editorial.buttonLabel}
              onChange={(e) => update("about.editorial.buttonLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Button Link" contentKey="about.editorial.buttonHref">
            <input
              type="text"
              value={a.editorial.buttonHref}
              onChange={(e) => update("about.editorial.buttonHref", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="3. Mission & Vision" sectionKey="about.missionVision">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="cms-sub-card">
            <FieldWrapper label="Mission Label" contentKey="about.missionVision.missionLabel">
              <input
                type="text"
                value={a.missionVision.missionLabel}
                onChange={(e) => update("about.missionVision.missionLabel", e.target.value)}
                className="cms-input font-mono text-xs"
              />
            </FieldWrapper>
            <FieldWrapper label="Mission Title" contentKey="about.missionVision.missionTitle" className="mt-2">
              <input
                type="text"
                value={a.missionVision.missionTitle}
                onChange={(e) => update("about.missionVision.missionTitle", e.target.value)}
                className="cms-input font-bold"
              />
            </FieldWrapper>
            <FieldWrapper label="Mission Description" contentKey="about.missionVision.missionDescription" className="mt-2">
              <RichTextEditor
                value={a.missionVision.missionDescription}
                onChange={(val) => update("about.missionVision.missionDescription", val)}
                rows={3}
              />
            </FieldWrapper>
          </div>

          <div className="cms-sub-card">
            <FieldWrapper label="Vision Label" contentKey="about.missionVision.visionLabel">
              <input
                type="text"
                value={a.missionVision.visionLabel}
                onChange={(e) => update("about.missionVision.visionLabel", e.target.value)}
                className="cms-input font-mono text-xs"
              />
            </FieldWrapper>
            <FieldWrapper label="Vision Title" contentKey="about.missionVision.visionTitle" className="mt-2">
              <input
                type="text"
                value={a.missionVision.visionTitle}
                onChange={(e) => update("about.missionVision.visionTitle", e.target.value)}
                className="cms-input font-bold"
              />
            </FieldWrapper>
            <FieldWrapper label="Vision Description" contentKey="about.missionVision.visionDescription" className="mt-2">
              <RichTextEditor
                value={a.missionVision.visionDescription}
                onChange={(val) => update("about.missionVision.visionDescription", val)}
                rows={3}
              />
            </FieldWrapper>
          </div>
        </div>
      </AccordionSection>

      <AccordionSection title="4. Core Values (5 Items)" sectionKey="about.valuesSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <FieldWrapper label="Eyebrow" contentKey="about.valuesSection.eyebrow">
            <input
              type="text"
              value={a.valuesSection.eyebrow}
              onChange={(e) => update("about.valuesSection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="about.valuesSection.title">
            <input
              type="text"
              value={a.valuesSection.title}
              onChange={(e) => update("about.valuesSection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {a.valuesSection.items.map((val, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">
                Value #{idx + 1} ({`about.valuesSection.items[${idx}]`})
              </span>
              <FieldWrapper label="Value Title" contentKey={`about.valuesSection.items[${idx}].title`}>
                <input
                  type="text"
                  value={val.title}
                  onChange={(e) => update(`about.valuesSection.items.${idx}.title`, e.target.value)}
                  className="cms-input font-bold"
                />
              </FieldWrapper>
              <FieldWrapper label="Text" contentKey={`about.valuesSection.items[${idx}].text`} className="mt-2">
                <RichTextEditor
                  value={val.text}
                  onChange={(v) => update(`about.valuesSection.items.${idx}.text`, v)}
                  rows={2}
                />
              </FieldWrapper>
            </div>
          ))}
        </div>
      </AccordionSection>
      <AccordionSection title="5. Capabilities Banner (Text + Background Image)" sectionKey="about.capabilitiesBanner">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="about.capabilitiesBanner.eyebrow">
            <input type="text" value={a.capabilitiesBanner.eyebrow} onChange={(e) => update("about.capabilitiesBanner.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="about.capabilitiesBanner.title">
            <input type="text" value={a.capabilitiesBanner.title} onChange={(e) => update("about.capabilitiesBanner.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Description" contentKey="about.capabilitiesBanner.description" className="mt-4">
            <RichTextEditor value={a.capabilitiesBanner.description} onChange={(val) => update("about.capabilitiesBanner.description", val)} rows={2} />
          </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Capabilities Background Banner"
            contentKey="about.capabilitiesBanner.bgImage"
            variant="banner"
            hint="Full-width photo band on the About page (cover, centred). Recommended 1920×800 desktop · 1080×1000 mobile"
            value={a.capabilitiesBanner.bgImage}
            defaultValue={defaultSiteContent.about.capabilitiesBanner.bgImage}
            onChange={(val) => update("about.capabilitiesBanner.bgImage", val)}
          />
        </div>
      </AccordionSection>

      <AccordionSection title="6. Milestones, Statistics & Disclaimer" sectionKey="about.milestonesSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="about.milestonesSection.eyebrow">
            <input type="text" value={a.milestonesSection.eyebrow} onChange={(e) => update("about.milestonesSection.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="about.milestonesSection.title">
            <input type="text" value={a.milestonesSection.title} onChange={(e) => update("about.milestonesSection.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Description" contentKey="about.milestonesSection.description" className="mt-4">
            <RichTextEditor value={a.milestonesSection.description} onChange={(val) => update("about.milestonesSection.description", val)} rows={2} />
          </FieldWrapper>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {a.milestonesSection.milestones.map((m, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">Milestone {m.step}</span>
              <FieldWrapper label="Title" contentKey={`about.milestonesSection.milestones[${idx}].title`}>
                <input type="text" value={m.title} onChange={(e) => update(`about.milestonesSection.milestones.${idx}.title`, e.target.value)} className="cms-input font-bold" />
              </FieldWrapper>
              <FieldWrapper label="Text" contentKey={`about.milestonesSection.milestones[${idx}].text`} className="mt-2">
                <RichTextEditor value={m.text} onChange={(val) => update(`about.milestonesSection.milestones.${idx}.text`, val)} rows={2} />
              </FieldWrapper>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          {a.milestonesSection.stats.map((st, idx) => (
            <div key={idx} className="cms-sub-card">
              <FieldWrapper label="Number" contentKey={`about.milestonesSection.stats[${idx}].number`}>
                <input type="text" value={st.number} onChange={(e) => update(`about.milestonesSection.stats.${idx}.number`, e.target.value)} className="cms-input font-bold" />
              </FieldWrapper>
              <FieldWrapper label="Label" contentKey={`about.milestonesSection.stats[${idx}].label`} className="mt-2">
                <input type="text" value={st.label} onChange={(e) => update(`about.milestonesSection.stats.${idx}.label`, e.target.value)} className="cms-input" />
              </FieldWrapper>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <FieldWrapper label="Disclaimer Note" contentKey="about.milestonesSection.disclaimer">
            <input type="text" value={a.milestonesSection.disclaimer} onChange={(e) => update("about.milestonesSection.disclaimer", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </AccordionSection>
    </div>
  );
}

/* 4. Services Page Editor */
function ServicesPageEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const s = content.services;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. Services Hero (Text + Banner)" sectionKey="services.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="services.hero.eyebrow">
            <input type="text" value={s.hero.eyebrow} onChange={(e) => update("services.hero.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Page Title" contentKey="services.hero.title">
            <input type="text" value={s.hero.title} onChange={(e) => update("services.hero.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Hero Description" contentKey="services.hero.description" className="mt-4">
            <RichTextEditor value={s.hero.description} onChange={(val) => update("services.hero.description", val)} rows={2} />
          </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Services Hero Banner"
            contentKey="services.hero.bgImage"
            variant="banner"
            hint="Page hero banner, 480px tall (cover, centred). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={s.hero.bgImage}
            defaultValue={defaultSiteContent.services.hero.bgImage}
            onChange={(val) => update("services.hero.bgImage", val)}
          />
        </div>
      </AccordionSection>

      <AccordionSection title="2. Overview Section" sectionKey="services.overview">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="services.overview.eyebrow">
            <input type="text" value={s.overview.eyebrow} onChange={(e) => update("services.overview.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="services.overview.title">
            <input type="text" value={s.overview.title} onChange={(e) => update("services.overview.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Description" contentKey="services.overview.description" className="mt-4">
            <RichTextEditor value={s.overview.description} onChange={(val) => update("services.overview.description", val)} rows={2} />
          </FieldWrapper>
      </AccordionSection>

      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider">Individual Services ({s.items.length}) — text + image</h3>
        {s.items.map((srv, idx) => (
          <AccordionSection key={srv.slug} title={`${idx + 3}. ${srv.title}`} sectionKey={`services.items[${idx}]`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FieldWrapper label="Service Title" contentKey={`services.items[${idx}].title`}>
                <input type="text" value={srv.title} onChange={(e) => update(`services.items.${idx}.title`, e.target.value)} className="cms-input font-bold" />
              </FieldWrapper>
              <FieldWrapper label="Short Description (Card)" contentKey={`services.items[${idx}].shortDescription`}>
                <input type="text" value={srv.shortDescription} onChange={(e) => update(`services.items.${idx}.shortDescription`, e.target.value)} className="cms-input" />
              </FieldWrapper>
            </div>
            <FieldWrapper label="Detailed Description (Service Page)" contentKey={`services.items[${idx}].longDescription`} className="mt-4">
              <RichTextEditor value={srv.longDescription} onChange={(val) => update(`services.items.${idx}.longDescription`, val)} rows={3} />
            </FieldWrapper>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              {srv.benefits.map((b, bIdx) => (
                <FieldWrapper key={bIdx} label={`Benefit #${bIdx + 1}`} contentKey={`services.items[${idx}].benefits[${bIdx}]`}>
                  <input
                    type="text"
                    value={b}
                    onChange={(e) => {
                      const next = [...srv.benefits];
                      next[bIdx] = e.target.value;
                      update(`services.items.${idx}.benefits`, next);
                    }}
                    className="cms-input"
                  />
                </FieldWrapper>
              ))}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <FieldWrapper label="Industries Served" contentKey={`services.items[${idx}].industriesServed`} className="md:col-span-2">
                <input type="text" value={srv.industriesServed} onChange={(e) => update(`services.items.${idx}.industriesServed`, e.target.value)} className="cms-input" />
              </FieldWrapper>
              <FieldWrapper label="Button Label" contentKey={`services.items[${idx}].buttonLabel`}>
                <input type="text" value={srv.buttonLabel} onChange={(e) => update(`services.items.${idx}.buttonLabel`, e.target.value)} className="cms-input" />
              </FieldWrapper>
            </div>
            <div className="mt-4">
              <MediaField
                label="Service Image"
                contentKey={`services.items[${idx}].image`}
                variant="image"
                hint="Service detail image on the Services page (cover). Recommended 1400×1000"
                value={srv.image}
                defaultValue={defaultSiteContent.services.items[idx]?.image}
                onChange={(val) => update(`services.items.${idx}.image`, val)}
              />
            </div>
          </AccordionSection>
        ))}
      </div>
    </div>
  );
}

/* 5. Solutions Page Editor */
function SolutionsPageEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const sol = content.solutions;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. Solutions Hero (Text + Banner)" sectionKey="solutions.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="solutions.hero.eyebrow">
            <input type="text" value={sol.hero.eyebrow} onChange={(e) => update("solutions.hero.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Page Title" contentKey="solutions.hero.title">
            <input type="text" value={sol.hero.title} onChange={(e) => update("solutions.hero.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Hero Description" contentKey="solutions.hero.description" className="mt-4">
            <RichTextEditor value={sol.hero.description} onChange={(val) => update("solutions.hero.description", val)} rows={2} />
          </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Solutions Hero Banner"
            contentKey="solutions.hero.bgImage"
            variant="banner"
            hint="Page hero banner, 480px tall (cover, centred). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={sol.hero.bgImage}
            defaultValue={defaultSiteContent.solutions.hero.bgImage}
            onChange={(val) => update("solutions.hero.bgImage", val)}
          />
        </div>
      </AccordionSection>

      <AccordionSection title="2. Overview & Details Headings" sectionKey="solutions.overview">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Overview Eyebrow" contentKey="solutions.overview.eyebrow">
            <input type="text" value={sol.overview.eyebrow} onChange={(e) => update("solutions.overview.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Overview Heading" contentKey="solutions.overview.title">
            <input type="text" value={sol.overview.title} onChange={(e) => update("solutions.overview.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Overview Description" contentKey="solutions.overview.description" className="mt-4">
            <RichTextEditor value={sol.overview.description} onChange={(val) => update("solutions.overview.description", val)} rows={2} />
          </FieldWrapper>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Details Eyebrow" contentKey="solutions.detailsHeader.eyebrow">
            <input type="text" value={sol.detailsHeader.eyebrow} onChange={(e) => update("solutions.detailsHeader.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Details Heading" contentKey="solutions.detailsHeader.title">
            <input type="text" value={sol.detailsHeader.title} onChange={(e) => update("solutions.detailsHeader.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider">Individual Solutions ({sol.items.length}) — text + image</h3>
        {sol.items.map((item, idx) => (
          <AccordionSection key={item.slug} title={`${idx + 3}. ${item.title}`} sectionKey={`solutions.items[${idx}]`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FieldWrapper label="Solution Title" contentKey={`solutions.items[${idx}].title`}>
                <input type="text" value={item.title} onChange={(e) => update(`solutions.items.${idx}.title`, e.target.value)} className="cms-input font-bold" />
              </FieldWrapper>
              <FieldWrapper label="Short Description" contentKey={`solutions.items[${idx}].description`}>
                <input type="text" value={item.description} onChange={(e) => update(`solutions.items.${idx}.description`, e.target.value)} className="cms-input" />
              </FieldWrapper>
              <FieldWrapper label="Target Audience (Who it is for)" contentKey={`solutions.items[${idx}].audience`}>
                <input type="text" value={item.audience} onChange={(e) => update(`solutions.items.${idx}.audience`, e.target.value)} className="cms-input" />
              </FieldWrapper>
              <FieldWrapper label="Main Benefit" contentKey={`solutions.items[${idx}].benefit`}>
                <input type="text" value={item.benefit} onChange={(e) => update(`solutions.items.${idx}.benefit`, e.target.value)} className="cms-input" />
              </FieldWrapper>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <FieldWrapper label="How We Help" contentKey={`solutions.items[${idx}].help`} className="md:col-span-2">
                <RichTextEditor value={item.help} onChange={(val) => update(`solutions.items.${idx}.help`, val)} rows={2} />
              </FieldWrapper>
              <FieldWrapper label="Link Text" contentKey={`solutions.items[${idx}].discussLinkText`}>
                <input type="text" value={item.discussLinkText} onChange={(e) => update(`solutions.items.${idx}.discussLinkText`, e.target.value)} className="cms-input" />
              </FieldWrapper>
            </div>
            <div className="mt-4">
              <MediaField
                label="Solution Image"
                contentKey={`solutions.items[${idx}].image`}
                variant="image"
                hint="Solution card image, 185px tall (cover, softened colours). Recommended 1200×800"
                value={item.image}
                defaultValue={defaultSiteContent.solutions.items[idx]?.image}
                onChange={(val) => update(`solutions.items.${idx}.image`, val)}
              />
            </div>
          </AccordionSection>
        ))}
      </div>
    </div>
  );
}

/* 6. Global Network Editor */
function GlobalNetworkEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const gn = content.globalNetwork;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. Global Network Hero (Text + Banner)" sectionKey="globalNetwork.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="globalNetwork.hero.eyebrow">
            <input type="text" value={gn.hero.eyebrow} onChange={(e) => update("globalNetwork.hero.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Page Title" contentKey="globalNetwork.hero.title">
            <input type="text" value={gn.hero.title} onChange={(e) => update("globalNetwork.hero.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Hero Description" contentKey="globalNetwork.hero.description" className="mt-4">
            <RichTextEditor value={gn.hero.description} onChange={(val) => update("globalNetwork.hero.description", val)} rows={2} />
          </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Global Network Hero Banner"
            contentKey="globalNetwork.hero.bgImage"
            variant="banner"
            hint="Page hero banner, 480px tall (cover, centred). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={gn.hero.bgImage}
            defaultValue={defaultSiteContent.globalNetwork.hero.bgImage}
            onChange={(val) => update("globalNetwork.hero.bgImage", val)}
          />
        </div>
      </AccordionSection>

      <AccordionSection title="2. Interactive Map Section" sectionKey="globalNetwork.mapSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="globalNetwork.mapSection.eyebrow">
            <input type="text" value={gn.mapSection.eyebrow} onChange={(e) => update("globalNetwork.mapSection.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="globalNetwork.mapSection.title">
            <input type="text" value={gn.mapSection.title} onChange={(e) => update("globalNetwork.mapSection.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Region Selector Prompt" contentKey="globalNetwork.mapSection.selectRegionPrompt">
            <input type="text" value={gn.mapSection.selectRegionPrompt} onChange={(e) => update("globalNetwork.mapSection.selectRegionPrompt", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Map Coordinate Label" contentKey="globalNetwork.mapSection.coordinateText">
            <input type="text" value={gn.mapSection.coordinateText} onChange={(e) => update("globalNetwork.mapSection.coordinateText", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Description" contentKey="globalNetwork.mapSection.description" className="mt-4">
            <RichTextEditor value={gn.mapSection.description} onChange={(val) => update("globalNetwork.mapSection.description", val)} rows={2} />
          </FieldWrapper>
          <FieldWrapper label="Map Caveat Note" contentKey="globalNetwork.mapSection.caveat" className="mt-4">
            <RichTextEditor value={gn.mapSection.caveat} onChange={(val) => update("globalNetwork.mapSection.caveat", val)} rows={2} />
          </FieldWrapper>
      </AccordionSection>

      <AccordionSection title="3. World Regions (6 Regions)" sectionKey="globalNetwork.regions">
        <div className="space-y-4">
          {gn.regions.map((reg, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="font-bold text-amber-400 font-mono text-sm block mb-2">Region #{idx + 1}: {reg.name}</span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <FieldWrapper label="Region Name" contentKey={`globalNetwork.regions[${idx}].name`}>
                  <input type="text" value={reg.name} onChange={(e) => update(`globalNetwork.regions.${idx}.name`, e.target.value)} className="cms-input font-bold" />
                </FieldWrapper>
                <FieldWrapper label="Major Destinations" contentKey={`globalNetwork.regions[${idx}].destinations`} className="md:col-span-2">
                  <input type="text" value={reg.destinations} onChange={(e) => update(`globalNetwork.regions.${idx}.destinations`, e.target.value)} className="cms-input" />
                </FieldWrapper>
                <FieldWrapper label="Transport Modes" contentKey={`globalNetwork.regions[${idx}].modes`}>
                  <input type="text" value={reg.modes} onChange={(e) => update(`globalNetwork.regions.${idx}.modes`, e.target.value)} className="cms-input" />
                </FieldWrapper>
                <FieldWrapper label="Available Services" contentKey={`globalNetwork.regions[${idx}].services`} className="md:col-span-2">
                  <input type="text" value={reg.services} onChange={(e) => update(`globalNetwork.regions.${idx}.services`, e.target.value)} className="cms-input" />
                </FieldWrapper>
              </div>
            </div>
          ))}
        </div>
      </AccordionSection>

      <AccordionSection title="4. Connected Capabilities" sectionKey="globalNetwork.capabilitiesSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="globalNetwork.capabilitiesSection.eyebrow">
            <input type="text" value={gn.capabilitiesSection.eyebrow} onChange={(e) => update("globalNetwork.capabilitiesSection.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Heading" contentKey="globalNetwork.capabilitiesSection.title">
            <input type="text" value={gn.capabilitiesSection.title} onChange={(e) => update("globalNetwork.capabilitiesSection.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Button Label" contentKey="globalNetwork.capabilitiesSection.buttonLabel">
            <input type="text" value={gn.capabilitiesSection.buttonLabel} onChange={(e) => update("globalNetwork.capabilitiesSection.buttonLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Button Link" contentKey="globalNetwork.capabilitiesSection.buttonHref">
            <input type="text" value={gn.capabilitiesSection.buttonHref} onChange={(e) => update("globalNetwork.capabilitiesSection.buttonHref", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Description" contentKey="globalNetwork.capabilitiesSection.description" className="mt-4">
            <RichTextEditor value={gn.capabilitiesSection.description} onChange={(val) => update("globalNetwork.capabilitiesSection.description", val)} rows={2} />
          </FieldWrapper>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
          {gn.capabilitiesSection.items.map((item, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">Item {item.step}</span>
              <FieldWrapper label="Title" contentKey={`globalNetwork.capabilitiesSection.items[${idx}].title`}>
                <input type="text" value={item.title} onChange={(e) => update(`globalNetwork.capabilitiesSection.items.${idx}.title`, e.target.value)} className="cms-input font-bold" />
              </FieldWrapper>
              <FieldWrapper label="Description" contentKey={`globalNetwork.capabilitiesSection.items[${idx}].description`} className="mt-2">
                <RichTextEditor value={item.description} onChange={(val) => update(`globalNetwork.capabilitiesSection.items.${idx}.description`, val)} rows={2} />
              </FieldWrapper>
            </div>
          ))}
        </div>
      </AccordionSection>
    </div>
  );
}

/* 7. Tracking Page Editor */
function TrackingEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const t = content.tracking;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. Tracking Hero (Text + Banner)" sectionKey="tracking.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="tracking.hero.eyebrow">
            <input type="text" value={t.hero.eyebrow} onChange={(e) => update("tracking.hero.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Page Title" contentKey="tracking.hero.title">
            <input type="text" value={t.hero.title} onChange={(e) => update("tracking.hero.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Hero Description" contentKey="tracking.hero.description" className="mt-4">
            <RichTextEditor value={t.hero.description} onChange={(val) => update("tracking.hero.description", val)} rows={2} />
          </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Tracking Hero Banner"
            contentKey="tracking.hero.bgImage"
            variant="banner"
            hint="Page hero banner, 480px tall (cover, centred). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={t.hero.bgImage}
            defaultValue={defaultSiteContent.tracking.hero.bgImage}
            onChange={(val) => update("tracking.hero.bgImage", val)}
          />
        </div>
      </AccordionSection>

      <AccordionSection title="2. Tracking Form Labels" sectionKey="tracking.form" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Micro Label" contentKey="tracking.form.microLabel">
            <input type="text" value={t.form.microLabel} onChange={(e) => update("tracking.form.microLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Form Title" contentKey="tracking.form.title">
            <input type="text" value={t.form.title} onChange={(e) => update("tracking.form.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Form Subtitle" contentKey="tracking.form.subtitle" className="md:col-span-2">
            <input type="text" value={t.form.subtitle} onChange={(e) => update("tracking.form.subtitle", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Input Label" contentKey="tracking.form.inputLabel">
            <input type="text" value={t.form.inputLabel} onChange={(e) => update("tracking.form.inputLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Input Placeholder" contentKey="tracking.form.inputPlaceholder">
            <input type="text" value={t.form.inputPlaceholder} onChange={(e) => update("tracking.form.inputPlaceholder", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Shipment Type Label" contentKey="tracking.form.selectLabel">
            <input type="text" value={t.form.selectLabel} onChange={(e) => update("tracking.form.selectLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Button Label" contentKey="tracking.form.buttonLabel">
            <input type="text" value={t.form.buttonLabel} onChange={(e) => update("tracking.form.buttonLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Searching Label" contentKey="tracking.form.searchingLabel">
            <input type="text" value={t.form.searchingLabel} onChange={(e) => update("tracking.form.searchingLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="3. Demo Hint & Sample Data" sectionKey="tracking.demoHint">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FieldWrapper label="Badge Label" contentKey="tracking.demoHint.badge">
            <input type="text" value={t.demoHint.badge} onChange={(e) => update("tracking.demoHint.badge", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Demo Reference Number" contentKey="tracking.demoHint.sampleNumber">
            <input type="text" value={t.demoHint.sampleNumber} onChange={(e) => update("tracking.demoHint.sampleNumber", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Info Button Label" contentKey="tracking.demoHint.infoButtonLabel">
            <input type="text" value={t.demoHint.infoButtonLabel} onChange={(e) => update("tracking.demoHint.infoButtonLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Hint Text" contentKey="tracking.demoHint.text" className="md:col-span-3">
            <input type="text" value={t.demoHint.text} onChange={(e) => update("tracking.demoHint.text", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Sample Status" contentKey="tracking.sampleResult.statusText">
            <input type="text" value={t.sampleResult.statusText} onChange={(e) => update("tracking.sampleResult.statusText", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sample Banner Text" contentKey="tracking.sampleResult.bannerText">
            <input type="text" value={t.sampleResult.bannerText} onChange={(e) => update("tracking.sampleResult.bannerText", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sample Origin" contentKey="tracking.sampleResult.originValue">
            <input type="text" value={t.sampleResult.originValue} onChange={(e) => update("tracking.sampleResult.originValue", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sample Destination" contentKey="tracking.sampleResult.destinationValue">
            <input type="text" value={t.sampleResult.destinationValue} onChange={(e) => update("tracking.sampleResult.destinationValue", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sample Estimated Delivery" contentKey="tracking.sampleResult.deliveryValue">
            <input type="text" value={t.sampleResult.deliveryValue} onChange={(e) => update("tracking.sampleResult.deliveryValue", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sample Shipment Type" contentKey="tracking.sampleResult.shipmentTypeValue">
            <input type="text" value={t.sampleResult.shipmentTypeValue} onChange={(e) => update("tracking.sampleResult.shipmentTypeValue", e.target.value)} className="cms-input" />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="4. Empty State, Help Box & Info Modal" sectionKey="tracking.helpBox">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="No-result Title" contentKey="tracking.emptyState.title">
            <input type="text" value={t.emptyState.title} onChange={(e) => update("tracking.emptyState.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="No-result Text Prefix" contentKey="tracking.emptyState.textPrefix">
            <input type="text" value={t.emptyState.textPrefix} onChange={(e) => update("tracking.emptyState.textPrefix", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="No-result Text Suffix" contentKey="tracking.emptyState.textSuffix" className="md:col-span-2">
            <RichTextEditor value={t.emptyState.textSuffix} onChange={(val) => update("tracking.emptyState.textSuffix", val)} rows={2} />
          </FieldWrapper>
          <FieldWrapper label="Help Box Title" contentKey="tracking.helpBox.title">
            <input type="text" value={t.helpBox.title} onChange={(e) => update("tracking.helpBox.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Help Box Button Label" contentKey="tracking.helpBox.buttonLabel">
            <input type="text" value={t.helpBox.buttonLabel} onChange={(e) => update("tracking.helpBox.buttonLabel", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Help Box Description" contentKey="tracking.helpBox.description" className="md:col-span-2">
            <RichTextEditor value={t.helpBox.description} onChange={(val) => update("tracking.helpBox.description", val)} rows={2} />
          </FieldWrapper>
          <FieldWrapper label="Modal Title" contentKey="tracking.modal.title" className="md:col-span-2">
            <input type="text" value={t.modal.title} onChange={(e) => update("tracking.modal.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Modal Paragraph 1" contentKey="tracking.modal.paragraph1">
            <RichTextEditor value={t.modal.paragraph1} onChange={(val) => update("tracking.modal.paragraph1", val)} rows={2} />
          </FieldWrapper>
          <FieldWrapper label="Modal Paragraph 2" contentKey="tracking.modal.paragraph2">
            <RichTextEditor value={t.modal.paragraph2} onChange={(val) => update("tracking.modal.paragraph2", val)} rows={2} />
          </FieldWrapper>
        </div>
      </AccordionSection>
    </div>
  );
}

/* 8. Quote Page Editor */
function QuoteEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const q = content.quote;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. Quote Hero & Side Panel" sectionKey="quote.sidePanel" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Hero Eyebrow" contentKey="quote.hero.eyebrow">
            <input
              type="text"
              value={q.hero.eyebrow}
              onChange={(e) => update("quote.hero.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Hero Title" contentKey="quote.hero.title">
            <input
              type="text"
              value={q.hero.title}
              onChange={(e) => update("quote.hero.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Side Panel Heading" contentKey="quote.sidePanel.title" className="md:col-span-2">
            <input
              type="text"
              value={q.sidePanel.title}
              onChange={(e) => update("quote.sidePanel.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
          <FieldWrapper label="Hero Description" contentKey="quote.hero.description" className="mt-4">
            <RichTextEditor value={q.hero.description} onChange={(val) => update("quote.hero.description", val)} rows={2} />
          </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Quote Hero Banner"
            contentKey="quote.hero.bgImage"
            variant="banner"
            hint="Quote page hero banner, 480px tall (cover, centred). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={q.hero.bgImage}
            defaultValue={defaultSiteContent.quote.hero.bgImage}
            onChange={(val) => update("quote.hero.bgImage", val)}
          />
        </div>
        <FieldWrapper label="Side Panel Description" contentKey="quote.sidePanel.description" className="mt-4">
          <RichTextEditor
            value={q.sidePanel.description}
            onChange={(val) => update("quote.sidePanel.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="space-y-2 mt-4">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Side Panel Steps</span>
          {q.sidePanel.points.map((pt, idx) => (
            <div key={idx} className="flex gap-2 items-center">
              <span className="font-mono text-amber-400 font-bold text-xs w-8">{pt.step}</span>
              <input
                type="text"
                value={pt.text}
                onChange={(e) => update(`quote.sidePanel.points.${idx}.text`, e.target.value)}
                className="cms-input flex-1"
              />
            </div>
          ))}
        </div>
        <FieldWrapper label="Security Note" contentKey="quote.sidePanel.note" className="mt-4">
          <input
            type="text"
            value={q.sidePanel.note}
            onChange={(e) => update("quote.sidePanel.note", e.target.value)}
            className="cms-input"
          />
        </FieldWrapper>
      </AccordionSection>

      <AccordionSection title="2. Quote Form Labels & Placeholders" sectionKey="quote.form">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Form Title" contentKey="quote.form.title">
            <input
              type="text"
              value={q.form.title}
              onChange={(e) => update("quote.form.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Form Subtitle" contentKey="quote.form.subtitle">
            <input
              type="text"
              value={q.form.subtitle}
              onChange={(e) => update("quote.form.subtitle", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Submit Button Label" contentKey="quote.form.buttonLabel">
            <input
              type="text"
              value={q.form.buttonLabel}
              onChange={(e) => update("quote.form.buttonLabel", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Submitting Status Label" contentKey="quote.form.submittingLabel">
            <input
              type="text"
              value={q.form.submittingLabel}
              onChange={(e) => update("quote.form.submittingLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Privacy Note" contentKey="quote.form.privacyNote" className="md:col-span-2">
            <input
              type="text"
              value={q.form.privacyNote}
              onChange={(e) => update("quote.form.privacyNote", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="3. Form Submission Success State" sectionKey="quote.form.success">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Success Heading" contentKey="quote.form.success.title">
            <input
              type="text"
              value={q.form.success.title}
              onChange={(e) => update("quote.form.success.title", e.target.value)}
              className="cms-input font-bold text-emerald-400"
            />
          </FieldWrapper>
          <FieldWrapper label="Toast Notification Text" contentKey="quote.form.success.toastMessage">
            <input
              type="text"
              value={q.form.success.toastMessage}
              onChange={(e) => update("quote.form.success.toastMessage", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Success Description" contentKey="quote.form.success.description" className="mt-4">
          <RichTextEditor
            value={q.form.success.description}
            onChange={(val) => update("quote.form.success.description", val)}
            rows={2}
          />
        </FieldWrapper>
      </AccordionSection>
    </div>
  );
}

/* 9. Contact Page Editor */
function ContactEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const c = content.contact;
  return (
    <div className="space-y-6">
      <AccordionSection title="1. Contact Hero & Sidebar" sectionKey="contact.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Hero Eyebrow" contentKey="contact.hero.eyebrow">
            <input
              type="text"
              value={c.hero.eyebrow}
              onChange={(e) => update("contact.hero.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Hero Title" contentKey="contact.hero.title">
            <input
              type="text"
              value={c.hero.title}
              onChange={(e) => update("contact.hero.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Hero Description" contentKey="contact.hero.description" className="mt-4">
          <RichTextEditor
            value={c.hero.description}
            onChange={(val) => update("contact.hero.description", val)}
            rows={2}
          />
        </FieldWrapper>
        <div className="mt-4">
          <MediaField
            label="Contact Hero Banner"
            contentKey="contact.hero.bgImage"
            variant="banner"
            hint="Contact page hero banner, 480px tall (cover, centred). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={c.hero.bgImage}
            defaultValue={defaultSiteContent.contact.hero.bgImage}
            onChange={(val) => update("contact.hero.bgImage", val)}
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <FieldWrapper label="Sidebar Eyebrow" contentKey="contact.sidePanel.eyebrow">
            <input type="text" value={c.sidePanel.eyebrow} onChange={(e) => update("contact.sidePanel.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sidebar Heading" contentKey="contact.sidePanel.title">
            <input type="text" value={c.sidePanel.title} onChange={(e) => update("contact.sidePanel.title", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Sidebar Description" contentKey="contact.sidePanel.description" className="md:col-span-2">
            <RichTextEditor value={c.sidePanel.description} onChange={(val) => update("contact.sidePanel.description", val)} rows={2} />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="2. Contact Form Settings" sectionKey="contact.form">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Form Title" contentKey="contact.form.title">
            <input
              type="text"
              value={c.form.title}
              onChange={(e) => update("contact.form.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Form Subtitle" contentKey="contact.form.subtitle">
            <input
              type="text"
              value={c.form.subtitle}
              onChange={(e) => update("contact.form.subtitle", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Submit Button Label" contentKey="contact.form.buttonLabel">
            <input
              type="text"
              value={c.form.buttonLabel}
              onChange={(e) => update("contact.form.buttonLabel", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Submitting Status Label" contentKey="contact.form.submittingLabel">
            <input
              type="text"
              value={c.form.submittingLabel}
              onChange={(e) => update("contact.form.submittingLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Privacy Note" contentKey="contact.form.privacyNote" className="md:col-span-2">
            <input
              type="text"
              value={c.form.privacyNote}
              onChange={(e) => update("contact.form.privacyNote", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
      </AccordionSection>

      <AccordionSection title="3. Location Section" sectionKey="contact.locationSection">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="contact.locationSection.eyebrow">
            <input
              type="text"
              value={c.locationSection.eyebrow}
              onChange={(e) => update("contact.locationSection.eyebrow", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
          <FieldWrapper label="Title" contentKey="contact.locationSection.title">
            <input
              type="text"
              value={c.locationSection.title}
              onChange={(e) => update("contact.locationSection.title", e.target.value)}
              className="cms-input font-bold"
            />
          </FieldWrapper>
          <FieldWrapper label="Button Label" contentKey="contact.locationSection.buttonLabel">
            <input
              type="text"
              value={c.locationSection.buttonLabel}
              onChange={(e) => update("contact.locationSection.buttonLabel", e.target.value)}
              className="cms-input"
            />
          </FieldWrapper>
        </div>
        <FieldWrapper label="Description" contentKey="contact.locationSection.description" className="mt-4">
          <RichTextEditor
            value={c.locationSection.description}
            onChange={(val) => update("contact.locationSection.description", val)}
            rows={2}
          />
        </FieldWrapper>
      </AccordionSection>

      <AccordionSection title="4. Frequently Asked Questions (FAQ)" sectionKey="contact.faqSection" defaultOpen={true}>
        <div className="space-y-4">
          {c.faqSection.items.map((item, idx) => (
            <div key={idx} className="cms-sub-card">
              <span className="text-xs font-mono text-amber-400 font-bold mb-2 block">
                FAQ #{idx + 1} ({`contact.faqSection.items[${idx}]`})
              </span>
              <FieldWrapper label="Question" contentKey={`contact.faqSection.items[${idx}].question`}>
                <input
                  type="text"
                  value={item.question}
                  onChange={(e) => update(`contact.faqSection.items.${idx}.question`, e.target.value)}
                  className="cms-input font-bold"
                />
              </FieldWrapper>
              <FieldWrapper label="Answer" contentKey={`contact.faqSection.items[${idx}].answer`} className="mt-2">
                <RichTextEditor
                  value={item.answer}
                  onChange={(val) => update(`contact.faqSection.items.${idx}.answer`, val)}
                  rows={2}
                />
              </FieldWrapper>
            </div>
          ))}
        </div>
      </AccordionSection>
    </div>
  );
}

/* 10. Legal & Policies Editor */
function LegalEditor({ content, update }: { content: SiteContent; update: (path: string, val: any) => void }) {
  const l = content.legal;
  const policy = (key: "privacy" | "terms" | "cookies", title: string, route: string) => (
    <AccordionSection title={`${title} (${route})`} sectionKey={`legal.${key}`}>
      <FieldWrapper label="Page Title" contentKey={`legal.${key}.title`}>
        <input type="text" value={l[key].title} onChange={(e) => update(`legal.${key}.title`, e.target.value)} className="cms-input font-bold" />
      </FieldWrapper>
      <FieldWrapper label="Paragraph 1" contentKey={`legal.${key}.paragraph1`} className="mt-3">
        <RichTextEditor value={l[key].paragraph1} onChange={(val) => update(`legal.${key}.paragraph1`, val)} rows={3} />
      </FieldWrapper>
      <FieldWrapper label="Paragraph 2" contentKey={`legal.${key}.paragraph2`} className="mt-3">
        <RichTextEditor value={l[key].paragraph2} onChange={(val) => update(`legal.${key}.paragraph2`, val)} rows={3} />
      </FieldWrapper>
    </AccordionSection>
  );
  return (
    <div className="space-y-6">
      <AccordionSection title="Legal Pages Hero (shared by all 3 pages)" sectionKey="legal.hero" defaultOpen={true}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FieldWrapper label="Eyebrow" contentKey="legal.hero.eyebrow">
            <input type="text" value={l.hero.eyebrow} onChange={(e) => update("legal.hero.eyebrow", e.target.value)} className="cms-input" />
          </FieldWrapper>
          <FieldWrapper label="Hero Description" contentKey="legal.hero.description">
            <RichTextEditor value={l.hero.description} onChange={(val) => update("legal.hero.description", val)} rows={2} />
          </FieldWrapper>
        </div>
        <div className="mt-4">
          <MediaField
            label="Legal Hero Banner"
            contentKey="legal.hero.bgImage"
            variant="banner"
            hint="Hero banner for Privacy, Terms and Cookie pages, 480px tall (cover). Recommended 1920×900 desktop · 1080×1000 mobile"
            value={l.hero.bgImage}
            defaultValue={defaultSiteContent.legal.hero.bgImage}
            onChange={(val) => update("legal.hero.bgImage", val)}
          />
        </div>
          <FieldWrapper label="Demonstration Notice Banner" contentKey="legal.note" className="mt-4">
            <RichTextEditor value={l.note} onChange={(val) => update("legal.note", val)} rows={2} />
          </FieldWrapper>
      </AccordionSection>
      {policy("privacy", "Privacy Policy", "/privacy")}
      {policy("terms", "Terms & Conditions", "/terms")}
      {policy("cookies", "Cookie Policy", "/cookies")}
    </div>
  );
}
