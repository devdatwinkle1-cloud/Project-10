import { NextRequest, NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { cmsMedia } from "@/db/schema";
import { ACCEPTED_IMAGE_TYPES, MAX_UPLOAD_BYTES, MEDIA_API_PREFIX } from "@/lib/media";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const MAX_DIMENSION = 2560; // large uploads are downscaled to keep pages fast

/** GET /api/media — list uploaded images (metadata only, no binary data). */
export async function GET() {
  try {
    const rows = await db
      .select({
        id: cmsMedia.id,
        filename: cmsMedia.filename,
        mimeType: cmsMedia.mimeType,
        size: cmsMedia.size,
        width: cmsMedia.width,
        height: cmsMedia.height,
        alt: cmsMedia.alt,
        createdAt: cmsMedia.createdAt,
      })
      .from(cmsMedia)
      .orderBy(desc(cmsMedia.createdAt))
      .limit(60);

    return NextResponse.json({
      success: true,
      media: rows.map((r) => ({ ...r, url: `${MEDIA_API_PREFIX}${r.id}` })),
    });
  } catch (error) {
    console.error("[media] list failed", error);
    return NextResponse.json({ success: false, error: "Failed to list media" }, { status: 500 });
  }
}

/** POST /api/media — multipart upload (field name: "file", optional "alt"). */
export async function POST(request: NextRequest) {
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ success: false, error: "Invalid upload request." }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ success: false, error: "No file received." }, { status: 400 });
  }

  const mimeType = (file.type || "").toLowerCase();
  if (!ACCEPTED_IMAGE_TYPES.includes(mimeType)) {
    return NextResponse.json(
      { success: false, error: "Unsupported file type. Please upload JPG, PNG, WEBP, GIF, AVIF or SVG." },
      { status: 415 },
    );
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return NextResponse.json(
      { success: false, error: `File is too large. Maximum size is ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)} MB.` },
      { status: 413 },
    );
  }

  let buffer = Buffer.from(await file.arrayBuffer());
  let width: number | null = null;
  let height: number | null = null;

  // Read dimensions and downscale very large raster images (best-effort; original kept on failure).
  if (mimeType !== "image/svg+xml" && mimeType !== "image/gif") {
    try {
      const sharp = (await import("sharp")).default;
      const image = sharp(buffer, { failOn: "none" });
      const meta = await image.metadata();
      width = meta.width ?? null;
      height = meta.height ?? null;

      if ((meta.width ?? 0) > MAX_DIMENSION || (meta.height ?? 0) > MAX_DIMENSION) {
        const resized = image.rotate().resize({
          width: MAX_DIMENSION,
          height: MAX_DIMENSION,
          fit: "inside",
          withoutEnlargement: true,
        });
        const encoded =
          mimeType === "image/png"
            ? resized.png({ compressionLevel: 9 })
            : mimeType === "image/webp"
              ? resized.webp({ quality: 85 })
              : mimeType === "image/avif"
                ? resized.avif({ quality: 60 })
                : resized.jpeg({ quality: 84, mozjpeg: true });
        const { data, info } = await encoded.toBuffer({ resolveWithObject: true });
        buffer = Buffer.from(data);
        width = info.width;
        height = info.height;
      }
    } catch (error) {
      console.warn("[media] image processing skipped:", error instanceof Error ? error.message : error);
    }
  }

  const altRaw = form.get("alt");
  const alt = typeof altRaw === "string" ? altRaw.slice(0, 500) : "";
  const filename = (file.name || "upload").replace(/[^\w.\- ()]/g, "_").slice(0, 255);

  try {
    const [row] = await db
      .insert(cmsMedia)
      .values({ filename, mimeType, size: buffer.length, width, height, alt, data: buffer })
      .returning({
        id: cmsMedia.id,
        filename: cmsMedia.filename,
        mimeType: cmsMedia.mimeType,
        size: cmsMedia.size,
        width: cmsMedia.width,
        height: cmsMedia.height,
        alt: cmsMedia.alt,
        createdAt: cmsMedia.createdAt,
      });

    return NextResponse.json({ success: true, media: { ...row, url: `${MEDIA_API_PREFIX}${row.id}` } });
  } catch (error) {
    console.error("[media] insert failed", error);
    return NextResponse.json({ success: false, error: "Could not store the image. Please try again." }, { status: 500 });
  }
}
