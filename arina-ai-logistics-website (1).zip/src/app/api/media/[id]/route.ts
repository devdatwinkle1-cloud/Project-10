import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { cmsMedia } from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function parseId(raw: string) {
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

/** GET /api/media/[id] — serves the stored image bytes with long-lived caching. */
export async function GET(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id: rawId } = await params;
  const id = parseId(rawId);
  if (!id) return new NextResponse("Not found", { status: 404 });

  try {
    const rows = await db.select().from(cmsMedia).where(eq(cmsMedia.id, id)).limit(1);
    const row = rows[0];
    if (!row) return new NextResponse("Not found", { status: 404 });

    const headers: Record<string, string> = {
      "Content-Type": row.mimeType,
      "Content-Length": String(row.size),
      "Cache-Control": "public, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
      "Content-Disposition": `inline; filename="${row.filename.replace(/"/g, "")}"`,
    };
    // SVG can contain scripts — never let it execute in the site's origin.
    if (row.mimeType === "image/svg+xml") {
      headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
    }

    return new NextResponse(new Uint8Array(row.data), { status: 200, headers });
  } catch (error) {
    console.error("[media] read failed", error);
    return new NextResponse("Server error", { status: 500 });
  }
}

/** DELETE /api/media/[id] — removes an uploaded image from storage. */
export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id: rawId } = await params;
  const id = parseId(rawId);
  if (!id) return NextResponse.json({ success: false, error: "Invalid id" }, { status: 400 });

  try {
    const deleted = await db.delete(cmsMedia).where(eq(cmsMedia.id, id)).returning({ id: cmsMedia.id });
    if (deleted.length === 0) {
      return NextResponse.json({ success: false, error: "Image not found" }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[media] delete failed", error);
    return NextResponse.json({ success: false, error: "Failed to delete image" }, { status: 500 });
  }
}
