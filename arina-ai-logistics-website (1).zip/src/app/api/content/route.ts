import { NextRequest, NextResponse } from "next/server";
import { getSiteContent, saveSiteContent } from "@/lib/cms-server";
import { SiteContent } from "@/lib/cms-types";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const content = await getSiteContent();
    return NextResponse.json({ success: true, content });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to load content" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (!body || !body.content) {
      return NextResponse.json({ success: false, error: "Missing content payload" }, { status: 400 });
    }

    const result = await saveSiteContent(body.content as SiteContent);
    if (!result.success) {
      return NextResponse.json({ success: false, error: result.error || "Failed to save" }, { status: 500 });
    }

    return NextResponse.json({ success: true, version: result.version, message: "Content published successfully." });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Invalid request payload" }, { status: 400 });
  }
}
