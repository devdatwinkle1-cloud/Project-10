import { NextResponse } from "next/server";
import { resetSiteContent } from "@/lib/cms-server";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    const result = await resetSiteContent();
    if (!result.success) {
      return NextResponse.json({ success: false, error: result.error || "Failed to reset" }, { status: 500 });
    }
    return NextResponse.json({ success: true, message: "Site content has been reset to default values." });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to reset content" }, { status: 500 });
  }
}
