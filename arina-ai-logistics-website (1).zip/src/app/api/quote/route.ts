import { NextRequest } from "next/server";
import { handleInquiry } from "@/lib/inquiries";
export async function POST(request: NextRequest) { return handleInquiry(request, "quote"); }
