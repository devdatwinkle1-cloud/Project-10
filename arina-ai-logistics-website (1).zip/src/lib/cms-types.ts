/** A single image used inside a section (alt text is used for accessibility & SEO). */
export interface ImageAsset {
  src: string;
  alt: string;
}

/** A full-width banner/background. mobileSrc is optional and falls back to src. */
export interface BannerAsset {
  src: string;
  mobileSrc: string;
  alt: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface BrandingContent {
  /** Logo shown on light backgrounds (solid header). Empty = built-in ARINA mark. */
  logo: ImageAsset;
  /** Logo shown on dark backgrounds (transparent header over hero, footer). Falls back to logo. */
  logoLight: ImageAsset;
  /** Optional smaller logo for the mobile header (up to 760px). Falls back to logo. */
  logoMobile: ImageAsset;
  favicon: ImageAsset;
  /** Show the company name + subtitle text next to the logo mark. */
  showBrandText: boolean;
}

export interface FooterHeadings {
  company: string;
  services: string;
  solutions: string;
  support: string;
  contact: string;
}

export interface GlobalContent {
  branding: BrandingContent;
  navigation: NavItem[];
  footerHeadings: FooterHeadings;
  companyName: string;
  companySubtitle: string;
  tagline: string;
  footerMission: string;
  footerBottomTagline: string;
  copyright: string;
  phone: string;
  email: string;
  address: string;
  workingHours: string;
  workingHoursNote: string;
  socialLinks: {
    linkedin: string;
    instagram: string;
    facebook: string;
  };
  headerTrackButton: string;
  headerQuoteButton: string;
  meta: {
    defaultTitle: string;
    defaultDescription: string;
  };
}

export interface StatItem {
  number: number;
  suffix: string;
  label: string;
}

export interface JourneyStep {
  step: string;
  label: string;
  icon: string;
}

export interface FeatureItem {
  title: string;
  description: string;
  icon: string;
}

export interface ServiceItem {
  slug: string;
  title: string;
  shortDescription: string;
  longDescription: string;
  benefits: string[];
  industriesServed: string;
  buttonLabel: string;
  buttonHref: string;
  image: ImageAsset;
  icon: string;
}

export interface SolutionItem {
  slug: string;
  title: string;
  description: string;
  audience: string;
  benefit: string;
  help: string;
  discussLinkText: string;
  image: ImageAsset;
  icon: string;
}

export interface IndustryItem {
  title: string;
  icon: string;
  image: ImageAsset;
}

export interface ValueItem {
  title: string;
  text: string;
  icon: string;
}

export interface MilestoneItem {
  step: string;
  title: string;
  text: string;
}

export interface AboutStatItem {
  number: string;
  label: string;
}

export interface RegionItem {
  name: string;
  destinations: string;
  modes: string;
  services: string;
  pointX: number;
  pointY: number;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface HomeContent {
  hero: {
    eyebrow: string;
    titleLine1: string;
    titleLine2: string;
    description: string;
    primaryButton: string;
    primaryButtonHref: string;
    secondaryButton: string;
    secondaryButtonHref: string;
    bottomLabel: string;
    scrollLabel: string;
    bgImage: BannerAsset;
  };
  trackingWidget: {
    title: string;
    description: string;
    placeholder: string;
    buttonLabel: string;
    footerNote: string;
  };
  stats: StatItem[];
  servicesSection: {
    eyebrow: string;
    title: string;
    description: string;
    viewAllLabel: string;
  };
  aboutPreview: {
    eyebrow: string;
    title: string;
    paragraph1: string;
    paragraph2: string;
    stat1Number: string;
    stat1Label: string;
    stat2Number: string;
    stat2Label: string;
    buttonLabel: string;
    buttonHref: string;
    image: ImageAsset;
    photoCaption: string;
  };
  networkPreview: {
    eyebrow: string;
    title: string;
    description: string;
    buttonLabel: string;
    buttonHref: string;
    regionBadges: string[];
  };
  solutionsSection: {
    eyebrow: string;
    title: string;
    description: string;
    viewAllLabel: string;
  };
  industriesSection: {
    eyebrow: string;
    title: string;
    description: string;
  };
  journeySection: {
    eyebrow: string;
    title: string;
    description: string;
    steps: JourneyStep[];
  };
  whyChooseSection: {
    eyebrow: string;
    title: string;
    description: string;
    watermarkTop: string;
    watermarkBottom: string;
    features: FeatureItem[];
  };
  largeCta: {
    eyebrow: string;
    title: string;
    description: string;
    primaryButton: string;
    primaryButtonHref: string;
    secondaryButton: string;
    secondaryButtonHref: string;
    bgImage: BannerAsset;
  };
  compactCta: {
    eyebrow: string;
    title: string;
    buttonLabel: string;
    buttonHref: string;
  };
}

export interface AboutContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
    indexLabel1: string;
    indexLabel2: string;
  };
  editorial: {
    eyebrow: string;
    title: string;
    paragraph1: string;
    paragraph2: string;
    buttonLabel: string;
    buttonHref: string;
  };
  missionVision: {
    missionLabel: string;
    missionTitle: string;
    missionDescription: string;
    visionLabel: string;
    visionTitle: string;
    visionDescription: string;
  };
  valuesSection: {
    eyebrow: string;
    title: string;
    description: string;
    items: ValueItem[];
  };
  capabilitiesBanner: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  milestonesSection: {
    eyebrow: string;
    title: string;
    description: string;
    milestones: MilestoneItem[];
    stats: AboutStatItem[];
    disclaimer: string;
  };
}

export interface ServicesContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  overview: {
    eyebrow: string;
    title: string;
    description: string;
  };
  items: ServiceItem[];
}

export interface SolutionsContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  overview: {
    eyebrow: string;
    title: string;
    description: string;
  };
  detailsHeader: {
    eyebrow: string;
    title: string;
  };
  items: SolutionItem[];
}

export interface GlobalNetworkContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  mapSection: {
    eyebrow: string;
    title: string;
    description: string;
    selectRegionPrompt: string;
    coordinateText: string;
    caveat: string;
  };
  regions: RegionItem[];
  capabilitiesSection: {
    eyebrow: string;
    title: string;
    description: string;
    buttonLabel: string;
    buttonHref: string;
    items: { step: string; title: string; description: string }[];
  };
}

export interface TimelineMilestone {
  label: string;
  stageType: "done" | "current" | "upcoming";
}

export interface TrackingContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  form: {
    microLabel: string;
    title: string;
    subtitle: string;
    inputLabel: string;
    inputPlaceholder: string;
    selectLabel: string;
    options: string[];
    buttonLabel: string;
    searchingLabel: string;
  };
  demoHint: {
    badge: string;
    text: string;
    sampleNumber: string;
    infoButtonLabel: string;
  };
  emptyState: {
    title: string;
    textPrefix: string;
    textSuffix: string;
  };
  sampleResult: {
    bannerText: string;
    numberLabel: string;
    statusText: string;
    originLabel: string;
    originValue: string;
    destinationLabel: string;
    destinationValue: string;
    deliveryLabel: string;
    deliveryValue: string;
    shipmentTypeLabel: string;
    shipmentTypeValue: string;
    journeyHeading: string;
    journeyCount: string;
    timelineSteps: string[];
  };
  helpBox: {
    title: string;
    description: string;
    buttonLabel: string;
    buttonHref: string;
  };
  modal: {
    title: string;
    paragraph1: string;
    paragraph2: string;
  };
}

export interface QuoteContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  sidePanel: {
    eyebrow: string;
    title: string;
    description: string;
    points: { step: string; text: string }[];
    note: string;
  };
  form: {
    microLabel: string;
    title: string;
    subtitle: string;
    labels: {
      fullName: string;
      companyName: string;
      email: string;
      phone: string;
      origin: string;
      destination: string;
      cargoType: string;
      cargoWeight: string;
      shippingMethod: string;
      preferredDate: string;
      message: string;
    };
    placeholders: {
      fullName: string;
      companyName: string;
      email: string;
      phone: string;
      origin: string;
      destination: string;
      cargoType: string;
      cargoWeight: string;
      shippingMethodPrompt: string;
      message: string;
    };
    shippingMethods: string[];
    buttonLabel: string;
    submittingLabel: string;
    privacyNote: string;
    success: {
      microLabel: string;
      title: string;
      description: string;
      buttonLabel: string;
      toastMessage: string;
    };
  };
}

export interface ContactContent {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    bgImage: BannerAsset;
  };
  sidePanel: {
    eyebrow: string;
    title: string;
    description: string;
  };
  form: {
    microLabel: string;
    title: string;
    subtitle: string;
    labels: {
      fullName: string;
      companyName: string;
      email: string;
      phone: string;
      subject: string;
      message: string;
    };
    placeholders: {
      fullName: string;
      companyName: string;
      email: string;
      phone: string;
      subjectPrompt: string;
      message: string;
    };
    subjects: string[];
    buttonLabel: string;
    submittingLabel: string;
    privacyNote: string;
    success: {
      microLabel: string;
      title: string;
      description: string;
      buttonLabel: string;
      toastMessage: string;
    };
  };
  locationSection: {
    eyebrow: string;
    title: string;
    description: string;
    buttonLabel: string;
    buttonHref: string;
  };
  faqSection: {
    eyebrow: string;
    title: string;
    items: FaqItem[];
  };
}

export interface LegalContent {
  hero: {
    eyebrow: string;
    description: string;
    bgImage: BannerAsset;
  };
  note: string;
  privacy: {
    title: string;
    paragraph1: string;
    paragraph2: string;
  };
  terms: {
    title: string;
    paragraph1: string;
    paragraph2: string;
  };
  cookies: {
    title: string;
    paragraph1: string;
    paragraph2: string;
  };
}

export interface SiteContent {
  global: GlobalContent;
  home: HomeContent;
  about: AboutContent;
  services: ServicesContent;
  solutions: SolutionsContent;
  industries: IndustryItem[];
  globalNetwork: GlobalNetworkContent;
  tracking: TrackingContent;
  quote: QuoteContent;
  contact: ContactContent;
  legal: LegalContent;
}
