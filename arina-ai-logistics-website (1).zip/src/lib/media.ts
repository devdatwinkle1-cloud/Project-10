import type { CSSProperties } from "react";
import type { BannerAsset, ImageAsset } from "./cms-types";

/** Mobile breakpoint used by the website stylesheet (globals.css). */
export const MOBILE_BREAKPOINT = 760;

export const MEDIA_API_PREFIX = "/api/media/";

export const ACCEPTED_IMAGE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/svg+xml",
  "image/avif",
];

export const MAX_UPLOAD_BYTES = 8 * 1024 * 1024; // 8 MB

export const emptyImage = (alt = ""): ImageAsset => ({ src: "", alt });
export const emptyBanner = (alt = ""): BannerAsset => ({ src: "", mobileSrc: "", alt });

/** Escape a URL for use inside CSS url('...'). */
export function cssUrl(src: string) {
  return `url('${src.replace(/\\/g, "\\\\").replace(/'/g, "%27").replace(/\n/g, "")}')`;
}

/**
 * Builds the CSS custom properties consumed by banner sections
 * (.home-hero, .page-hero, .large-cta, .about-photo-band).
 * The gradient overlay is identical to the original design; only the image changes.
 * Mobile image (if provided) is applied by the stylesheet under the 760px breakpoint.
 */
export function bannerStyle(banner: BannerAsset | undefined | null, overlay: string): CSSProperties {
  const src = banner?.src?.trim() ?? "";
  const mobile = banner?.mobileSrc?.trim() ?? "";
  const desktop = src ? `${overlay}, ${cssUrl(src)}` : overlay;
  const mobileValue = mobile ? `${overlay}, ${cssUrl(mobile)}` : desktop;
  return {
    ["--bg-desktop" as string]: desktop,
    ["--bg-mobile" as string]: mobileValue,
  } as CSSProperties;
}

export function isUploadedMedia(src: string | undefined | null) {
  return !!src && src.startsWith(MEDIA_API_PREFIX);
}

export function mediaIdFromUrl(src: string): number | null {
  if (!isUploadedMedia(src)) return null;
  const id = Number(src.slice(MEDIA_API_PREFIX.length).split(/[/?#]/)[0]);
  return Number.isFinite(id) && id > 0 ? id : null;
}

export function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
