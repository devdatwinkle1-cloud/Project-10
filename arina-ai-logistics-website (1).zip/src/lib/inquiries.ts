import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { inquiries } from "@/db/schema";

const quoteFields = ["fullName", "companyName", "email", "phone", "origin", "destination", "cargoType", "cargoWeight", "shippingMethod"];
const contactFields = ["fullName", "email", "subject", "message"];
const allowed = ["fullName", "companyName", "email", "phone", "origin", "destination", "cargoType", "cargoWeight", "shippingMethod", "preferredDate", "subject", "message"];
export async function handleInquiry(request: NextRequest, kind: "quote" | "contact") {
  try {
    const raw = await request.text();
    if (raw.length > 16000) return NextResponse.json({ error: "Request is too large." }, { status: 413 });
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return NextResponse.json({ error: "Invalid form data." }, { status: 400 });
    const input = parsed as Record<string, unknown>;
    const data: Record<string, string> = {};
    for (const key of allowed) {
      const value = input[key];
      if (value !== undefined) {
        if (typeof value !== "string" || value.length > 3000) return NextResponse.json({ error: "Please check your form entries." }, { status: 400 });
        data[key] = value.trim();
      }
    }
    const required = kind === "quote" ? quoteFields : contactFields;
    if (required.some(key => !data[key])) return NextResponse.json({ error: "Please complete all required fields." }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email) || data.email.length > 320) return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
    if (kind === "quote" && (!Number.isFinite(Number(data.cargoWeight)) || Number(data.cargoWeight) <= 0 || !["Ocean", "Air", "Road", "Rail"].includes(data.shippingMethod))) return NextResponse.json({ error: "Please enter valid shipment details." }, { status: 400 });
    await db.insert(inquiries).values({ kind, fullName: data.fullName, companyName: data.companyName || null, email: data.email, phone: data.phone || null, details: data });
    return NextResponse.json({ success: true, message: "Your request has been received." });
  } catch (error) {
    console.error("Inquiry submission failed", error);
    return NextResponse.json({ error: "We couldn't submit your request right now. Please try again later." }, { status: 500 });
  }
}
