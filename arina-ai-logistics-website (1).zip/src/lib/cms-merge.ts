import type { SiteContent } from "./cms-types";
import { defaultSiteContent } from "./cms-defaults";

type AnyRecord = Record<string, unknown>;

function isPlainObject(value: unknown): value is AnyRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** A media object is any object that carries a `src` string (ImageAsset / BannerAsset). */
function isMediaObject(value: unknown): value is AnyRecord & { src: string } {
  return isPlainObject(value) && typeof value.src === "string";
}

/**
 * Deep-merges saved content on top of the defaults so that:
 *  - new keys added in later releases always exist,
 *  - legacy image values saved as plain URL strings are migrated to media objects
 *    ({ src, alt } / { src, mobileSrc, alt }) without losing the chosen image,
 *  - array items (services, solutions, industries, …) are merged item-by-item.
 */
export function mergeContent<T>(defaults: T, saved: unknown): T {
  if (saved === undefined || saved === null) return defaults;

  // Legacy string URL -> media object
  if (isMediaObject(defaults) && typeof saved === "string") {
    return { ...(defaults as AnyRecord), src: saved } as T;
  }

  if (Array.isArray(defaults)) {
    if (!Array.isArray(saved)) return defaults;
    const template = defaults[0];
    return saved.map((item, index) => {
      const base = defaults[index] !== undefined ? defaults[index] : template;
      if (base === undefined) return item;
      return mergeContent(base, item);
    }) as unknown as T;
  }

  if (isPlainObject(defaults)) {
    if (!isPlainObject(saved)) return defaults;
    const output: AnyRecord = { ...defaults };
    for (const key of Object.keys(saved)) {
      const defaultValue = (defaults as AnyRecord)[key];
      const savedValue = saved[key];
      if (defaultValue === undefined) {
        output[key] = savedValue; // unknown/extra key: keep as-is
      } else {
        output[key] = mergeContent(defaultValue, savedValue);
      }
    }
    return output as T;
  }

  // Primitive leaf: saved value wins (when the types are compatible)
  if (typeof defaults === typeof saved) return saved as T;
  return defaults;
}

/** Normalises any content payload (DB row, imported JSON, postMessage) into a complete SiteContent. */
export function normalizeSiteContent(input: unknown): SiteContent {
  return mergeContent(defaultSiteContent, input);
}
