import { db } from "@/db";
import { cmsContent, cmsMedia } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { SiteContent } from "./cms-types";
import { defaultSiteContent } from "./cms-defaults";
import { normalizeSiteContent } from "./cms-merge";

const MASTER_KEY = "master";

export async function getSiteContent(): Promise<SiteContent> {
  try {
    const rows = await db.select().from(cmsContent).where(eq(cmsContent.key, MASTER_KEY)).limit(1);
    if (rows && rows.length > 0 && rows[0].data) {
      // Merge with defaults so new keys exist and legacy image strings become media objects
      return normalizeSiteContent(rows[0].data);
    }

    // Lazy seed
    try {
      await db
        .insert(cmsContent)
        .values({
          key: MASTER_KEY,
          data: defaultSiteContent,
          version: 1,
        })
        .onConflictDoNothing();
    } catch (seedErr) {
      console.warn("Could not seed initial cmsContent:", seedErr);
    }

    return defaultSiteContent;
  } catch (err) {
    console.error("Error fetching site content from DB, falling back to defaults:", err);
    return defaultSiteContent;
  }
}

/** Collects the ids of uploaded images (/api/media/<id>) referenced anywhere in a content tree. */
export function referencedMediaIds(content: unknown): Set<number> {
  const ids = new Set<number>();
  const json = JSON.stringify(content ?? {});
  const re = /\/api\/media\/(\d+)/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(json)) !== null) ids.add(Number(match[1]));
  return ids;
}

/**
 * Deletes uploaded files that the previously published content used but the new one no longer does
 * (i.e. images that were replaced or removed in the editor and then published).
 * Uploads that were never published are left untouched so they stay available for reuse.
 */
async function cleanupReplacedMedia(previous: unknown, next: unknown) {
  const before = referencedMediaIds(previous);
  const after = referencedMediaIds(next);
  const orphaned = [...before].filter((id) => !after.has(id));
  if (orphaned.length === 0) return;
  try {
    await db.delete(cmsMedia).where(inArray(cmsMedia.id, orphaned));
  } catch (err) {
    console.warn("[media] cleanup of replaced images failed:", err);
  }
}

export async function saveSiteContent(
  newContent: SiteContent,
): Promise<{ success: boolean; version?: number; error?: string }> {
  try {
    const content = normalizeSiteContent(newContent);
    const existing = await db.select().from(cmsContent).where(eq(cmsContent.key, MASTER_KEY)).limit(1);
    const nextVersion = existing.length > 0 ? existing[0].version + 1 : 1;

    if (existing.length > 0) {
      await db
        .update(cmsContent)
        .set({
          data: content,
          updatedAt: new Date(),
          version: nextVersion,
        })
        .where(eq(cmsContent.key, MASTER_KEY));
    } else {
      await db.insert(cmsContent).values({
        key: MASTER_KEY,
        data: content,
        version: nextVersion,
      });
    }

    if (existing.length > 0) await cleanupReplacedMedia(existing[0].data, content);

    return { success: true, version: nextVersion };
  } catch (err) {
    console.error("Error saving site content:", err);
    return { success: false, error: err instanceof Error ? err.message : "Unknown error" };
  }
}

export async function resetSiteContent(): Promise<{ success: boolean; error?: string }> {
  try {
    const existing = await db.select().from(cmsContent).where(eq(cmsContent.key, MASTER_KEY)).limit(1);
    const nextVersion = existing.length > 0 ? existing[0].version + 1 : 1;

    if (existing.length > 0) {
      await db
        .update(cmsContent)
        .set({
          data: defaultSiteContent,
          updatedAt: new Date(),
          version: nextVersion,
        })
        .where(eq(cmsContent.key, MASTER_KEY));
    } else {
      await db.insert(cmsContent).values({
        key: MASTER_KEY,
        data: defaultSiteContent,
        version: nextVersion,
      });
    }

    return { success: true };
  } catch (err) {
    console.error("Error resetting site content:", err);
    return { success: false, error: err instanceof Error ? err.message : "Unknown error" };
  }
}
