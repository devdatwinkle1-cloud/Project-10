"use client";

import React, { createContext, useContext, useEffect, useState, useMemo } from "react";
import { SiteContent } from "@/lib/cms-types";
import { defaultSiteContent } from "@/lib/cms-defaults";
import { normalizeSiteContent } from "@/lib/cms-merge";

interface ContentContextValue {
  content: SiteContent;
  updateLocalPreview: (newContent: SiteContent) => void;
  isLivePreview: boolean;
}

const ContentContext = createContext<ContentContextValue>({
  content: defaultSiteContent,
  updateLocalPreview: () => {},
  isLivePreview: false,
});

export function ContentProvider({
  initialContent,
  children,
}: {
  initialContent?: SiteContent;
  children: React.ReactNode;
}) {
  const [content, setContent] = useState<SiteContent>(initialContent || defaultSiteContent);
  const [isLivePreview, setIsLivePreview] = useState(false);

  // Sync if initialContent changes on page transition
  useEffect(() => {
    if (initialContent) {
      setContent(initialContent);
    }
  }, [initialContent]);

  // Listen for Live Preview messages from the CMS Editor window or iframe
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === "ARINA_CMS_PREVIEW_UPDATE" && event.data.content) {
        setContent(normalizeSiteContent(event.data.content));
        setIsLivePreview(true);
      }
    };

    window.addEventListener("message", handleMessage);

    // If inside iframe, notify parent that preview is ready
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: "ARINA_CMS_PREVIEW_READY" }, "*");
    }

    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, []);

  const value = useMemo(
    () => ({
      content,
      updateLocalPreview: (newContent: SiteContent) => setContent(newContent),
      isLivePreview,
    }),
    [content, isLivePreview]
  );

  return <ContentContext.Provider value={value}>{children}</ContentContext.Provider>;
}

export function useContent(): SiteContent {
  const ctx = useContext(ContentContext);
  return ctx.content || defaultSiteContent;
}

export function useContentContext() {
  return useContext(ContentContext);
}

/**
 * Utility component to render formatted text with bold, italic, line breaks and basic formatting
 * without breaking typography or layout.
 */
export function FormattedText({ text, className = "" }: { text?: string; className?: string }) {
  if (!text) return null;

  // Split by newlines if any
  const lines = text.split("\n");

  return (
    <span className={className}>
      {lines.map((line, lineIdx) => {
        // Parse simple markdown/html like **bold**, *italic*, <b>, <i>, <u>, <em>
        const parts = line.split(/(\*\*.*?\*\*|\*.*?\*|<b>.*?<\/b>|<i>.*?<\/i>|<em>.*?<\/em>|<u>.*?<\/u>)/g);

        return (
          <React.Fragment key={lineIdx}>
            {parts.map((part, partIdx) => {
              if (part.startsWith("**") && part.endsWith("**")) {
                return <strong key={partIdx}>{part.slice(2, -2)}</strong>;
              }
              if (part.startsWith("*") && part.endsWith("*")) {
                return <em key={partIdx}>{part.slice(1, -1)}</em>;
              }
              if (part.startsWith("<b>") && part.endsWith("</b>")) {
                return <strong key={partIdx}>{part.slice(3, -4)}</strong>;
              }
              if (part.startsWith("<i>") && part.endsWith("</i>")) {
                return <em key={partIdx}>{part.slice(3, -4)}</em>;
              }
              if (part.startsWith("<em>") && part.endsWith("</em>")) {
                return <em key={partIdx}>{part.slice(4, -5)}</em>;
              }
              if (part.startsWith("<u>") && part.endsWith("</u>")) {
                return <u key={partIdx}>{part.slice(3, -4)}</u>;
              }
              return part;
            })}
            {lineIdx < lines.length - 1 && <br />}
          </React.Fragment>
        );
      })}
    </span>
  );
}
